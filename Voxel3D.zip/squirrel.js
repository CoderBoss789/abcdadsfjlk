Math.lookAt = function(x1, y1, x2, y2){
	return Math._direction = Math.atan2(y2-y1, x2-x1);
}
function distance3d(v1, v2){
    var dx = v1.x - v2.x;
    var dy = v1.y - v2.y;
    var dz = v1.z - v2.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}
function distance2d(x1, y1, x2, y2){
	var dx = x2 - x1, dy = y2 - y1;
	return Math.sqrt(dx*dx + dy*dy);
}
var sp = 0.05;
class Squirrel {
	constructor(x, y, z){
		this.x = x;
		this.y = y;
		this.z = z;
		this.dir = 0;
		this.width = 0.3;
		this.height = 0.4;
		this.depth = 0.3;
		this.yForce = 0;
		this.pet = false;
		this.destination = houses[Math.floor(Math.random()*houses.length)];
		this.dir = 0;
	}
	update(){
		/*if(Math.floor(this.x) > this.destination.x){
			this.x-=sp;
			this.dir = Math.lookAt(0,0,-1,0);
		} else if(Math.floor(this.x) < this.destination.x) {
			this.x+=sp;
			this.dir = Math.lookAt(0,0,1,0);
		} else if(Math.floor(this.z) > this.destination.z){
			this.z-=sp;
			this.dir = Math.lookAt(0,0,0,-1);
		} else if(Math.floor(this.z) < this.destination.z) {
			this.z+=sp;
			this.dir = Math.lookAt(0,0,0,1);
		} else if(Math.floor(this.y) > this.destination.y){
			this.y-=sp;
		} else if(Math.floor(this.y) < this.destination.y) {
			this.y+=sp;
		} else {
			this.destination = {
				x: Math.floor(tx),
				y: Math.floor(ty),
				z: Math.floor(tz)
			}
			//this.destination = houses[Math.floor(Math.random()*houses.length)];
		}*/
		//*if(distance3d(this,this.destination) > 5)*/setBlockFast(Math.round(this.x),Math.round(this.y),Math.round(this.z),5);
		this.downdate();
		//setBlockFast(Math.round(this.x),Math.round(this.y),Math.round(this.z),0);
	}
	set sqrl(x){
		this.pet = true;
		this.destination = {
				x: Math.floor(tx),
				y: Math.floor(ty),
				z: Math.floor(tz)
			};
		return true;
	}
	move(obj){
		for(var i=0;i<obj.length;i+=3){
			var __ = obj[i];
			obj[i] = Math.cos(Math.lookAt(obj[i], obj[i+2], 0, 0) + this.dir + Squirrel.rotation) * distance2d(obj[i], obj[i+2], 0, 0);
			obj[i+2] = Math.sin(Math.lookAt(__, obj[i+2], 0, 0) + this.dir + Squirrel.rotation) * distance2d(__, obj[i+2], 0, 0);
			obj[i] += this.x+0.15;
			obj[i+1] += this.y+0.2;
			obj[i+2] += this.z+0.15;
		}
		return obj;
	}
	downdate(){
		if(window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) return;
		var dir = Math.lookAt(this.x,this.z,this.destination.x,this.destination.z);
		this.y += this.yForce;
		var colliding = detectCollision(this);
		if (!colliding) this.yForce -= (0.01); else {
	    	var sign = -Math.sign(this.yForce);
	    	this.yForce = 0;
    		while (detectCollision(this)) {
        		this.y += 0.0625 * sign;
      		}
      		this.yForce += 0.2;
      	}
      	var n=0,spd = 0.05;
      	this.dir = dir;
      	for(var i=0;i<4;i++){
      		n=0;
      		spd = (this.dir == dir) ? 0.05 : window.SLUP || 0.25;
      		var bx = this.x;
      		this.x += Math.cos(dir) * spd;
      		if(detectCollision(this)){
      			this.x = bx;
      			n++;
      		}
      		var bz = this.z;
      		this.z += Math.sin(dir) * spd;
      		if(detectCollision(this)){
      			this.z = bz;
      			n++;
      		}
      		if(n<2) break;
      		dir += Math.PI / 2 * Math.sign(Math.random()-0.5);
      		if(!this.pet)this.destination = houses[Math.floor(Math.random()*houses.length)];
        }
        if(distance2d(this.x,this.z,this.destination.x,this.destination.z) < 5){
        	if(this.pet){
        		this.destination = {
					x: Math.floor(tx),
					y: Math.floor(ty),
					z: Math.floor(tz)
				}
			} else {
        		this.destination = houses[Math.floor(Math.random()*houses.length)];
			}
        }
      	this.dir = dir;
      	if(this.y < -100){
      		this.x = 0;this.y = 90; this.z = 0;
      	}
	}
}
Squirrel.rotation = Math.PI;
Squirrel.xTranslation = 0.5;
if(typeof module !== "undefined" && typeof require !== "undefined" && module.exports){
    module.exports = Squirrel;
}