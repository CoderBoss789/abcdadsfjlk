window.prompt = function(arg,_default,restrict){
  return new Promise(resolve => {
    window.prompting = true;
    if(document.pointerLockElement) document.exitPointerLock();
    let hide = document.createElement('div');
    hide.style.zIndex = "99998";
    hide.style.backgroundColor = "rgba(0,0,0,0.7)";
    hide.style.width="100%";
    hide.style.height="100%";
    hide.id="prompt-div";
    hide.style.position = "absolute";
    hide.style.left = "0%";
    hide.style.top = "0%";
    hide.innerHTML = `<div style="text-align: center;"><div id="pr" style="border:2px double blue;display: inline-block;background-color:red;border-radius: 10px;padding:10px;" class="vertical-center"><label for="inn" style="color:white">${arg}</label><br><input value="${_default}" id="inn"><button onclick="pend()">Ok</button></div></div>`;
    document.body.append(hide);
    if(restrict){
      document.getElementById("inn").addEventListener('keydown', (e) => {
      if(restrict.split('').indexOf(e.key) !== -1 || e.key.length > 1){} else {
        e.preventDefault();
      }
});
    }
    window.pend = function(){
      let val = document.getElementById("inn").value;
      var ETTheExtraTerrestrial = document.getElementById('et');
      var extra;
      //console.log(ETTheExtraTerrestrial, ETTheExtraTerrestrial.value);
      if(ETTheExtraTerrestrial){
        extra = ETTheExtraTerrestrial.value;
        console.log('extra');
      }
      document.getElementById("prompt-div").remove();
      window.prompting = false;
      if(extra)resolve([val, extra]);else resolve(val);
    }
  });
}
window.show = function(arg){
  return new Promise(resolve => {
    window.prompting = true;
    if(document.pointerLockElement) document.exitPointerLock();
    let hide = document.createElement('div');
    hide.style.zIndex = "99998";
    hide.style.backgroundColor = "rgba(0,0,0,0.7)";
    hide.style.width="100%";
    hide.style.height="100%";
    hide.id="prompt-div";
    hide.style.position = "absolute";
    hide.style.left = "0%";
    hide.style.top = "0%";
    hide.innerHTML = `<div style="text-align: center;"><div id="pr" style="border:2px double blue;display: inline-block;background-color:red;border-radius: 10px;padding:10px;" class="vertical-center"><div style="color:white">${arg}</div><br><button onclick="pend()">Ok</button></div></div>`;
    document.body.append(hide);
    window.pend = function(){
      document.getElementById("prompt-div").remove();
      window.prompting = false;
      resolve();
    }
  });
}