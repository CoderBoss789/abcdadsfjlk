const { app, BrowserWindow } = require('electron');
app.whenReady().then(()=>{
	var win = new BrowserWindow({width: 800, height: 500});
	win.loadURL(`https://meow.astroide.repl.co/`);
});
