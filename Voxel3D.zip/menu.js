/**
 * Copyright (c) 2020 Olie Auger | https://repl.it/@ASTROIDE/
 */
function main(){
	sessionStorage.setItem('gametype', 'singleplayer');
  
var reset;
var div = document.getElementById('list');
var ul = document.createElement('ul');
var list = games.list();
var n = document.createElement('li'), n2 = document.createElement('a'), n3 = document.createElement('a'), n4 = document.createElement('a'), n5 = document.createElement('button');
n.appendChild(n2);
n.appendChild(n3);
n.appendChild(n4);
n.appendChild(n5);
ul.appendChild(n);
n2.href = './play.html';
n3.href = './play.html';
n4.href = './info.html';
n2.innerText = 'New world';
n3.innerText = 'New world (limited resources)';
n4.innerText = 'Information';
n4.remove();
n5.innerText = 'Disable NPCs';
n2.onclick = function(){
	window.sessionStorage.setItem('gamemode', 'creative');
	window.sessionStorage.setItem('gametype', 'singleplayer');
}
n3.onclick = function(){
	window.sessionStorage.setItem('gamemode', 'survival');
	window.sessionStorage.setItem('gametype', 'singleplayer');
}
n5.onclick = () => {
	sessionStorage.disableNPCs = "true";
}
for (var i = list.length - 1; i >= 0; i--) {
	let name = list[i];
	let element = document.createElement('li');
	let a = document.createElement('a');
	a.href = './play.html?'+encodeURIComponent(name);
	a.innerText = name;
	let btn = document.createElement('button');
	btn.innerText = '[Delete]';
	btn.onclick = function(){games.remove(name);element.remove();}
	let code = document.createElement('button');
	code.innerText = '[Download]';
	code.onclick = function(){
		show(`<a download="${name.replace(/"/g, '&quot')}.meow" href="data:text/plain,${games.toString(name)}">&#11015;</a>`);
	}
	element.appendChild(a);
	element.appendChild(btn);
	element.appendChild(code);
	ul.appendChild(element);
}
var button = document.createElement('button');
button.innerText = 'Delete All';
button.onclick = function(){games.removeAll();reset();}
var importInput = document.createElement('input');
importInput.type = 'file';
importInput.accept = '.meow';
importInput.style.display='none';
importInput.onchange = function(e){
	var file = importInput.files[0];
	var fr = new FileReader();
	fr.onload = function(){
		var text = fr.result;
		var name = file.name.replace(/^(.*).meow$/, "$1");
		localStorage.setItem('X'+name, text);
		localStorage.setItem('games', games.list().concat([name]).join('_'));
		reset();
	}
	fr.readAsText(file);
}
var importButton = document.createElement('button');
importButton.innerText = 'Import';
importButton.onclick = function(){
	importInput.click();
}
var multiplayerButton = document.createElement('a');
multiplayerButton.innerText = 'Multiplayer';
//multiplayerButton.addEventListener('click', function() {
//console.log('!');
//	sessionStorage.setItem('gametype', 'multiplayer');
//	location.href = sessionStorage.getItem('username') && sessionStorage.getItem('password') ? './server.html' : './account.html';
//});
multiplayerButton.href = './account.html';
div.appendChild(ul);
div.appendChild(button);
div.appendChild(importInput);
div.appendChild(importButton);
div.appendChild(multiplayerButton);
reset = function(){
	ul.remove();button.remove();importButton.remove();importInput.remove();multiplayerButton.remove();main();
}                               
console.log('ok');
}
main();