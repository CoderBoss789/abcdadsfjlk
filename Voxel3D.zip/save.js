/**
 * Copyright (c) 2020 Olie Auger | https://repl.it/@ASTROIDE/
 */
(function(){
function list(){
  var str = localStorage.getItem('games') || '';
	return str.split('_').filter(e => !!e);
}
function remove(key){
	var games = list();
	if(games.includes(key)){
		games.splice(games.indexOf(key), 1);
		localStorage.removeItem('X'+key);
	}
	localStorage.setItem('games', games.join('_'));
}
function removeAll(){
	var games = list();
	localStorage.setItem('games', '');
	for (var i = games.length - 1; i >= 0; i--) {
		localStorage.removeItem(games[i]);
	}
}
function toString(){
	var string = "", array = [], entry, c, sub;
	for (var i = chunks.length - 1; i >= 0; i--) {
		c = chunks[i];
		entry = `${c.x}/${c.y}/${c.z}/`;
		sub = '';
		for (var j = 0; j < c.data.length; j++) {
			sub += String.fromCharCode(c.data[j] + 97);
		}
		sub = RLE_encode(sub);
		entry += sub;
		array.push(entry);
	}
	if(limited){
		array.push('MODE/SURVIVAL');
		array.push(`INVENTORY/${inventory.toString().replace(/"/g, '$')}`);
		console.log(array[array.length-1]);
	}
	var houseData = [];
	window.houses = window.houses || [{x:16,y:50,z:16}];
	for(var i=0;i<houses.length;i++){
		var h = houses[i];
		houseData.push(`${h.x.toString(16)}~${h.y.toString(16)}~${h.z.toString(16)}`);
	}
	array.push(`HOUSES/${houseData.join(';')}`);
	var wp, ps = [];
	window.portalList = window.portalList || [];
	for(var i=0;i<window.portalList.length;i++){
		ps.push(`${portalList[i].replace(/\//g,'~')}~${JSON.stringify(portals[portalList[i]].map(x => x.toString(16))).replace(/"/g,'$')}`);
		console.log(ps);
	}
	wp = window.waitingPortal ? `${waitingPortal.x.toString(16)}~${waitingPortal.y.toString(16)}~${waitingPortal.z.toString(16)}` : '!'
	array.push(`PORTALS/${wp}/${ps.join(';')}`);
	if(window.animals){
		let horseStrings = [];
		for(var i=0;i<animals.horses.length;i++){
			horseStrings.push(`${animals.horses[i].x}~${animals.horses[i].y-1}~${animals.horses[i].z}`);
		}
		let squirrelStrings = [];
		for(var i=0;i<animals.squirrels.length;i++){
			squirrelStrings.push(`${animals.squirrels[i].x}~${animals.squirrels[i].y}~${animals.squirrels[i].z}`);
		}
		let birdStrings = [];
		for(var i=0;i<animals.birds.length;i++){
			birdStrings.push(`${animals.birds[i].x}~${animals.birds[i].y-1}~${animals.birds[i].z}`);
		}
		array.push(`ANIMALS/${horseStrings.join(';')}/${squirrelStrings.join(';')}/${birdStrings.join(';')}`);
	}
	string = "{" + array.join('|') + '}';
	return string;
}
function addChunk(data){
	c = data.split('/');
		//console.log(c);
		if(c[0]=='MODE') {
			limited = (c[1] == 'SURVIVAL');
			return false;
		} else if(c[0]=='RENDERDISTANCE'){
			renderDistance = parseFloat(c[1]);
		}else if(c[0]=='INVENTORY'){
			inventory.load(c[1].replace(/\$/g,'"'));
			return false;
		} else if(c[0]=="HOUSES"){
			var hs = c[1] = c[1].split(';');
			window.houses = window.houses || [];
			for(var i=0;i<hs.length;i++){
				hs[i] = hs[i].split('~');
				var h = {
					x: parseInt(hs[i][0], 16),
					y: parseInt(hs[i][1], 16),
					z: parseInt(hs[i][2], 16)
				}
				window.houses.push(h);
			}
			return false;
		} else if (c[0]=="PORTALS") {
			console.log('Gerbils !');
			if(c[1] == '!') window.waitingPortal = null;
			else {
				window.waitingPortal = {};
				[waitingPortal.x,waitingPortal.y,waitingPortal.z] = c[1].split('~').map(x => parseInt(x,16));
				window.waitingPortal.str = `${waitingPortal.x}/${waitingPortal.y}/${waitingPortal.z}`;
			}
				window.portalList = window.portalList || [];
				window.portals = window.portals || [];
				
				let ps = c[2].split(';'), cp, dst;
				if(!ps[0])ps=[];
				console.log(ps,c);
				for(let i=0;i<ps.length;i++){
					console.log('git+https://',ps);
					cp = ps[i].split('~');
					dst = cp[3];
					console.log('ftp://',dst);
					cp = cp.slice(0,3);
					var str = cp.join('/');
					portalList.push(str);
					portals[str] = JSON.parse(dst.replace(/\$/g,'"')).map(x => parseInt(x,16));
				}
		} else if(c[0] == 'ANIMALS'){
			window.animals = window.animals || {
				horses: [],
				squirrels: [],
				birds: []
			};
			var horses = c[1].split(';').map(x => {return x.split('~').map(parseFloat)});
			for(var i=0;i<horses.length;i++){
				window.animals.horses.push(new Horse(...horses[i]));
			}
			var squirrels = c[2].split(';').map(x => {return x.split('~').map(parseFloat)});
			for(var i=0;i<squirrels.length;i++){
				window.animals.squirrels.push(new Squirrel(...squirrels[i]));
				console.log('SQUIRREL !!!');
			}
			var birds = c[3].split(';').map(x => {return x.split('~').map(parseFloat)});
			for(var i=0;i<birds.length;i++){
				window.animals.birds.push(new Bird(...birds[i]));
			}
		} else {
		var ch = new Chunk(window.gl, parseInt(c[0]), parseInt(c[1]), parseInt(c[2]), false);
		//console.log(c);
		if(true || c[3].indexOf(';')) c[3] = RLE_decode(c[3]);
		for (var i = 0; i < c[3].length; i++) {
			var n = c[3].codePointAt(i) - 97;
			ch.data[i] = n;
		}
		return ch;
	}
}
function save(key){
	key = key.replace(/_/g, '');
	var string = toString();
	console.log(string.length / 1e6);
	console.log(string);
	localStorage.setItem('X'+key, string);
	if(!list().includes(key))
	localStorage.setItem('games', (localStorage.getItem('games') ? localStorage.getItem('games')+'_' : '') + key);
	console.log('saved', key);
}
function load(key){
	decode(localStorage.getItem('X'+key));
}
function decode(val){
	var str = val;
	//console.log(val);
	str = str.slice(1);
	str = str.slice(0,str.length-1);
	var chunks = str.split('|').map(c => addChunk(c)).filter(x => !!x);
	window.chunks = chunks;
	tx = 8;
	ty = 50;
	tz = 8;
}
function toString2(key){
	return localStorage.getItem('X'+key);
}
function loadThis(){
if(location.search){
	var gamename = location.search.slice(1);
	if(list().includes(decodeURIComponent(gamename))){
		load(decodeURIComponent(gamename));
		window.GAME_NAME = decodeURIComponent(gamename);
		window.GAME_SAVED = true;
		window.cleanChunks && cleanChunks();
		return true;
	}else console.log('cannot load', gamename);
}
}
window.games = {
	list: list,
	remove: remove,
	removeAll: removeAll,
	save: save,
	load: load,
	loadThis: loadThis,
	toString: toString2,
	decode: decode,
	addChunk: addChunk
};
})();