function loadObjFile(url, scale, translation){
  return new Promise(async resolve => {
    var string = await (await fetch(url)).text();
    var lns = string.split('\n');
    var mtlfileurl = './models/default.mtl';
    for (var i = lns.length - 1; i >= 0; i--) {
      if(lns[i].startsWith('mtllib ')){
        lns[i] = lns[i].slice(7);
        mtlfileurl = lns[i];
      }
    }
    var mtlfile = await (await fetch(mtlfileurl)).text();
    var mtlfilelines = mtlfile.split('\n').map(ln => ln.trim());
    //console.log('passing');
    var img = await (new Promise(resolve => {
    var ii = new Image();
    for (var i = 0; i < mtlfilelines.length; i++) {
      //if(mtlfilelines[i].startsWith('map_Ka ')){
        ii.src = url.slice(0, -3)+'png';
        break;
      //}
    }
    //console.log(ii);
    ii.onload = function(){/*console.log('should pass');*/resolve(ii);}
    }));
    //console.log('passed');
    var tr = translation;
    scale = scale || [1,1,1];
    var rVertices = [], vertices = [], texcoords = [], rTexcoords = [];
    var lines = string.split('\n');
    for(var lineNo = 0;lineNo < lines.length;lineNo++){
      var line = lines[lineNo];
      if(line == '' || line.startsWith('#')) continue;
      if(line.startsWith('v ')){
        line = line.slice(2).split(' ');
        vertices.push([parseFloat(line[0])*scale[0]+tr[0], parseFloat(line[1])*scale[1]+tr[1], parseFloat(line[2])*scale[2]+tr[2]]);
      }else if(line.startsWith('f ')){
        line = line.slice(2).split(' ');
        //console.log(line);
        for(var j=0;j<line.length;j++)
        line[j] = line[j].split('/').map(e => {/*console.log('>',e);*/return parseInt(e);});
        rVertices = rVertices.concat(
          vertices[line[0][0]-1].concat(
            vertices[line[1][0]-1].concat(
              vertices[line[2][0]-1]
            )
          )
        );
        //console.log(texcoords, line);
        rTexcoords = rTexcoords.concat(
          texcoords[line[0][1]-1].concat(
            texcoords[line[1][1]-1].concat(
              texcoords[line[2][1]-1]
            )
          )
        );
      }else if(line.startsWith('vt ')){
        line = line.slice(3).split(' ');
        //console.log(line);
        texcoords.push([parseFloat(line[0]),parseFloat(line[1])]);
      }
    }
    //console.log('meow');
    resolve({vertices: rVertices, texcoords: rTexcoords, texture: img});
  });
}