var account = {
    status: 'create-account',
    elements: {
        type: document.getElementById('type'),
        username: document.getElementById('username'),
        password: document.getElementById('password'),
        confirm: document.getElementById('confirm'),
        typeswitch: document.getElementById('typeswitch'),
        mainDiv: document.getElementById('all'),
        info: document.getElementById('info')
    },
    change: () => {
        if(account.status == 'create-account'){
            account.status = 'login';
            account.elements.type.innerText = 'Login';
            document.title = 'Login';
            account.elements.confirm.innerText = 'Login';
            account.elements.typeswitch.innerText = '[Create an account]';
        } else {
            account.status = 'create-account';
            account.elements.type.innerText = 'Create an account';
            document.title = 'Create an account';
            account.elements.confirm.innerText = 'Create account';
            account.elements.typeswitch.innerText = '[Login]';
        }
    },
    confirm: () => {
        if(account.status == 'create-account'){
            if(!account.elements.username.value){
                account.elements.info.innerText = 'Enter a username';
            } else if(!account.elements.password.value){
                account.elements.info.innerText = 'Enter a password';
            } else {
                var username, password;
                createAccount(username = account.elements.username.value, password = account.elements.password.value).then(() => {
                    account.elements.mainDiv.innerHTML = '<h2>Account Created</h2><br><a href="./play.html">Play</a>';
                    sessionStorage.setItem('username', username);
                    sessionStorage.setItem('password', password);
                }).catch(() => {
                    account.elements.info.innerText = 'This username is already taken.';
                });
            }
        } else {
            if(!account.elements.username.value){
                account.elements.info.innerText = 'Enter a username';
            } else if(!account.elements.password.value){
                account.elements.info.innerText = 'Enter a password';
            } else {
                var username, password;
                auth(username = account.elements.username.value, password = account.elements.password.value).then((status) => {
                    if(status){
                        account.elements.info.innerText = status;
                        return;
                    }
                    account.elements.mainDiv.innerHTML = '<h2>Login Successful</h2><br><a href="./server.html">Choose a server</a>';
                    sessionStorage.setItem('username', username);
                    sessionStorage.setItem('password', password);
                });
            }
        }
    }
};
account.change();
account.elements.username.addEventListener('keydown', (e) => {
    var restrict = 'QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm_1234567890';
    if(restrict.split('').indexOf(e.key) !== -1 || e.key.length > 1){} else {
      e.preventDefault();
    }
});
sessionStorage.setItem('gametype', 'multiplayer');