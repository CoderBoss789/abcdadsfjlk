const letters = "abcdefghijklmnopqrtsuvwxyzeeaaoouuiiy";
function randomName() {
    return Array(Math.floor(Math.random() * 4) + 4).fill(0).map((_, i) => letters[Math.floor(Math.random() * letters.length)][`to${i == 0 ? 'Upp' : 'Low'}erCase`]()).join('');
}
function randomElement(array) {
    return array[Math.floor(Math.random() * array.length)];
}
function lookAt(x1, y1, x2, y2) {
    x2 -= x1;
    y2 -= y1;
    return Math.atan2(y2, x2);
}
function arrayRandom(array) {
    return array[Math.floor(Math.random() * array.length)];
}
function decenter(o) {
    // var newObject = {
    //     width: o.width,
    //     height: o.height,
    //     depth: o.depth,
    //     x: o.x - o.width / 2,
    //     y: o.y - o.height / 2,
    //     z: o.z - o.depth / 2
    // };
    // return newObject;
    return o;
}
function quickDistance(x1, y1, z1, x2, y2, z2) {
    return (x1 - x2) ** 2 + (y1 - y2) ** 2 + (z1 - z2) ** 2;
}
var personWaitList = [];
/**
 * Class for representing a human NPC.
 */
class Person {
    /**
     * Creates a new Person.
     * @param {number} x Starting X coordinate
     * @param {number} y Starting Y coordinate
     * @param {number} z Starting Z coordinate
     */
    constructor(x, y, z, villageXZ) {
        this.source = {
            ...villageXZ,
            y: 0
        }
        this.x = x;
        this.y = y;
        this.z = z;
        this.orientation = {
            horizontal: 0,
            vertical: 0
        }
        this.width = 0.6;
        this.height = 1.6;
        this.depth = 0.6;
        this.wentOut = false;
        this.distance = 0;
        this.mx = 0;
        this.mz = 0;
        this.yForce = 0;
        this.life = 10;
        this.mad = false;
        this.realName = randomName();
        this.name = this.realName.toLowerCase();
        this.visible = false;
        this.pet = new Rabbit(this.x, this.y, this.z, this);
        this.registeredPet = false;
    }
    sendMessage(message) {
        addMessage(`[${this.realName}] ${message}`);
    }
    buyOrExchange(self) {
        return function (answer) {
            if (answer) {
                answer = answer.toLowerCase().trim();
                if (answer == 'non') {
                    self.sendMessage('À plus tard !');
                } else if (answer == 'oui') {
                    objects.food.push(new (arrayRandom([Carrot, HealingPotion]))(self.x, self.y, self.z));
                } else {
                    ask(`[${self.realName}] Je ne te comprends pas. Peux-tu répéter ?`).then(self.buyOrExchange(self));
                }
            }
        }
    }
    update() {
        if (!this.registeredPet && window.animals && window.animals.rabbits) {
            animals.rabbits.push(this.pet);
            this.registeredPet = true;
        }
        var tmp;
        if ((tmp = quickDistance(this.x, this.y, this.z, tx, ty, tz)) > (renderDistance * renderDistance)) return;
        if (tmp < 400) {
            if (!this.visible && !this.mad) this.sendMessage(randomElement("Hi|Hello".split("|")) + " !");
            this.visible = true;
            if (Math.random() > 0.99) {
                // ask('[' + this.realName + '] Veux-tu m\'acheter ou m\'échanger quelque chose ?').then(this.buyOrExchange(this));
            }
        } else {
            this.visible = false;
        }
        if (this.distance-- <= 0) {
            this.distance = this.mad ? 35 : this.wentOut ? 100 : 200;
            let destination = this.mad ? {
                x: tx,
                y: ty,
                z: tz
            } : !this.wentOut ? this.source : {
                x: this.x + Math.random() * 10 - 5,
                y: this.y + Math.random() * 10 - 5,
                z: this.z + Math.random() * 10 - 5
            }
            this.orientation.horizontal = lookAt(this.x, this.z, destination.x, destination.z) - Math.PI / 2;
            this.orientation.vertical = lookAt(this.y, 0, destination.y, 0);
            this.mx = Math.cos(this.orientation.horizontal + Math.PI / 2) * 0.1;
            this.mz = Math.sin(this.orientation.horizontal + Math.PI / 2) * 0.1;
            if (!this.wentOut) this.wentOut = true;
        }
        this.y += this.yForce;
        var colliding = detectCollision(this), canJump = false;
        if (!colliding) this.yForce -= (0.01); else {
            var sign = -Math.sign(this.yForce), tmp = this.yForce;
            this.yForce = 0;
            if (Math.abs(tmp) <= 0.123) {
                this.y += -tmp;
            } else {
                while (detectCollision(this)) {
                    this.y += 0.0625 * sign;
                }
            }
            canJump = true;
        }
        this.x += this.mx;
        if (detectCollision(this)) {
            this.x -= this.mx;
            if (canJump) {
                this.yForce += 0.2;
                canJump = false;
            }
        }
        this.z += this.mz;
        if (detectCollision(this)) {
            this.z -= this.mz;
            if (canJump) this.yForce += 0.2;
        }
        this.orientation.vertical += Math.random() / 20 - 0.025;
        this.orientation.vertical = Math.min(Math.max(this.orientation.vertical, -Math.PI / 2), Math.PI / 2);
        if (this.y < -100) {
            this.y = 100;
            this.yForce = 0;
            this.x = 0;
            this.y = 0;
        }
        if (Math.random() > 0.9995) {
            objects.food.push(new (arrayRandom([Carrot, HealingPotion]))(this.x, this.y, this.z));
        }
        if (Math.random() > 0.92 && this.mad) {
            window.objects.arrows.push(new Arrow(this.x, this.y + 2, this.z, { horizontal: -this.orientation.horizontal + Math.PI, vertical: 0 }, horizontalVerticalDistanceToXYZ, { arrowForce: 0.55 }, this));
            for (let index = 0; index < window.animals.npcs.length; index++) {
                const npc = window.animals.npcs[index];
                if (npc == this) continue;
                if (quickDistance(npc.x, npc.y, npc.z, this.x, this.y, this.z) < 400) {
                    if (!npc.mad) npc.sendMessage('$#900You\'re $bMEAN$c ! You\'ve thrown an arrow to ' + this.name + ' !');
                    npc.mad = true;
                }
            }
        }
        if (this.life <= 0) {
            return true;
        }
    }
    gotHitByAnArrow(thrower) {
        if (thrower == "player") {
            if (!this.mad) this.sendMessage('$1REVENGE !');
            this.mad = true;
        }
        this.lastHit = thrower;
        this.life--;
    }
}