/**
 * Copyright (c) 2020 Olie Auger | https://repl.it/@ASTROIDE/
 * except window.onerror & throttle
 */
DISABLE_REGION_COLLISION=1;
var cameraPosition = {
  x: 0,
  y: 0,
  z: 0,
  yOffset: 0.95
}
var toCheck = [];
function blockFlow(x, y, z, toCheckNext, blockType) {
  if(y < -100) return;
  // setBlockFast(x, y, z, 0);
  // setBlockFast(x, y, z, WATER, true);
  // var toCheck = [];
  // toCheck.push([x, y, z]);
  // debugger;
  // for (let i = 0; i < toCheck.length; i++) {
  //  [x, y, z] = toCheck[i];
  if (!getBlockFast(x - 1, y - 1, z) && getBlockFast(x - 1, y - 2, z)) {
    toCheckNext.push([x - 1, y - 1, z]);
    setBlockFast(x - 1, y - 1, z, blockType, true);
    // return
  }
  if (!getBlockFast(x + 1, y - 1, z) && getBlockFast(x + 1, y - 2, z)) {
    toCheckNext.push([x + 1, y - 1, z]);
    setBlockFast(x + 1, y - 1, z, blockType, true);
    // return
  }
  if (!getBlockFast(x, y - 1, z - 1) && getBlockFast(x, y - 2, z - 1)) {
    toCheckNext.push([x, y - 1, z - 1]);
    setBlockFast(x, y - 1, z - 1, blockType, true);
    // return
  }
  if (!getBlockFast(x, y - 1, z + 1) && getBlockFast(x, y - 2, z + 1)) {
    toCheckNext.push([x, y - 1, z + 1]);
    setBlockFast(x, y - 1, z + 1, blockType, true);
    // return
  }
  if (!getBlockFast(x, y - 1, z)) {
    toCheckNext.push([x, y - 1, z]);
    setBlockFast(x, y - 1, z, blockType, true);
    // return
  }
  // --- \\
  if (!getBlockFast(x - 1, y, z) && getBlockFast(x - 1, y - 1, z)) {
    toCheckNext.push([x - 1, y, z]);
    setBlockFast(x - 1, y, z, blockType, true);
    // return
  }
  if (!getBlockFast(x + 1, y, z) && getBlockFast(x + 1, y - 1, z)) {
    toCheckNext.push([x + 1, y, z]);
    setBlockFast(x + 1, y, z, blockType, true);
    // return
  }
  if (!getBlockFast(x, y, z - 1) && getBlockFast(x, y - 1, z - 1)) {
    toCheckNext.push([x, y, z - 1]);
    setBlockFast(x, y, z - 1, blockType, true);
    // return
  }
  if (!getBlockFast(x, y, z + 1) && getBlockFast(x, y - 1, z + 1)) {
    toCheckNext.push([x, y, z + 1]);
    setBlockFast(x, y, z + 1, blockType, true);
    // return
  }
  // --- \\
  if (!getBlockFast(x - 2, y - 1, z) && getBlockFast(x - 2, y - 2, z) && (getBlockFast(x - 1, y - 1, z) == blockType)) {
    toCheckNext.push([x - 2, y - 1, z]);
    setBlockFast(x - 2, y - 1, z, blockType, true);
    // return
  }
  if (!getBlockFast(x + 2, y - 1, z) && getBlockFast(x + 2, y - 2, z) && (getBlockFast(x + 1, y - 1, z) == blockType)) {
    toCheckNext.push([x + 2, y - 1, z]);
    setBlockFast(x + 2, y - 1, z, blockType, true);
    // return
  }
  if (!getBlockFast(x, y - 1, z - 2) && getBlockFast(x, y - 2, z - 2) && (getBlockFast(x, y - 1, z - 1) == blockType)) {
    toCheckNext.push([x, y - 1, z - 2]);
    setBlockFast(x, y - 1, z - 2, blockType, true);
    // return
  }
  if (!getBlockFast(x, y - 1, z + 2) && getBlockFast(x, y - 2, z + 2) && (getBlockFast(x, y - 1, z + 1) == blockType)) {
    toCheckNext.push([x, y - 1, z + 2]);
    setBlockFast(x, y - 1, z + 2, blockType, true);
    // return
  }
  if(!getBlockFast(x+1, y-1, z) && getBlockFast(x, y-1, z) != WATER){
    toCheckNext.push([x+1, y-1, z]);
    setBlockFast(x+1, y - 1, z, blockType, true);
  }
  if(!getBlockFast(x-1, y-1, z) && getBlockFast(x, y-1, z) != WATER){
    toCheckNext.push([x-1, y-1, z]);
    setBlockFast(x-1, y - 1, z, blockType, true);
  }
  if(!getBlockFast(x, y-1, z+1) && getBlockFast(x, y-1, z) != WATER){
    toCheckNext.push([x, y-1, z+1]);
    setBlockFast(x, y - 1, z+1, blockType, true);
  }
  if(!getBlockFast(x, y-1, z-1) && getBlockFast(x, y-1, z) != WATER){
    toCheckNext.push([x, y-1, z-1]);
    setBlockFast(x, y - 1, z-1, blockType, true);
  }
  console.log(':>>', i);
  // }
}
window.blockFlow = blockFlow;
/**
 * @type {(() => void)[]}
 */
var ondrawend = [];
function onDrawEnd(fn) {
  ondrawend.push(fn);
}
var waterList = [];
var answering = false;
function format(text) {
  text = text.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  var returnText = '', openElements = [];
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char == '$') {
      let next = text[i + 1] || 'r';
      if (next == 'c') {
        returnText += `</${openElements.pop()}>`;
      } else if (next != '#') {
        switch (next) {
          case 'b':
            openElements.push('strong');
            returnText += '<strong>';
            break;
          case 'i':
            openElements.push('em');
            returnText += '<em>';
            break;
          case 'u':
            openElements.push('text');
            returnText += '<text style="text-decoration:underline;">';
            break;
          case '1':
            openElements.push('text');
            returnText += '<text style="color:#f00">';
            break;
          case '2':
            openElements.push('text');
            returnText += '<text style="color:#0f0">';
            break;
          case '3':
            openElements.push('text');
            returnText += '<text style="color:#00f">';
            break;
          case '4':
            openElements.push('text');
            returnText += '<text style="color:#ff0">';
            break;
          case '5':
            openElements.push('text');
            returnText += '<text style="color:#0ff">';
            break;
          case '6':
            openElements.push('text');
            returnText += '<text style="color:#f0f">';
            break;
        }
      } else {
        var color = (text[i + 2] || '0') + (text[i + 3] || '0') + (text[i + 4] || '0');
        openElements.push('text');
        returnText += `<text style="color:#${color}">`;
        i += 3;
      }
      i++;
    } else {
      returnText += char;
    }
  }
  while (openElements.length) {
    returnText += `</${openElements.pop()}>`;
  }
  return returnText
}
function addMessage(message) {
  message = format(message);
  if (messages[messages.length - 1] !== message || message.startsWith('!')) messages.push(message.startsWith('!') ? message.slice(1) : message);
  if (messages.length > 3) messages.shift();
  message_div.innerHTML = `${messages.join('<br>')}`;
}
var actualQuestion = [];
function ask(question) {
  return new Promise((resolve) => {
    actualQuestion = [question, resolve];
    addMessage(question);
  });
}
var playerLife = 1.0;
function hitPlayer(force) {
  playerLife -= force;
  if (playerLife <= 0) {
    tx = 8;
    ty = 50;
    tz = 8;
    window.yForce = 0;
    playerLife = 1;
  }
}
var gameSettings = {
  mouseWheelSensivity: 40,
  setRenderDistance: distance => {
    renderDistance = distance
  },
  playerSpeed: 0.1
}
var temporaryEffects = [];
function addTemporaryEffect(fn, duration) {
  temporaryEffects.push([fn, duration]);
}
var DA_VARIABLE = 0;
function cleanChunks() {
  for (const position in window.terrainData) {
    if (Object.hasOwnProperty.call(window.terrainData, position)) {
      const chunk = window.terrainData[position];
      for (let i = 0; i < chunks.length; i++) {
        const chunk2 = chunks[i];
        if (chunk == chunk2) continue;
        if (chunk.x == chunk2.x && chunk.y == chunk2.y && chunk.z == chunk2.z) {
          chunks.splice(i--, 1);
        }
      }
    }
  }
}
var renderDistance = 40;
function injectScript(src) {
  var script = document.createElement('script');
  script.src = src;
  document.body.appendChild(script);
}
var fov = 90;
var isTyping = false, typing = "", messages = [];
window.portals = {};
window.portalList = [];
window.waitingPortal = null;
{
  let o = Math.sign;
  Math.sign = function (x) {
    let result = o(x);
    if (result == 0) return -1;
    return result;
  }
}
window.SOME_CONSTANT_WITH_A_SEEMINGLY_RANOM_VALUE = 3.14159265358979;

function distance2d(x1, y1, x2, y2) {
  var dx = x2 - x1, dy = y2 - y1;
  return Math.sqrt(dx * dx + dy * dy);
}
function quickDistance(x1, y1, z1, x2, y2, z2) {
  return (x1 - x2) ** 2 + (y1 - y2) ** 2 + (z1 - z2) ** 2;
}
function detectCollision(o) {
  if(window.DISABLE_REGION_COLLISION){
    for (let i = 0; i < chunks.length; i++) {
      if(chunks[i].detectCollision(o)) return true;
    }
    return false;
  }
  //if(keys.q) return false;
  // if (o.isHuge) {
  for (let i = 0; i < Region.regions.length; i++) {
    /** @type {Region} */
    const region = Region.regions[i];
    if(region.detectCollision(o)){
      for (let j = 0; j < region.chunks.length; j++) {
        if(region.chunks[j].detectCollision(o)) return true;
      }
    }
  }
  // } else {
    // for (var chunk of [
      // terrainData[`${round16(o.x)}/${round16(o.y)}/${round16(o.z)}`],
      // terrainData[`${round16(o.x)}/${round16(o.y) - 16}/${round16(o.z)}`],
      // terrainData[`${round16(o.x)}/${round16(o.y) + 16}/${round16(o.z)}`],
      // terrainData[`${round16(o.x) - 16}/${round16(o.y)}/${round16(o.z)}`],
      // terrainData[`${round16(o.x) + 16}/${round16(o.y)}/${round16(o.z)}`],
      // terrainData[`${round16(o.x)}/${round16(o.y)}/${round16(o.z - 16)}`],
      // terrainData[`${round16(o.x)}/${round16(o.y)}/${round16(o.z + 16)}`],
      // terrainData[`${round16(o.x) - 16}/${round16(o.y) - 16}/${round16(o.z) - 16}`],
      // terrainData[`${round16(o.x) - 16}/${round16(o.y) - 16}/${round16(o.z) + 16}`],
      // terrainData[`${round16(o.x) + 16}/${round16(o.y) - 16}/${round16(o.z) - 16}`],
      // terrainData[`${round16(o.x) + 16}/${round16(o.y) - 16}/${round16(o.z) + 16}`],
      // terrainData[`${round16(o.x) - 16}/${round16(o.y) + 16}/${round16(o.z) - 16}`],
      // terrainData[`${round16(o.x) - 16}/${round16(o.y) + 16}/${round16(o.z) + 16}`],
      // terrainData[`${round16(o.x) + 16}/${round16(o.y) + 16}/${round16(o.z) - 16}`],
      // terrainData[`${round16(o.x) + 16}/${round16(o.y) + 16}/${round16(o.z) + 16}`],
    // ]) {
      // if (chunk && chunk.detectCollision(o)) return true;
    // }
  // }
  return false;
}

window.RAYCAST_MAX = 6;
const PI = Math.PI, TAU = Math.PI * 2;
function realdiff(n1, n2) {
  let simple = Math.abs(n1 - n2);
  //let complex = Math.abs(wrapNumber(n1+PI, -PI, PI, PI)-wrapNumber(n2+PI, -PI, PI, PI));
  let complex2 = Math.abs(wrapNumber(n1 - PI, -PI, PI, PI) - wrapNumber(n2 - PI, -PI, PI, PI));
  return Math.min(simple, Infinity, complex2);
}
function wrapNumber(n, min, max, ntaos) {
  ntaos = ntaos || max;
  while (n < min) n += ntaos;
  while (n > max) n -= ntaos;
  return n;
}
Math.lookAt = function (x1, y1, x2, y2) {
  return Math._direction = Math.atan2(y2 - y1, x2 - x1);
}

function rotate(x, y, z, angle) {
  var initialAngle = Math.lookAt(0, 0, x, z), dist = distance2d(0, 0, x, z);
  angle += initialAngle;
  x = Math.cos(angle) * dist;
  z = Math.sin(angle) * dist;
  return [x, y, z];
}
function rotateVertical(x, y, z, angle) {
  var initialAngle = Math.lookAt(0, 0, y, z), dist = distance2d(0, 0, y, z);
  angle += initialAngle;
  y = Math.cos(angle) * dist;
  z = Math.sin(angle) * dist;
  return [x, y, z];
}
var limited = false;
class Inventory {
  constructor() {
    this.items = {};
  }
  numberOf(type) {
    if (this.items[type]) return this.items[type];
    return 0;
  }
  change(type, number) {
    if (!this.items[type]) this.items[type] = number;
    else this.items[type] += number;
  }
  use(type) {
    if (!this.items[type]) return false;
    else {
      this.items[type]--;
      return true;
    }
  }
  toString() {
    return JSON.stringify(this.items);
  }
  load(s) {
    this.items = JSON.parse(s);
  }
}
var inventory = new Inventory();
var hotbar = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var hotbarSelected = 0;
var glMode = WebGLRenderingContext.prototype.TRIANGLES;
window.AUTO_GENERATE = false;
const $ = document.querySelector.bind(document);
function round16(n) {
  return Math.floor(n / 16) * 16;
}
function roundN(number, n) {
  return Math.floor(number / n) * n;
}
function distance3d(v1, v2) {
  var dx = v1.x - v2.x;
  var dy = v1.y - v2.y;
  var dz = v1.z - v2.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}
window.THROTTLE_TIMEOUT_OVERRIDE = null;
const throttle = (func, limit, limitt) => {
  let inThrottle
  return function () {
    const args = arguments
    const context = this
    if (!inThrottle) {
      func.apply(context, args)
      inThrottle = true
      setTimeout(() => inThrottle = false, limitt || window.THROTTLE_TIMEOUT_OVERRIDE || limit)
    }
  }
}
var horizontalHeading = Math.PI, verticalHeading = 0, selectedType = 1, started_playing = false;
var back_elt = $('#back');
var elt_import = $('#import_textures');
var lastSaveTime = Date.now();
var sin = Math.sin.bind(Math), cos = Math.cos.bind(Math);
var rounding = Math.floor.bind(Math);
var addedListener = false;
const sendDirection = throttle(() => { serverInterface.sendDirection(horizontalHeading, verticalHeading) }, 1000 / 24, 1000 / 24);                                                                                                                                            ;console.log('<h6>'+ atob("Q3JlYXRlZCBieSBBc3Ryb2lkZSAoaHR0cHM6Ly9yZXBsaXQuY29tL0BBU1RST0lERSksIG9yaWdpbmFsIHZlcnNpb24gPGEgaHJlZj0iLy9yZXBsaXQuY29tL0BBU1RST0lERS9Wb3hlbDNEIj5oZXJlPC9hPg==")+'</h6>');
document.addEventListener('click', (e) => {
  if (document.pointerLockElement || window.prompting || back_elt.contains(e.target) || e.target == accountDiv)
    return;
  /** @type {HTMLCanvasElement} */
  const canvas = $('#webgl');
  /** @type {HTMLCanvasElement} */
  const postProcessingCanvas = $('#canvas');
  // window.postProcessingCanvas = postProcessingCanvas;
  if (!inventoryOpen)
    postProcessingCanvas.requestPointerLock();
  started_playing = true;
  if (!addedListener)
    postProcessingCanvas.addEventListener('mousemove', e => {
      if (!document.pointerLockElement)
        return;
      horizontalHeading -= e.movementX * (Math.PI / 360);
      verticalHeading -= e.movementY * Math.PI / 360;
      verticalHeading = Math.max(Math.PI / -2, verticalHeading);
      verticalHeading = Math.min(Math.PI / 2, verticalHeading);
      //horizontalHeading = horizontalHeading - Math.PI*2 * Math.floor((horizontalHeading + Math.PI) / Math.PI*2);
      horizontalHeading = wrapNumber(horizontalHeading, -Math.PI, Math.PI, Math.PI * 2);
      if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED)
        sendDirection();
    });
  addedListener = true;
});
function lineCollision(coord1, width1, coord2, width2) {
  //Determines if the lines defined by coord1/width1 and coord1/width1 collide.
  if ((coord1 >= coord2 && coord1 <= coord2 + width2) || (coord2 >= coord1 && coord2 <= coord1 + width1)) return true;
  else return false;
}

function squareCollision(x1, y1, w1, h1, x2, y2, w2, h2) {
  //Determines if two rectangles collide.
  if (lineCollision(x1, w1, x2, w2) && lineCollision(y1, h1, y2, h2)) return true;
  else return false;
}

function cubeCollision(x1, y1, z1, w1, h1, d1, x2, y2, z2, w2, h2, d2) {
  return lineCollision(z1, d1, z2, d2) && squareCollision(x1, y1, w1, h1, x2, y2, w2, h2);
}

function cubeCollision2(o1, o2) {
  return lineCollision(o1.z, o1.depth, o2.z, o2.depth) && squareCollision(o1.x, o1.y, o1.width, o1.height, o2.x, o2.y, o2.width, o2.height);
}
/* <Block configuration> */
var blockNumber = 21;
var inventoryMaps = {
  20: [1.5, 0, 1.6, 0.25].map(x => x / 2)
}
var texmaps = {
  "J": [0, 0.75, 0.25, 1.0].map(x => x / 2), // J
  "bark": [0, 0.5, 0.25, 0.75].map(x => x / 2),
  "bark-birch": [0.25, 0.5, 0.5, 0.75].map(x => x / 2),
  1: [0, 0, 0.25, 0.25].map(x => x / 2), // Red
  2: [0, 0.25, 0.25, 0.5].map(x => x / 2), // Grass
  3: [0.25, 0, 0.5, 0.25].map(x => x / 2), // Blue
  4: [0.25, 0.25, 0.5, 0.5].map(x => x / 2), // Glass
  5: [0.5, 0, 0.75, 0.25].map(x => x / 2), // Leaves
  6: [0.5, 0.25, 0.75, 0.5].map(x => x / 2), // Wood (brown)
  7: [0.75, 0, 1, 0.25].map(x => x / 2), // Blue stone
  8: [0.75, 0.25, 1, 0.5].map(x => x / 2), // Wood (birch)
  9: [0.5, 0.5, 0.75, 0.75].map(x => x / 2), // Black
  10: [0.75, 0.5, 1, 0.75].map(x => x / 2), // Dark red
  11: [0.25, 0.75, 0.5, 1].map(x => x / 2), // Brick
  12: [0.5, 0.75, 0.75, 1].map(x => x / 2), // Sand
  13: [0.75, 0.75, 1, 1].map(x => x / 2), // Magic
  14: [1, 0, 1.25, 0.25].map(x => x / 2), // Stone
  15: [1, 0.25, 1.25, 0.5].map(x => x / 2), // Snow
  16: [1, 0.5, 1.25, 0.75].map(x => x / 2), // Conductor
  17: [1, 0.75, 1.25, 1].map(x => x / 2), // Emitter
  18: [1.25, 0, 1.5, 0.25].map(x => x / 2), // Arrow thrower
  "potion": [1.25, 0.25, 1.5, 0.5].map(x => x / 2),
  "carrot": [1.25, 0.5, 1.5, 0.75].map(x => x / 2),
  19: [1.25, 0.75, 1.5, 1].map(x => x / 2), // Earth
  20: [1.7, 0, 1.75, 0.25].map(x => x / 2), // Water
};
for (var i = 1; i < blockNumber; i++) {
  var thing = texmaps[i];
  thing[0] += 0.001;
  thing[1] += 0.001;
  thing[2] -= 0.001;
  thing[3] -= 0.001;
}
/* </Block configuration> */
var glyphs = {
  "a": [0, 0, 5 / 32, 7 / 32],
  "b": [5 / 32, 0, 10 / 32, 7 / 32],
  "c": [10 / 32, 0, 15 / 32, 7 / 32],
  "d": [15 / 32, 0, 20 / 32, 7 / 32],
  "e": [20 / 32, 0, 25 / 32, 7 / 32],
  "f": [25 / 32, 0, 30 / 32, 7 / 32],
  "g": [0, 7 / 32, 5 / 32, 14 / 32],
  "h": [5 / 32, 7 / 32, 10 / 32, 14 / 32],
  "i": [10 / 32, 7 / 32, 15 / 32, 14 / 32],
  "j": [15 / 32, 7 / 32, 20 / 32, 14 / 32],
  "k": [20 / 32, 7 / 32, 25 / 32, 14 / 32],
  "l": [25 / 32, 7 / 32, 30 / 32, 14 / 32],
  "m": [0, 14 / 32, 5 / 32, 21 / 32],
  "n": [5 / 32, 14 / 32, 10 / 32, 21 / 32],
  "o": [10 / 32, 14 / 32, 15 / 32, 21 / 32],
  "p": [15 / 32, 14 / 32, 20 / 32, 21 / 32],
  "q": [20 / 32, 14 / 32, 25 / 32, 21 / 32],
  "r": [25 / 32, 14 / 32, 30 / 32, 21 / 32],
  "s": [0, 21 / 32, 5 / 32, 28 / 32],
  "t": [5 / 32, 21 / 32, 10 / 32, 28 / 32],
  "u": [10 / 32, 21 / 32, 15 / 32, 28 / 32],
  "v": [15 / 32, 21 / 32, 20 / 32, 28 / 32],
  "w": [5 / 32, 21 / 32, 0, 14 / 32],
  "x": [20 / 32, 21 / 32, 25 / 32, 28 / 32],
  "y": [15 / 32, 21 / 32, 20 / 32, 31 / 32],
  "z": [5 / 32, 21 / 32, 0, 28 / 32],
  "_": [25 / 32, 21 / 32, 30 / 32, 28 / 32],
  "void": [31 / 32, 31 / 32, 31 / 32, 31 / 32],
};
Array.prototype.forEach.call('qwertyuiopasdfghjklzxcvbnm_', letter => {
  [glyphs[letter][0], glyphs[letter][2]] = [glyphs[letter][2], glyphs[letter][0]];
  [glyphs[letter][1], glyphs[letter][3]] = [glyphs[letter][3], glyphs[letter][1]];
});
var playerTexcoords = {
  "headTop": [3 * 3, 4 * 3, 7 * 3, 8 * 3],
  "headSide": [11 * 3, 0, 7 * 3, 4 * 3],
  "headFront": [7 * 3, 4 * 3, 3 * 3, 0],
  "headBack": [7 * 3, 8 * 3, 11 * 3, 4 * 3],
  "leg": [1 * 3, 0, 2 * 3, 5 * 3],
  "arm": [2 * 3, 0, 3 * 3, 5 * 3],
  "foot": [1 * 3, 5 * 3, 2 * 3, 6 * 3],
  "hand": [2 * 3, 5 * 3, 3 * 3, 6 * 3],
  "body": [0, 8 * 3, 4 * 3, 15 * 3]
}
var LAVA = 1;
var GRASS = 2;
var BLUE = 3;
var GLASS = 4;
var FOLIAGE = 5;
var WOOD = 6;
var BLUE_STONE = 7;
var WOOD_BIRCH = 8;
var BLACK_STONE = 9;
var RED = 10;
var BRICK = 11;
var SAND = 12;
var MAGIC = 13;
var GREY_STONE = 14;
var SNOW = 15;
var CONDUCTOR = 16;
var EMITTER = 17;
var ARROW_THROWER = 18;
var EARTH = 19;
var WATER = 20;
function meow(x, y, z) {
  let gb = getBlockFast;
  if (gb(x, y, z) == MAGIC) {
    var isPortal = false;
    // PORTAL DETECTION
    // Horizontal
    if (getBlockFast(x - 1, y, z) == BLACK_STONE && getBlockFast(x + 1, y, z) == BLACK_STONE && getBlockFast(x, y, z - 1) == BLACK_STONE && getBlockFast(x, y, z + 1) == BLACK_STONE && getBlockFast(x - 1, y, z - 1) == BLACK_STONE && getBlockFast(x - 1, y, z + 1) == BLACK_STONE && getBlockFast(x + 1, y, z - 1) == BLACK_STONE && getBlockFast(x + 1, y, z + 1) == BLACK_STONE) isPortal = true;
    // Vertical (x aligned)
    else if (getBlockFast(x - 1, y, z) == BLACK_STONE && getBlockFast(x + 1, y, z) == BLACK_STONE && getBlockFast(x, y - 1, z) == BLACK_STONE && getBlockFast(x, y + 1, z) == BLACK_STONE && getBlockFast(x - 1, y - 1, z) == BLACK_STONE && getBlockFast(x - 1, y + 1, z) == BLACK_STONE && getBlockFast(x + 1, y - 1, z) == BLACK_STONE && getBlockFast(x + 1, y + 1, z) == BLACK_STONE) isPortal = true;
    // Vertical (z aligned)
    else if (getBlockFast(x, y, z - 1) == BLACK_STONE && getBlockFast(x, y, z + 1) == BLACK_STONE && getBlockFast(x, y - 1, z) == BLACK_STONE && getBlockFast(x, y + 1, z) == BLACK_STONE && getBlockFast(x, y - 1, z - 1) == BLACK_STONE && getBlockFast(x, y + 1, z - 1) == BLACK_STONE && getBlockFast(x, y - 1, z + 1) == BLACK_STONE && getBlockFast(x, y + 1, z + 1) == BLACK_STONE) isPortal = true;
    if (!isPortal) return;
    if (!waitingPortal) {
      window.waitingPortal = {
        x: x,
        y: y,
        z: z,
        str: `${x}/${y}/${z}`
      }
    } else {
      let other = waitingPortal;
      let str = `${x}/${y}/${z}`;
      window.waitingPortal = null;
      window.portalList.push(str);
      window.portalList.push(other.str);
      window.portals[str] = [other.x, other.y, other.z];
      window.portals[other.str] = [x, y, z];
      if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) serverInterface.createPortals(str, portals[str], other.str, portals[other.str]);
    }
  } else
    if ((gb(x, y - 1, z) == LAVA || gb(x, y - 1, z) == BLUE || gb(x, y - 1, z) == WOOD || gb(x, y - 1, z) == MAGIC) && gb(x - 1, y, z) == BRICK && gb(x + 1, y, z) == BRICK && gb(x, y, z - 1) == BRICK && gb(x, y, z + 1) == BRICK) {
      if (gb(x, y - 1, z) == LAVA) {
        switch (gb(x, y, z)) {
          case SAND:
            setBlock(x, y, z, GLASS);
            break;
          case LAVA:
            setBlock(x, y, z, RED);
            break;
          case RED:
            setBlock(x, y, z, BLACK_STONE);
            break;
          case BLACK_STONE:
            if (gb(x, y + 2, z)) {
              setBlock(x, y, z, MAGIC);
              setBlock(x, y + 2, z, 0);
            }
          default:
            console.log('?');
            break;
        }
      } else if (gb(x, y - 1, z) == BLUE) {
        switch (gb(x, y, z)) {
          case SAND:
            setBlock(x, y, z, GLASS);
            break;
          case LAVA:
            setBlock(x, y, z, RED);
            break;
          case RED:
            setBlock(x, y, z, BLACK_STONE);
            break;
          default:
            console.log('?');
            break;
        }
      } else {
        switch (gb(x, y, z)) {
          case WOOD_BIRCH:
            setBlock(x, y, z, 0);
            if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) {
              serverInterface.createAnimal('squirrel', x, y, z);
              return;
            }
            animals.squirrels.push(new Squirrel(x + 0.5, y + 0.5, z + 0.5));
            if (Math.random() > 0.9) animals.squirrels[animals.squirrels.length - 1].sqrl = true;
            break;
          case FOLIAGE:
            setBlock(x, y, z, 0);
            if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) {
              serverInterface.createAnimal('bird', x, y, z);
              return;
            }
            animals.birds.push(new Bird(x + 0.5, y + 0.5, z + 0.5));
            break;
          case GRASS:
            setBlock(x, y, z, 0);
            if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) {
              serverInterface.createAnimal('horse', x, y, z);
              return;
            }
            animals.horses.push(new Horse(x + 0.5, y + 0.5, z + 0.5));
            break;
          default:
            console.log('?');
            break;
        }
      }
    }
  if (getBlockFast(x, y, z) == LAVA) {
    //if(window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) serverInterface.pulse(x, y, z);
    if (getBlockFast(x + 1, y, z) == CONDUCTOR) {
      new ActivatedBox(x + 1, y, z);
    }
    if (getBlockFast(x - 1, y, z) == CONDUCTOR) {
      new ActivatedBox(x - 1, y, z);
    }
    if (getBlockFast(x, y + 1, z) == CONDUCTOR) {
      new ActivatedBox(x, y + 1, z);
    }
    if (getBlockFast(x, y - 1, z) == CONDUCTOR) {
      new ActivatedBox(x, y - 1, z);
    }
    if (getBlockFast(x, y, z + 1) == CONDUCTOR) {
      new ActivatedBox(x, y, z + 1);
    }
    if (getBlockFast(x, y, z - 1) == CONDUCTOR) {
      new ActivatedBox(x, y, z - 1);
    }
  }
  if (getBlockFast(x, y, z) == EMITTER) {
    window.objects.signalEmitters.push(new SignalEmitter(x, y, z));
  }
}
var texcoords = new Float32Array([
  0.0, 0.0,
  0.5, 0.5,
  0.5, 0.0,
  0.0, 0.0,
  0.5, 0.5,
  0.0, 0.5,
  0.0, 0.0,
  0.5, 0.5,
  0.5, 0.0,
  0.0, 0.0,
  0.5, 0.5,
  0.0, 0.5
].map(x => x * 2));
var positionArray = [];
//var tx=510,ty=510,tz=132;
var tx = 8, ty = 50, tz = 8;
function texCube(x1, y1, x2, y2) {
  return [
    x1, y1,
    x2, y1,
    x1, y2,

    x1, y2,
    x2, y1,
    x2, y2,

    x1, y1,
    x1, y2,
    x2, y1,

    x1, y2,
    x2, y2,
    x2, y1,

    x1, y1,
    x1, y2,
    x2, y2,

    x1, y1,
    x2, y2,
    x2, y1,

    x1, y2,
    x1, y1,
    x2, y2,

    x2, y2,
    x1, y1,
    x2, y1,
    // *()*
    x1, y1,
    x2, y2,
    x2, y1,

    x1, y1,
    x1, y2,
    x2, y2,

    x1, y1,
    x2, y1,
    x2, y2,

    x1, y1,
    x2, y2,
    x1, y2
  ]

}
function texCube2(x1, y1, x2, y2, xx1, yy1, xx2, yy2) {
  return [
    xx1, yy1, //Front
    xx2, yy1,
    xx1, yy2,

    xx1, yy2,
    xx2, yy1,
    xx2, yy2,

    xx1, yy1,//Back
    xx1, yy2,
    xx2, yy1,

    xx1, yy2,
    xx2, yy2,
    xx2, yy1,

    x1, y1,//Down
    x1, y2,
    x2, y2,

    x1, y1,
    x2, y2,
    x2, y1,

    x1, y2,//Up
    x1, y1,
    x2, y2,

    x2, y2,
    x1, y1,
    x2, y1,
    // *()*
    xx1, yy2,//Left
    xx2, yy1,
    xx2, yy2,

    xx1, yy2,
    xx1, yy1,
    xx2, yy1,

    xx1, yy2,//Right
    xx2, yy2,
    xx2, yy1,

    xx1, yy2,
    xx2, yy1,
    xx1, yy1
  ]

}
// 00 -> 01 -> 11
// 00 -> 10 -> 11
function coordCube(x, y, z, w, h, d) {
  return [
    x, y, z + d,      //Front
    x + w, y, z + d,
    x, y + h, z + d,

    x, y + h, z + d,
    x + w, y, z + d,
    x + w, y + h, z + d,


    x, y, z,    //Back
    x, y + h, z,
    x + w, y, z,

    x, y + h, z,
    x + w, y + h, z,
    x + w, y, z,


    x, y + h, z,      //Down
    x, y + h, z + d,
    x + w, y + h, z + d,

    x, y + h, z,
    x + w, y + h, z + d,
    x + w, y + h, z,


    x, y, z + d,  //Up
    x, y, z,
    x + w, y, z + d,

    x + w, y, z + d,
    x, y, z,
    x + w, y, z,


    x, y, z,      //Left
    x, y + h, z + d,
    x, y + h, z,

    x, y, z,
    x, y, z + d,
    x, y + h, z + d,


    x + w, y, z,    //Right
    x + w, y + h, z,
    x + w, y + h, z + d,

    x + w, y, z,
    x + w, y + h, z + d,
    x + w, y, z + d
  ];
}
function magicCube(x, y, z, w, h, d, up, down, left, right, front, back) {
  return [
    ...(back ? [x, y, z + d,      //Front
      x + w, y, z + d,
      x, y + h, z + d,

      x, y + h, z + d,
      x + w, y, z + d,
      x + w, y + h, z + d] : []),


    ...(front ? [x, y, z,    //Back
      x, y + h, z,
      x + w, y, z,

      x, y + h, z,
      x + w, y + h, z,
      x + w, y, z] : []),


    ...(up ? [x, y + h, z,      //Down
      x, y + h, z + d,
      x + w, y + h, z + d,

      x, y + h, z,
      x + w, y + h, z + d,
      x + w, y + h, z] : []),


    ...(down ? [x, y, z + d,  //Up
      x, y, z,
      x + w, y, z + d,

      x + w, y, z + d,
      x, y, z,
      x + w, y, z] : []),


    ...(right ? [x, y, z,      //Left
      x, y + h, z + d,
      x, y + h, z,

      x, y, z,
      x, y, z + d,
      x, y + h, z + d] : []),


    ...(left ? [x + w, y, z,    //Right
    x + w, y + h, z,
    x + w, y + h, z + d,

    x + w, y, z,
    x + w, y + h, z + d,
    x + w, y, z + d] : [])
  ];
}
function texQuad(a, b, c, d) {
  return [
    a, b,
    a, d,
    c, d,
    a, b,
    c, d,
    c, b
  ];
}
function coordQuad(x, y, z, w, h) {
  return [
    x, y, z,
    x, y + h, z,
    x + w, y + h, z,
    x, y, z,
    x + w, y + h, z,
    x + w, y, z
  ];
}
texcoords = texCube(0.5, 0.5, 1, 1);
positionArray = coordCube(-1, -1, -1, 2, 2, 2);
function isTransparent(x, l) {
  return (!x) || x == GLASS || x == FOLIAGE || x == MAGIC || x == WATER;
}
function isVisible(data, x, y, z) {
  if (x == 0 || y == 0 || z == 0 || x == 15 || y == 15 || z == 15) return true;
  return isTransparent(data[((x - 1) * 256) + (y * 16) + z]) || isTransparent(data[((x + 1) * 256) + (y * 16) + z]) || isTransparent(data[(x * 256) + ((y - 1) * 16) + z]) || isTransparent(data[(x * 256) + ((y + 1) * 16) + z]) || isTransparent(data[(x * 256) + (y * 16) + (z - 1)]) || isTransparent(data[(x * 256) + (y * 16) + (z + 1)]);
}
/**
 * 
 * @param {Uint8Array} visibilityArray 
 * @param {Uint8Array} blockArray 
 */
function updateVisibility(visibilityArray, blockArray) {
  for (var x = 0; x < 16; x++) {
    for (var y = 0; y < 16; y++) {
      for (var z = 0; z < 16; z++) {
        visibilityArray[(x * 256) + (y * 16) + z] = +isVisible(blockArray, x, y, z);
      }
    }
  }
}
function chunkToPositionBuffer(data, tx, ty, tz, visibility) {
  //console.time('ctpb');
  var returnArray = [];
  for (var x = 0; x < 16; x++) {
    for (var y = 0; y < 16; y++) {
      for (var z = 0; z < 16; z++) {
        if (data[(x * 256) + (y * 16) + z] && visibility[(x * 256) + (y * 16) + z])
          returnArray.push(...coordCube((x + tx), (y + ty), (z + tz), 1, 1, 1));
      }
    }
  }
  //console.timeEnd('ctpb');
  return new Float32Array(returnArray);
}
function chunkToTexCoordBuffer(data, visibility) {
  //console.time('cttcb');
  var returnArray = [];
  for (var x = 0; x < 16; x++) {
    for (var y = 0; y < 16; y++) {
      for (var z = 0; z < 16; z++) {
        if (data[(x * 256) + (y * 16) + z] && visibility[(x * 256) + (y * 16) + z])
          returnArray.push(...((data[(x * 256) + (y * 16) + z] == 6) ? texCube2(...texmaps[6], ...texmaps["bark"]) : (data[(x * 256) + (y * 16) + z] == 8) ? texCube2(...texmaps[8], ...texmaps["bark-birch"]) : texCube(...texmaps[data[(x * 256) + (y * 16) + z]])));
      }
    }
  }
  //console.timeEnd('cttcb');
  return new Float32Array(returnArray);
}
/** @returns {number} */
function chunk_xyz(x, y, z) {
  return (Math.min(Math.max(x, 0), 15) * 256) + (Math.min(y, 15) * 16) + Math.min(Math.max(z, 0), 15);
}
var blockTypes = {
  "0": [7, 1, 2, 4],
  "1": [7, 12, 12, 4],
  "2": [11, 7, 9, 10],
  "3": [6, 8, 5, 16],
  "4": [2, 8, 5, 4],
  "5": [10, 10, 4, 16]
}
function repeatArray(array, number) {
  var returnArray = [];
  while (returnArray.length < number) {
    returnArray.push(...array);
  }
  return returnArray
}
var terrainData = {};
class Region {
  constructor(x, z){
    this.x = x;
    this.z = z;
    this.chunks = [];
    Region.regionMap[`${x}/${z}`] = this;
    Region.regions.push(this);
  }
  addChunk(c){
    this.chunks.push(c);
  }
  detectCollision(o){
    return squareCollision(o.x, o.z, o.w, o.d, this.x, this.z, 16*8, 16*8);
  }
  /**
   * 
   * @param {number} x 
   * @param {number} z 
   * @returns {Region}
   */
  static findRegion(x, z){
    x = roundN(x, 16*8);
    z = roundN(z, 16*8);
    return Region.regionMap[`${x}/${z}`] || new Region(x, z);
  }
}
Region.regionMap = {};
Region.regions = [];
class Chunk {
  /** @param {WebGLRenderingContext} gl */
  constructor(gl, x, y, z, type, rnd) {
    this.width = 16;
    this.height = 16;
    this.depth = 16;
    this.special = 0;
    terrainData[`${x}/${y}/${z}`] = this;
    this.data = new Uint8Array(16 * 16 * 16);
    this.visible = new Uint8Array(16 * 16 * 16);
    this.waterMesh = {};
    this.waterBuffers = {
      coords: gl.createBuffer(),
      texcoords: gl.createBuffer()
    }
    for (var i = 0; i < 4096; i++) {
      this.visible[i] = 0;
    }
    //console.time('chunk');
    if (type == "special") {
      var t = rnd || Math.random();
      if (t >= 0.5) this.special = 0;
      else if (t >= 0.25) this.special = 1;
      else this.special = 2;
      type = null;
    }
    if (type == "special-top") {
      var t = rnd || Math.random();
      if (t >= 0.5) this.special = 3;
      else if (t >= 0.25) this.special = 4;
      else this.special = 5;
      type = true;
    }
    if (!type) {
      for (var i = 0; i < this.data.length; i++) {
        this.data[i] = Math.random() > 0.05 ? blockTypes[this.special][0] : blockTypes[this.special][1];//Math.floor  (Math.random() * 5);
      }
      for (let x = 0, y = 15; x < 16; x++) {
        for (let z = 0; z < 16; z++) {
          this.data[(x * 256) + (y * 16) + z] = blockTypes[this.special][2];
        }
      }
      for (let x = 0, y = 0; x < 16; x++) {
        for (let z = 0; z < 16; z++) {
          this.data[(x * 256) + (y * 16) + z] = blockTypes[this.special][3];
        }
      }
      var tunnel = { x: Math.floor(Math.random() * 16), y: 15, z: Math.floor(Math.random() * 16) };
      this.data[chunk_xyz(tunnel.x, tunnel.y, tunnel.z)] = 3;
      var tunnel_direction = -1;
      while (tunnel_direction > 0 ? (tunnel.y < 15) : (tunnel.y > 1)) {
        tunnel.y += (Math.round(Math.random() - 0.25)) * tunnel_direction;
        var isX = Math.random() > 0.5;
        if (isX) {
          tunnel.x += Math.sign(Math.random() - 0.5);
          tunnel.x = Math.min(Math.max(0, tunnel.x), 15);
        } else {
          tunnel.z += Math.sign(Math.random() - 0.5);
          tunnel.z = Math.min(Math.max(0, tunnel.z), 15);
        }
        this.data[chunk_xyz(tunnel.x, tunnel.y, tunnel.z)] = 0;
        this.data[chunk_xyz(tunnel.x - 1, tunnel.y, tunnel.z)] = 0;
        this.data[chunk_xyz(tunnel.x, tunnel.y, tunnel.z + 1)] = 0;
        this.data[chunk_xyz(tunnel.x, tunnel.y - tunnel_direction, tunnel.z)] = 0;
        if (tunnel.y == 1) tunnel_direction = 1;
      }
    } else if (type == "empty") {
      for (var i = this.data.length - 1; i >= 0; i--) {
        this.data[i] = 0;
      }
    } else {
      if (!this.special) this.special = 3;
      for (var i = 0; i < 5; i++) {
        let color = Math.random() > 0.5 ? blockTypes[this.special][0] : blockTypes[this.special][1];
        let x = Math.floor(Math.random() * 16), z = Math.floor(Math.random() * 16), y = 0;
        while (Math.random() > 0.3 && y < blockTypes[this.special][3]) {
          this.data[chunk_xyz(x, y, z)] = color;
          this.data[chunk_xyz(x - 1, y, z)] = blockTypes[this.special][2];
          this.data[chunk_xyz(x + 1, y, z)] = blockTypes[this.special][2];
          this.data[chunk_xyz(x, y, z + 1)] = blockTypes[this.special][2];
          this.data[chunk_xyz(x, y, z - 1)] = blockTypes[this.special][2];
          y++;
          if (Math.random() > 0.5) {
            x += Math.sign(Math.random() - 0.5);
          } else z += Math.sign(Math.random() - 0.5);
        }
        this.data[chunk_xyz(x, y, z)] = blockTypes[this.special][2];
      }
    }
    this.positionBuffer = gl.createBuffer();
    this.texCoordBuffer = gl.createBuffer();
    this.hasWater = false;
    this.updateBuffer = true;
    this.x = x;
    this.y = y;
    this.z = z;
    Region.findRegion(this.x, this.z).addChunk(this);
  }
  /** @param {Object} obj
   * @param {number} obj.x
   * @param {number} obj.y
   * @param {number} obj.z
   * @param {number} obj.width
   * @param {number} obj.height
   * @param {number} obj.depth
   */
  detectCollision(obj) {
    if (!cubeCollision(obj.x, obj.y, obj.z, obj.width, obj.height, obj.depth, this.x, this.y, this.z, 16, 16, 16)) return false;
    var x = 0, y = 0, z = 0;
    for (x = 0; x < 16; x++) {
      for (y = 0; y < 16; y++) {
        for (z = 0; z < 16; z++) {
          if (this.data[(x * 256) + (y * 16) + z] && this.visible[(x * 256) + (y * 16) + z] && !(this.data[(x * 256) + (y * 16) + z] == MAGIC) && !(this.data[(x * 256) + (y * 16) + z] === (WATER)) && cubeCollision(obj.x, obj.y, obj.z, obj.width, obj.height, obj.depth, this.x + x, this.y + y, this.z + z, 1, 1, 1)) return true;
        }
      }
    }
    return false;
  }
  updateWater() {
    this.hasWater = false;
    for (var i = 0; i < this.data.length; i++) {
      if (this.data[i] == WATER) {
        this.hasWater = true;
        break;
      }
    }
    this.waterMesh = {
      texcoords: [],
      coords: []
    };
    for (var x = 0; x < 16; x++) {
      for (var y = 0; y < 16; y++) {
        for (var z = 0; z < 16; z++) {
          if (this.data[(x * 256) + (y * 16) + z] == WATER) {
            var cubeCoords = magicCube(x + this.x, y + this.y, z + this.z, 1, 1, 1,/*  Math.round(Math.random()), Math.round(Math.random()), Math.round(Math.random()), Math.round(Math.random()), Math.round(Math.random()), Math.round(Math.random())); */
              (y == 15 ? (getBlockFast(this.x + x, this.y + y + 1, this.z + z) != WATER) : (this.data[(x * 256) + ((y + 1) * 16) + z] != WATER)) && (y == 15 ? isTransparent(getBlockFast(this.x + x, this.y + y + 1, this.z + z)) : isTransparent(this.data[(x * 256) + ((y + 1) * 16) + z])),
              (y == 0 ? (getBlockFast(this.x + x, this.y + y - 1, this.z + z) != WATER) : (this.data[(x * 256) + ((y - 1) * 16) + z] != WATER)) && (y == 0 ? isTransparent(getBlockFast(this.x + x, this.y + y - 1, this.z + z)) : isTransparent(this.data[(x * 256) + ((y - 1) * 16) + z])),
              (x == 15 ? (getBlockFast(this.x + x + 1, this.y + y, this.z + z) != WATER) : (this.data[((x + 1) * 256) + ((y) * 16) + z] != WATER)) && (x == 15 ? isTransparent(getBlockFast(this.x + x + 1, this.y + y, this.z + z)) : isTransparent(this.data[((x + 1) * 256) + ((y) * 16) + z])),
              (x == 0 ? (getBlockFast(this.x + x - 1, this.y + y, this.z + z) != WATER) : (this.data[((x - 1) * 256) + ((y) * 16) + z] != WATER)) && (x == 0 ? isTransparent(getBlockFast(this.x + x - 1, this.y + y, this.z + z)) : isTransparent(this.data[((x - 1) * 256) + ((y) * 16) + z])),
              (z == 0 ? (getBlockFast(this.x + x, this.y + y, this.z + z - 1) != WATER) : (this.data[((x) * 256) + ((y) * 16) + z - 1] != WATER)) && (z == 0 ? isTransparent(getBlockFast(this.x + x, this.y + y, this.z + z - 1)) : isTransparent(this.data[((x) * 256) + ((y) * 16) + z - 1])),
              (z == 15 ? (getBlockFast(this.x + x, this.y + y, this.z + z + 1) != WATER) : (this.data[((x) * 256) + ((y) * 16) + z + 1] != WATER)) && (z == 15 ? isTransparent(getBlockFast(this.x + x, this.y + y, this.z + z + 1)) : isTransparent(this.data[((x) * 256) + ((y) * 16) + z + 1])));
            this.waterMesh.coords.push(...cubeCoords);
          }
        }
      }
    }
    this.waterMesh.texcoords.push(...repeatArray([texmaps[WATER][0] - 0.1, texmaps[WATER][1] - 0.1], this.waterMesh.coords.length / 1.5));
    this.waterMesh.coords = Float32Array.from(this.waterMesh.coords);
    this.waterMesh.texcoords = Float32Array.from(this.waterMesh.texcoords);
  }
  /** @param {WebGLRenderingContext} gl */
  draw(gl, positionLocation, texCoordLocation) {
    var temporary;
    if (this.updateBuffer && !this.needsUpdate) {
      updateVisibility(this.visible, this.data);
      this.needsUpdate = true;
      this.updateBuffer = false;
    }
    if (
      /* Far objects hidden by fog */
      distance3d(this, { x: tx, y: ty, z: tz }) > ((renderDistance - 8) + 16 * Math.SQRT2) ||
      (
        /* Don't draw objects in back of the camera */
        // realdiff(Math.lookAt(tx, tz, this.x+8, this.z+8),horizontalHeading+Math.PI)<Math.PI/2
        0
        //Math.random() > 0.5
      )) return;
    //console.log(distance3d(this, {x:tx,y:ty,z:tz}), (32+16*Math.SQRT2));
    gl.bindBuffer(gl.ARRAY_BUFFER, this.positionBuffer);
    if (this.needsUpdate) {
      updateVisibility(this.visible, this.data);
      this.updateWater();
      this.positiondata = chunkToPositionBuffer(this.data, this.x, this.y, this.z, this.visible);
      gl.bufferData(gl.ARRAY_BUFFER, this.positiondata, gl.STATIC_DRAW);
    }

    gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLocation);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer);
    if (this.needsUpdate) {
      this.texdata = chunkToTexCoordBuffer(this.data, this.visible);
      gl.bufferData(gl.ARRAY_BUFFER, this.texdata, gl.STATIC_DRAW);
      this.needsUpdate = false;
    }

    gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(texCoordLocation);
    //throw new Error('Ratio');
    if (this.texdata.length)
      gl.drawArrays(glMode, 0, this.texdata.length / 2);
    if (this.hasWater) {
      let self = this
      onDrawEnd(() => {
        // ondrawend.push(function(){
        // console.log('WAATER', self, waveLocation, positionLocation, texCoordLocation);
        gl.uniform1i(waveLocation, 1);
        gl.disable(gl.CULL_FACE);
        gl.bindBuffer(gl.ARRAY_BUFFER, self.waterBuffers.coords);
        gl.bufferData(gl.ARRAY_BUFFER, self.waterMesh.coords, gl.STATIC_DRAW);
        gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(positionLocation);
        gl.bindBuffer(gl.ARRAY_BUFFER, self.waterBuffers.texcoords);
        gl.bufferData(gl.ARRAY_BUFFER, self.waterMesh.texcoords, gl.STATIC_DRAW);
        gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(texCoordLocation);
        if (self.waterMesh.texcoords.length)
          gl.drawArrays(glMode, 0, self.waterMesh.texcoords.length / 2);
        gl.enable(gl.CULL_FACE);
        gl.uniform1i(waveLocation, 0);
        // });
      });
    }
  }
}
([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]][([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]((!![]+[])[+!+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+([][[]]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+!+[]]+(+[![]]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+!+[]]]+(!![]+[])[!+[]+!+[]+!+[]]+(+(!+[]+!+[]+!+[]+[+!+[]]))[(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([]+[])[([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]][([][[]]+[])[+!+[]]+(![]+[])[+!+[]]+((+[])[([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]+[])[+!+[]+[+!+[]]]+(!![]+[])[!+[]+!+[]+!+[]]]](!+[]+!+[]+!+[]+[!+[]+!+[]])+(![]+[])[+!+[]]+(![]+[])[!+[]+!+[]])()(([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[!+[]+!+[]+!+[]]))[Array(..."gol").reverse().join('')](atob("Q29weXJpZ2h0IDIwMjAgT2xpZSBBdWdlciA8b2xpZS5hdWdlckBnbWFpbC5jb20+IGh0dHBzOi8vcmVwbGl0LmNvbS9AQVNUUk9JREU="));
/*function drawChunks(gl, positionLocation, texCoordLocation){
  if(!drawChunks.coordBuffer){
    drawChunks.coordBuffer = gl.createBuffer();
  }
  if(!drawChunks.texcoordBuffer){
    drawChunks.texcoordBuffer = gl.createBuffer();
  }
  for (var i = 0; i < chunks.length; i++) {
    if(chunks[i].updateBuffer){
      drawChunks.coords = [];
      drawChunks.texcoords = [];
      for (var j = 0; j < chunks.length; j++) {
        chunks[i].updateBuffer = false;
        drawChunks.coords.push(...chunkToPositionBuffer(chunks[i].data, chunks[i].x,chunks[i].y,chunks[i].z));
        drawChunks.texcoords.push(...chunkToTexCoordBuffer(chunks[i].data, chunks[i].x,chunks[i].y,chunks[i].z));
      }
      gl.bindBuffer(drawChunks.coordBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, drawChunks.coords, gl.STATIC_DRAW);
      gl.bindBuffer(drawChunks.texcoordBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, drawChunks.texcoords, gl.STATIC_DRAW);
    }
  }

}*/
function setTexture(tx) {
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, tx);
  var ext = (
    gl.getExtension('EXT_texture_filter_anisotropic') ||
    gl.getExtension('MOZ_EXT_texture_filter_anisotropic') ||
    gl.getExtension('WEBKIT_EXT_texture_filter_anisotropic')
  );
  if (ext && null) {
    console.log('anisotropic on')
    var max = gl.getParameter(ext.MAX_TEXTURE_MAX_ANISOTROPY_EXT);
    gl.texParameterf(gl.TEXTURE_2D, ext.TEXTURE_MAX_ANISOTROPY_EXT, max);
  }
}
/**
 * Add coordinates and texture coordinates into `coords` and `texcoords`, using data form `playerList`
 * @param {({x: number, y: number, z: number, width: number, height: number, orientation: {vertical: number, horizontal: number}} | Person)[]} playerList List of player objects
 * @param {number[]} coords Array in which to put the coordinates
 * @param {number[]} texcoords Texture coordinates list
 */
function addPlayersToList(playerList, coords, texcoords) {
  var player;
  var playerRepresentation = { x: tx - 0.3, y: ty - 0.4, z: tz - 0.3 };
  for (let i = 0; i < playerList.length; i++) {
    player = playerList[i];
    if (distance3d(player, playerRepresentation) < 0.15) continue;
    var start = coords.length;
    coords.push(...coordCube(0.1, 0 + player.height - 0.4, 0 + 0.1, player.width - 0.2, 0.4, player.depth - 0.2));
    texcoords.push(...texCube(...playerTexcoords["headTop"]).map(x => x / 64));
    coords.push(...coordCube(0.1, 0 + player.height - 0.4, 0 + 0.5001, 0.4, 0.4, 0.0001));
    texcoords.push(...texCube(...playerTexcoords["headFront"]).map(x => x / 64));
    coords.push(...coordCube(0.1, 0 + player.height - 0.4, 0 + 0.0999, 0.4, 0.4, 0.0001));
    texcoords.push(...texCube(...playerTexcoords["headBack"]).map(x => x / 64));
    coords.push(...coordCube(0.0999, 0 + player.height - 0.4, 0 + 0.1, 0.0001, 0.4, 0.4));
    texcoords.push(...texCube(...playerTexcoords["headSide"]).map(x => x / 64));
    coords.push(...coordCube(0.5001, 0 + player.height - 0.4, 0 + 0.1, 0.0001, 0.4, 0.4));
    texcoords.push(...texCube(...playerTexcoords["headSide"]).map(x => x / 64));
    for (let i = start; i < coords.length; i += 3) {
      coords[i] -= player.width / 2 - 0.2;
      coords[i + 1] -= player.height - 0.2;
      coords[i + 2] -= player.depth / 2 - 0.2;
      [coords[i], coords[i + 1], coords[i + 2]] = rotateVertical(coords[i], coords[i + 1], coords[i + 2], -player.orientation.vertical / 5);
      coords[i] += player.width / 2 - 0.2;
      coords[i + 1] += player.height - 0.2;
      coords[i + 2] += player.depth / 2 - 0.2;
    }
    coords.push(...coordCube(0.1, 0 + player.height - 1.1, 0 + 0.1, player.width - 0.2, 0.7, player.depth - 0.2));
    texcoords.push(...texCube(...playerTexcoords["body"]).map(x => x / 64));
    coords.push(...coordCube(-0.02, 0 + player.height - 1.1, 0 + 0.25, 0.1, 0.7, 0.1));
    texcoords.push(...texCube(...playerTexcoords["arm"]).map(x => x / 64));
    coords.push(...coordCube(0.52, 0 + player.height - 1.1, 0 + 0.25, 0.1, 0.7, 0.1));
    texcoords.push(...texCube(...playerTexcoords["arm"]).map(x => x / 64));
    var actualLength = coords.length;
    coords.push(...coordCube(0.1, 0, 0 + 0.25, 0.1, 0.7, 0.1));
    texcoords.push(...texCube(...playerTexcoords["leg"]).map(x => x / 64));
   /* // */ for (let j = actualLength; j < coords.length; j += 3) {
   /* // */   coords[j] -= 0.1;
   /* // */   coords[j + 1] -= 0.7;
   /* // */   coords[j + 2] -= 0.25;
   /* // */[coords[j], coords[j + 1], coords[j + 2]] = rotateVertical(coords[j], coords[j + 1], coords[j + 2], Math.sin((player.x + player.z) * 4) / 5);
   /* // */   coords[j] += 0.1;
   /* // */   coords[j + 1] += 0.7;
   /* // */   coords[j + 2] += 0.25;
      /* // */
    }
   /* // */ actualLength = coords.length;
    coords.push(...coordCube(0.4, 0, 0 + 0.25, 0.1, 0.7, 0.1));
    texcoords.push(...texCube(...playerTexcoords["leg"]).map(x => x / 64));
   /* // */ for (let j = actualLength; j < coords.length; j += 3) {
   /* // */   coords[j] -= 0.1;
   /* // */   coords[j + 1] -= 0.7;
   /* // */   coords[j + 2] -= 0.25;
   /* // */[coords[j], coords[j + 1], coords[j + 2]] = rotateVertical(coords[j], coords[j + 1], coords[j + 2], -Math.sin((player.x + player.z) * 4) / 5);
   /* // */   coords[j] += 0.1;
   /* // */   coords[j + 1] += 0.7;
   /* // */   coords[j + 2] += 0.25;
      /* // */
    }
    for (let i = start; i < coords.length; i += 3) {
      coords[i] -= player.width / 2;
      coords[i + 1] -= player.height / 2;
      coords[i + 2] -= player.depth / 2;
      [coords[i], coords[i + 1], coords[i + 2]] = rotate(coords[i], coords[i + 1], coords[i + 2], player.orientation.horizontal);
      coords[i] += player.x + player.width / 2;
      coords[i + 1] += player.y + player.height / 2;
      coords[i + 2] += player.z + player.depth / 2;
    }
  }
}
var textImage = new Image();
textImage.src = './text.png';
textImage.onload = () => {
  setTimeout(() => {
    var tx2 = gl.createTexture();
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, tx2);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, textImage);
    textImage.tx2 = tx2;
    console.log('img::ok');
    gl.activeTexture(gl.TEXTURE0);
  }, 2000);
};
function updateWaterNotThrottled() {
  let toCheckNext = [];
  for (let index = 0; index < toCheck.length; index++) {
    const [x, y, z] = toCheck[index];
    blockFlow(x, y, z, toCheckNext, WATER);
  }
  toCheck = toCheckNext;
}
window.updateWater = throttle(updateWaterNotThrottled, 1000);
var playerImage = new Image();
playerImage.src = './player.png';
playerImage.onload = () => {
  setTimeout(() => {
    var tx2 = gl.createTexture();
    gl.activeTexture(gl.TEXTURE3);
    gl.bindTexture(gl.TEXTURE_2D, tx2);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, playerImage);
    playerImage.tx2 = tx2;
    console.log('player.img::ok');
  }, 2000);
};
var image;
var image2 = new Image();
image2.src = './texture2.png';
image2.onload = function () {
  var image1 = new Image();
  image1.src = './texture.png';
  window.fps_div = $('#text');
  window.message_div = $('#htext');
  image1.onload = (function () {
    image = image1;
    var leftClickDown, rightClickDown, leftClickTime = 0, rightClickTime = 0;
    const canvas = $('#webgl');
    /** @type {HTMLCanvasElement} */
    const postProcessingCanvas = $('#canvas');
    window.postProcessingCanvas = postProcessingCanvas;
    const ppsCtx = postProcessingCanvas.getContext('2d');
    window.ppsCtx = ppsCtx;
    /** @type {?WebGLRenderingContext} */
    const gl = canvas.getContext('webgl', { antialias: false, preserveDrawingBuffer: true });
    if (!gl) {
      alert('Your browser does not support WebGL.');
      return;
    }
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    const canvas2d = $('#selected');
    const fakeCursor = $('.fakecursor');
    const ctx = canvas2d.getContext('2d');
    window.ctx = ctx;
    ctx.imageSmoothingEnabled = false;
    ctx.mozImageSmoothingEnabled = false;
    function action(build) {
      if (build) {
        // build blocks
        var nearest = 1e9;
        loop: for (var i = 0.1; i < window.RAYCAST_MAX; i += 0.05) {
          var positions = horizontalVerticalDistanceToXYZ(horizontalHeading, verticalHeading, i);
          positions[0] += cameraPosition.x;
          positions[1] += cameraPosition.y;
          positions[2] += cameraPosition.z;
          var [x_x, y_y, z_z] = positions.map(rounding);
          if (getBlockFast(x_x, y_y, z_z) && i < nearest) {
            nearest = i;
          }
        }
        if (nearest < 1e9) {
          loop: for (var i = nearest; i > 0.1; i -= 0.05) {
            var positions = horizontalVerticalDistanceToXYZ(horizontalHeading, verticalHeading, i);
            positions[0] += cameraPosition.x;
            positions[1] += cameraPosition.y;
            positions[2] += cameraPosition.z;
            var [x_x, y_y, z_z] = positions.map(rounding);
            if (getBlockFast(x_x, y_y, z_z) === 0 && !(cubeCollision2({ x: x_x, y: y_y, z: z_z, width: 1, height: 1, depth: 1 }, player))) {
              //console.log(x_x, y_y, z_z);
              if ((!limited) || inventory.use(selectedType)) {
                setBlock(x_x, y_y, z_z, selectedType);
                meow(x_x, y_y, z_z);
              }
              //console.log('Setting');
              break loop;
            }
          }
        }
      } else {
        // break blocks
        loop: for (var i = 0.1; i < window.RAYCAST_MAX; i += 0.05) {
          var positions = horizontalVerticalDistanceToXYZ(horizontalHeading, verticalHeading, i);
          positions[0] += cameraPosition.x;
          positions[1] += cameraPosition.y;
          positions[2] += cameraPosition.z;
          var [x_x, y_y, z_z] = positions.map(rounding);
          if (getBlockFast(x_x, y_y, z_z)) {
            if (limited) inventory.change(getBlockFast(x_x, y_y, z_z), 1);
            setBlock(x_x, y_y, z_z, 0);
            break loop;
          }
        }
      }
    }
    const autoAction = throttle((n) => { action(n); }, 300);
    document.addEventListener('mousedown', e => {
      if (!window.prompting) e.preventDefault(); else return;
      //console.log(e);
      if (!document.pointerLockElement || inventoryOpen) return;
      var rightclick = (e.which == 3 || e.button == 2 || e.ctrlKey || e.metaKey || e.altKey);
      if (!pressedKeys['f'])
        action(rightclick);
      else {
        if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) {
          serverInterface.throwArrow();
        } else {
          window.objects.arrows.push(new Arrow(tx, ty, tz, { horizontal: horizontalHeading, vertical: verticalHeading }, horizontalVerticalDistanceToXYZ, { arrowForce: 0.4 }, 'player'));
        }
      }
      if (rightclick) {
        rightClickDown = true;
        leftClickDown = false;
        rightClickTime = 0;
      } else {
        leftClickDown = true;
        rightClickDown = false;
        leftClickTime = 0;
      }
    });
    document.addEventListener('contextmenu', e => {
      if (!window.prompting) e.preventDefault(); else return;
      //console.log(e);
      if (!document.pointerLockElement) return;
      action(1);
    });
    document.addEventListener('mouseup', e => {
      if (!window.prompting) e.preventDefault(); else return;
      if (!document.pointerLockElement) return;
      var rightclick = (e.which == 3 || e.button == 2 || e.ctrlKey || e.metaKey || e.altKey);
      if (rightclick) {
        rightClickDown = false;
      } else {
        leftClickDown = false;
      }
    });
    window.addEventListener('resize', () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      postProcessingCanvas.width = window.innerWidth;
      postProcessingCanvas.height = window.innerHeight;
    });
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    postProcessingCanvas.width = window.innerWidth;
    postProcessingCanvas.height = window.innerHeight;
    const sky = [0.429, 0.707, 1.0, 1.0];
    // const sky = [0.05, 0.05, 0.1, 1.0];


    gl.clearColor(...sky);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    window.gl = gl;
    /**
     * @param {!WebGLRenderingContext} gl
     * @returns {WebGLShader}
     */
    function createShader(gl, source, type, name) {
      var shader = gl.createShader(type);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      var status = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
      if (!status) {
        throw new Error(`Shader <${name}> : ERROR (${gl.getShaderInfoLog(shader)})`);
      }
      return shader;
    }
    /** 
     * @param {!WebGLRenderingContext} gl
     * @param {WebGLShader} vertex
     * @param {WebGLShader} fragment
     * @returns {WebGLProgram}
     */
    function createProgram(gl, vertex, fragment) {
      var program = gl.createProgram();
      gl.attachShader(program, vertex);
      gl.attachShader(program, fragment);
      gl.linkProgram(program);
      var status = gl.getProgramParameter(program, gl.LINK_STATUS);
      if (!status) {
        throw new Error('could not compile program. (' + JSON.stringify(gl.getProgramInfoLog(program)) + ')');
      }
      window.program = program;
      return program;
    }
    const vertexShader = createShader(gl, `
#define WIGGLE 7.0
attribute vec4 a_position;
attribute vec2 a_texcoord;
varying vec4 v_position;
varying vec2 v_texcoord;
uniform mat4 u_matrix;
uniform float time;
uniform int wave;
void main(){
  v_texcoord = a_texcoord;
  vec4 position = vec4(a_position); 
  position.y += float(wave) * (sin(a_position.x * cos(time)) / WIGGLE - cos(a_position.z * sin(time)) / WIGGLE);
  gl_Position = u_matrix * position;
  v_position = gl_Position;
}
`, gl.VERTEX_SHADER, 'vertex');
    const fragmentShader = createShader(gl, `
precision highp float;
uniform sampler2D u_texture;
varying vec2 v_texcoord;
varying vec4 v_position;
uniform float renderDistance;
void main(){
  float fogAmount = (v_position.z / (renderDistance - 8.0))*1.1;
  fogAmount = clamp(fogAmount, 0., 1.);
  gl_FragColor = texture2D(u_texture, v_texcoord);
  if(gl_FragColor.a == 0.0) discard;
  gl_FragColor = mix(gl_FragColor, vec4(${sky.slice(0, -1).join(',')}, 1.0), fogAmount);
}
`, gl.FRAGMENT_SHADER, 'fragment');
([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]][([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]((!![]+[])[+!+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+([][[]]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+!+[]]+(+[![]]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+!+[]]]+(!![]+[])[!+[]+!+[]+!+[]]+(+(!+[]+!+[]+!+[]+[+!+[]]))[(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([]+[])[([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]][([][[]]+[])[+!+[]]+(![]+[])[+!+[]]+((+[])[([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]+[])[+!+[]+[+!+[]]]+(!![]+[])[!+[]+!+[]+!+[]]]](!+[]+!+[]+!+[]+[!+[]+!+[]])+(![]+[])[+!+[]]+(![]+[])[!+[]+!+[]])()(([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[!+[]+!+[]+!+[]]))[Array(..."gol").reverse().join('')](atob("Q29weXJpZ2h0IDIwMjAgT2xpZSBBdWdlciA8b2xpZS5hdWdlckBnbWFpbC5jb20+IGh0dHBzOi8vcmVwbGl0LmNvbS9AQVNUUk9JREU="));
    const program = createProgram(gl, vertexShader, fragmentShader);
    const matrixLocation = gl.getUniformLocation(program, 'u_matrix');
    const renderDistanceLocation = gl.getUniformLocation(program, 'renderDistance');
    const timeLocation = gl.getUniformLocation(program, 'time');
    const waveLocation = gl.getUniformLocation(program, 'wave');
    window.waveLocation = waveLocation;
    const positionLocation = gl.getAttribLocation(program, 'a_position');
    const texCoordLocation = gl.getAttribLocation(program, 'a_texcoord');
    const textureLocation = gl.getUniformLocation(program, 'u_texture');
    gl.enable(gl.CULL_FACE);
    gl.enable(gl.DEPTH_TEST);
    window.texture = gl.createTexture();
    setTexture(image);
    var positionBuffer = gl.createBuffer();
    var texCoordBuffer = gl.createBuffer();
    var flight = false;
    var inPortal = false;
    var temporaryBonus = {};
    var keys = {}, FPS;
    window.pressedKeys = keys;
    addEventListener("keydown", e => {
      if (window.prompting) return;
      if (isTyping) {
        if (e.key.length > 1) {
          if (e.key == "Enter" || e.key == "Return") {
            if (typing == 'position') {
              if (window.IS_MULTIPLAYER) serverInterface.sendMessage(`X: ${Math.floor(tx)}, Y: ${Math.floor(ty)}, Z: ${Math.floor(tz)}`);
            } else if (window.IS_MULTIPLAYER) {
              serverInterface.sendMessage(typing);
            } else {
              if (answering && actualQuestion) {
                actualQuestion[1](typing);
              } else {
                addMessage(typing);
              }
            }
            typing = '';
            isTyping = false;
          } else if (e.key == "Backspace") {
            typing = typing.slice(0, -1);
            e.preventDefault();
            e.returnValue = false;
            return false;
          }
        } else {
          if (e.key == ';') {
            answering = true;
          } else {
            typing += e.key;
          }
        }
        return;
      }
      //console.log('keydown:',e.key);
      switch (e.key.toLowerCase()) {
        case 'arrowup': if (inventoryOpen) moveInventoryCursor(0, -1); else verticalHeading += Math.PI / 50; break;
        case 'arrowdown': if (inventoryOpen) moveInventoryCursor(0, 1); else verticalHeading -= Math.PI / 50; break;
        case 'arrowleft': if (inventoryOpen) moveInventoryCursor(-1, 0); else horizontalHeading += Math.PI / 50; break;
        case 'arrowright': if (inventoryOpen) moveInventoryCursor(1, 0); else horizontalHeading -= Math.PI / 50; break;
        case '1': hotbarSelected = 0; break;
        case '2': hotbarSelected = 1; break;
        case '3': hotbarSelected = 2; break;
        case '4': hotbarSelected = 3; break;
        case '5': hotbarSelected = 4; break;
        case '6': hotbarSelected = 5; break;
        case '7': hotbarSelected = 6; break;
        case '8': hotbarSelected = 7; break;
        case '9': hotbarSelected = 8; break;
        case '0': hotbarSelected = 9; break;
        case 'e': toggleInventory(); break;
        case 'g': hotbar[hotbarSelected] = inventorySelected; break;
        case 'w': keys['w'] = true; break;
        case 'a': keys['a'] = true; break;
        case 'r': keys['r'] = true; break;
        case 'f': keys['f'] = true; break;
        case 's': keys['s'] = true; break;
        case 'd': keys['d'] = true; break;
        case '-': keys['minus'] = true; break;
        case ' ': keys['space'] = true; break;
        case 'q': keys['q'] = true; break;
        case 'shift': keys['shift'] = true; break;
        case 'p': [tx, ty, tz] = [8, 50, 8]; break;
        case 'l': flight = !flight; break;
        case 'x': cleanChunks(); break;
        case 'escape': document.exitPointerLock(); break;
        case 'y':
          if (window.GAME_SAVED) {
            games.save(GAME_NAME);
            lastSaveTime = Date.now();
          } else {
            prompt('World Name :', Math.random() * 500).then(name => {
              games.save(name);
              window.GAME_SAVED = true;
              window.GAME_NAME = name;
              lastSaveTime = Date.now();
            });
          }
          break;
        case 'c':
          hotbarSelected++;
          hotbarSelected %= 10;
          break;
        case 'i':
          switch (image) {
            case image1:
              image = image2;
              break;
            case image2:
              image = image1;
              break;
          }
          setTexture(image);
          break;
        case 't':
          if (!isTyping) isTyping = true;
          answering = false;
          break;
      }
      selectedType = hotbar[hotbarSelected];
      keys.flight = flight;
      if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) serverInterface.sendKeys(keys);
    });
    ([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]][([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]((!![]+[])[+!+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+([][[]]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+!+[]]+(+[![]]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+!+[]]]+(!![]+[])[!+[]+!+[]+!+[]]+(+(!+[]+!+[]+!+[]+[+!+[]]))[(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([]+[])[([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]][([][[]]+[])[+!+[]]+(![]+[])[+!+[]]+((+[])[([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(!![]+[])[+!+[]]]+[])[+!+[]+[+!+[]]]+(!![]+[])[!+[]+!+[]+!+[]]]](!+[]+!+[]+!+[]+[!+[]+!+[]])+(![]+[])[+!+[]]+(![]+[])[!+[]+!+[]])()(([][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+(![]+[])[!+[]+!+[]]+(![]+[])[+!+[]]+(!![]+[])[+[]]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[!+[]+!+[]+!+[]]))[Array(..."gol").reverse().join('')](atob("Q29weXJpZ2h0IDIwMjAgT2xpZSBBdWdlciA8b2xpZS5hdWdlckBnbWFpbC5jb20+IGh0dHBzOi8vcmVwbGl0LmNvbS9AQVNUUk9JREU="));
    var wheelNumber;
    addEventListener("wheel", e => {
      var direction = 0;
      if (Math.sign(wheelNumber) != Math.sign(e.deltaY)) wheelNumber = 0;
      wheelNumber += e.deltaY;
      if (Math.abs(wheelNumber) > gameSettings.mouseWheelSensivity) {
        direction = Math.sign(wheelNumber);
        wheelNumber = 0;
      }
      hotbarSelected += direction;
      if (hotbarSelected < 0) hotbarSelected = 9;
      hotbarSelected %= 10;
    });
    addEventListener("keyup", e => {
      if (window.prompting) return;
      switch (e.key.toLowerCase()) {
        case 'w': keys['w'] = false; break;
        case 'a': keys['a'] = false; break;
        case 'r': keys['r'] = false; break;
        case 'f': keys['f'] = false; break;
        case 's': keys['s'] = false; break;
        case 'd': keys['d'] = false; break;
        case 'q': keys['q'] = false; break;
        case '-': keys['minus'] = false; break;
        case ' ': keys['space'] = false; break;
        case 'shift': keys['shift'] = false; break;
      }
      if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) serverInterface.sendKeys(keys);
    });
    window.inventoryOpen = false;
    inventoryOpen = false, inventorySelected = 1, inventorySelectedX = 0, inventorySelectedY = 0;
    function toggleInventory() {
      inventoryOpen = !inventoryOpen;
      if (inventoryOpen) {
        ctx.canvas.height = 38 * 5;
        document.body.classList.add("nocursor");
        fakeCursor.classList.remove('hidden');
        document.exitPointerLock();
      } else {
        ctx.canvas.height = 38;
        fakeCursor.classList.add('hidden');
        document.body.classList.remove("nocursor");
        // const canvas = $('#webgl');
        postProcessingCanvas.requestPointerLock();
      }
    }
    function moveInventoryCursor(x, y) {
      inventorySelectedX += x;
      inventorySelectedY += y;
      if (inventorySelectedX > 9) {
        inventorySelectedX = 0;
        inventorySelectedY++;
      }
      if (inventorySelectedX < 0) {
        inventorySelectedX = 9;
        inventorySelectedY--;
      }
      if (inventorySelectedY > 3) inventorySelectedY = 0;
      if (inventorySelectedY < 0) inventorySelectedY = 3;
      inventorySelected = Math.min(inventorySelectedY * 10 + inventorySelectedX + 1, blockNumber - 1);
      console.log(inventorySelected);
      var [startX, startY] = texmaps[inventorySelected];
      startX *= 128;
      startY *= 128;
      fakeCursor.style.backgroundPosition = `-${startX}px -${startY}px`;
    }
    function inventoryCursorTo(x, y) {
      inventorySelectedX = x;
      inventorySelectedY = y;
      inventorySelected = Math.min(inventorySelectedY * 10 + inventorySelectedX + 1, blockNumber - 1);
      console.log(inventorySelected);
    }
    var mouseX = 0, mouseY = 0;
    addEventListener('mousemove', e => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      if (inventoryOpen) {
        fakeCursor.style.left = (mouseX - 8) + "px";
        fakeCursor.style.top = (mouseY - 8) + "px";
      }
    });
    addEventListener('click', e => {
      if (inventoryOpen) {
        var middleX = window.innerWidth / 2, middleY = window.innerHeight / 2, maxY = window.innerHeight - 5, minY = window.innerHeight - (5 + (38 * 4)), minX = middleX - (386 / 2), maxX = middleX + (386 / 2);
        if (mouseX >= minX && mouseX <= maxX && mouseY >= minY && mouseY <= maxY) {
          var x = Math.floor((mouseX - minX) / 38), y = Math.floor((mouseY - minY) / 38);
          if ((x == 8 || x == 9) && y == 3) {
            if (!inventory.use(["carrots", "potions"][x - 8])) return;
            if (keys.minus) {
              var [dx, dy, dz] = horizontalVerticalDistanceToXYZ(horizontalHeading, verticalHeading, 2);
              objects.food.push(new ([Carrot, HealingPotion][x - 8])(cameraPosition.x + dx, cameraPosition.y + dy, cameraPosition.z + dz));
              return
            }
            var item = new ([Carrot, HealingPotion][x - 8])();
            addMessage('!You\'ve eaten ' + item.name);
            item.effect();
            return
          }
          inventoryCursorTo(x, y);
          var [startX, startY] = inventoryMaps[inventorySelected] || texmaps[inventorySelected];
          startX *= 128;
          startY *= 128;
          fakeCursor.style.backgroundPosition = `-${Math.floor(startX)}px -${Math.floor(startY)}px`;
        } else if (mouseX >= minX && mouseX <= maxX && mouseY <= minY && mouseY >= (minY - 38)) {
          var index = Math.floor((mouseX - minX) / 38);
          console.log(index);
          hotbar[index] = inventorySelected;
        }
      }
    });
    window.chunks = [];//[new Chunk(gl, 0, 0, 0), new Chunk(gl, 16, 0, 0),new Chunk(gl, 0, 0, 16),new Chunk(gl, 16, 0, 16), new Chunk(gl,0,16,0,true),new Chunk(gl,16,16,0,true),new Chunk(gl,0,16,16,true),new Chunk(gl,16,16,16,true)];
    window.yForce = 0;
    var filter = 20, frameTime = 0, lastFrame = Date.now(), thisFrame;
    var wascrouching = false, crouching = false;
    function render() {
      var temporaryBonus = {
        vision: 0,
        speed: 0
      };
      for (let index = 0; index < temporaryEffects.length; index++) {
        const effect = temporaryEffects[index];
        effect[0](temporaryBonus, effect[1]--);
        if (effect[1] <= 0) {
          temporaryEffects.splice(index--, 1);
        }
      }
      var playerSpeed = (gameSettings.playerSpeed + temporaryBonus.speed) * (60 / FPS);
      horizontalHeading = wrapNumber(horizontalHeading, -Math.PI, Math.PI, Math.PI * 2)
      gl.uniform1i(textureLocation, 0);
      gl.uniform1f(renderDistanceLocation, renderDistance);
      gl.uniform1f(timeLocation, (Date.now() % 50000) / 50000 * Math.PI * 2);
      gl.uniform1i(waveLocation, 0);
      // console.log(tmp);
      if (leftClickDown) {
        leftClickTime++;
        if (leftClickTime >= 15)
          autoAction(0);
      }
      if (rightClickDown) {
        rightClickTime++;
        if (rightClickTime >= 15)
          autoAction(1);
      }
      if (!window.IS_MULTIPLAYER) ty += yForce;
      window.player = {
        x: tx - 0.3,
        y: ty - 0.4,
        z: tz - 0.3,
        width: 0.6,
        height: 1.6,
        depth: 0.6
      };

      if (!window.IS_MULTIPLAYER) {
        function isColliding() {
          //if(keys.q) return false;
          return detectCollision(player);
        }
        // THROTTLE_TIMEOUT_OVERRIDE = keys["f"] ? 10 : null;
        if (keys.shift) {
          player.height = 0.85;
          crouching = true;
        } else {
          crouching = false;
          if (wascrouching && isColliding()) {
            crouching = true;
            player.height = 0.85;
          }
        }
        var colliding = isColliding();
        var ascension = 0;
        if (!colliding) yForce -= (0.01); else {
          var sign = -Math.sign(yForce), tmp = yForce;
          yForce = 0;
          if (Math.abs(tmp) <= 0.123) {
            ty += -tmp;
            player.y += -tmp;
          } else {
            while (isColliding() && ascension < 90) {
              ty += 0.0625 * sign;
              player.y += 0.0625 * sign;
              ascension++;
            }
          }
        }
        if (keys.space && ((flight || window.inWater) ? true : colliding)) {
          if(window.inWater){
            yForce = 0.05;
          }
          else yForce += flight ? 0.02 : 0.2;//.178
        }
        var backup = [tx, ty, tz], backup2 = Object.assign({}, player);
        var tmp;
        if (keys.a) {
          tmp = cos(horizontalHeading + Math.PI / 2) * (playerSpeed);
          tz -= tmp;
          player.z -= tmp;
          tmp = sin(horizontalHeading + Math.PI / 2) * (playerSpeed);
          tx -= tmp;
          player.x -= tmp;
        }
        if (isColliding()) { [tx, ty, tz] = backup; player = backup2 }
        backup = [tx, ty, tz], backup2 = Object.assign({}, player);
        if (keys.d) {
          tmp = cos(horizontalHeading + Math.PI / 2) * (playerSpeed);
          tz += tmp;
          player.z += tmp;
          tmp = sin(horizontalHeading + Math.PI / 2) * (playerSpeed);
          tx += tmp;
          player.x += tmp;
        }
        if (isColliding()) { [tx, ty, tz] = backup; player = backup2 }
        backup = [tx, ty, tz], backup2 = Object.assign({}, player);
        if (keys.s) {
          tmp = cos(horizontalHeading) * (playerSpeed);
          tz += tmp;
          player.z += tmp;
          tmp = sin(horizontalHeading) * (playerSpeed);
          tx += tmp;
          player.x += tmp;
        }
        if (isColliding()) { [tx, ty, tz] = backup; player = backup2 }
        backup = [tx, ty, tz], backup2 = Object.assign({}, player);
        if (keys.w) {
          tmp = cos(horizontalHeading) * (playerSpeed);
          tz -= tmp;
          player.z -= tmp;
          tmp = sin(horizontalHeading) * (playerSpeed);
          tx -= tmp;
          player.x -= tmp;
        }
        if (isColliding()) { [tx, ty, tz] = backup; player = backup2 }
        if (ty < -100) {
          console.log('You fell in the void');
          tx = 8, ty = 50, tz = 8;
          yForce = 0;
        }
      }
      ; (function () {
        if (getBlockFast(rounding(tx), rounding(ty), rounding(tz)) == MAGIC) {
          if (inPortal) return;
          // PORTAL DETECTION
          var x = rounding(tx), y = rounding(ty), z = rounding(tz);
          // Horizontal
          if (getBlockFast(x - 1, y, z) == BLACK_STONE && getBlockFast(x + 1, y, z) == BLACK_STONE && getBlockFast(x, y, z - 1) == BLACK_STONE && getBlockFast(x, y, z + 1) == BLACK_STONE && getBlockFast(x - 1, y, z - 1) == BLACK_STONE && getBlockFast(x - 1, y, z + 1) == BLACK_STONE && getBlockFast(x + 1, y, z - 1) == BLACK_STONE && getBlockFast(x + 1, y, z + 1) == BLACK_STONE) inPortal = true;
          // Vertical (x aligned)
          else if (getBlockFast(x - 1, y, z) == BLACK_STONE && getBlockFast(x + 1, y, z) == BLACK_STONE && getBlockFast(x, y - 1, z) == BLACK_STONE && getBlockFast(x, y + 1, z) == BLACK_STONE && getBlockFast(x - 1, y - 1, z) == BLACK_STONE && getBlockFast(x - 1, y + 1, z) == BLACK_STONE && getBlockFast(x + 1, y - 1, z) == BLACK_STONE && getBlockFast(x + 1, y + 1, z) == BLACK_STONE) inPortal = true;
          // Vertical (z aligned)
          else if (getBlockFast(x, y, z - 1) == BLACK_STONE && getBlockFast(x, y, z + 1) == BLACK_STONE && getBlockFast(x, y - 1, z) == BLACK_STONE && getBlockFast(x, y + 1, z) == BLACK_STONE && getBlockFast(x, y - 1, z - 1) == BLACK_STONE && getBlockFast(x, y + 1, z - 1) == BLACK_STONE && getBlockFast(x, y - 1, z + 1) == BLACK_STONE && getBlockFast(x, y + 1, z + 1) == BLACK_STONE) inPortal = true;
          if (!inPortal) return;
          if (`${x}/${y}/${z}` in portals) {
            console.log(portals, `${x}/${y}/${z}`, portals[`${x}/${y}/${z}`]);
            [tx, ty, tz] = portals[`${x}/${y}/${z}`].map((x, i) => x + ([0.501, 0.501, 0.501][i]));
          } else {
            tx = Math.random() * 512 - 256;
            tz = Math.random() * 512 - 256;
            ty = 0;
          }
          if (window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) serverInterface.teleport(tx, ty, tz);
          yForce = 0;
          crouching = true; wascrouching = true;
        } else {
          inPortal = false;
        }
      })();

      gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
      gl.clearColor(...sky);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.useProgram(program);
      var projectionMatrix = m4.perspective((keys['f'] ? (fov + temporaryBonus.vision) - 30 : (fov + temporaryBonus.vision)) / 180 * Math.PI, canvas.clientWidth / canvas.clientHeight, /* zNear */ 0.01, /* zFar */ renderDistance);
      if (window.IS_MULTIPLAYER ? keys.shift : crouching) {
        cameraPosition.yOffset -= 0.15;
      } else {
        cameraPosition.yOffset += 0.15;
      }
      cameraPosition.yOffset = Math.max(Math.min(0.95, cameraPosition.yOffset), 0);
      cameraPosition.x = tx;
      cameraPosition.y = ty + cameraPosition.yOffset;
      cameraPosition.z = tz;
      var cameraMatrix = m4.translation(cameraPosition.x, cameraPosition.y, cameraPosition.z);
      cameraMatrix = m4.inverse(m4.xRotate(m4.yRotate(cameraMatrix, horizontalHeading), verticalHeading));
      var resultMatrix = m4.multiply(projectionMatrix, cameraMatrix);
      gl.uniformMatrix4fv(matrixLocation, false, resultMatrix);
      for (var i = 0; i < chunks.length; i++) {
        chunks[i].draw(gl, positionLocation, texCoordLocation);
      }
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      // var bounds = texmaps[selectedType].slice(0);
      // bounds[0] *= image.width * (32 / image.width);
      // bounds[2] *= image.width * (32 / image.width);
      // bounds[1] *= image.height * (32 / image.height);
      // bounds[3] *= image.height * (32 / image.height);
      // ctx.drawImage(image, 0, 0, image.width, image.height, 0, 0, 128, 128);
      // ctx.fillStyle = "black";
      // ctx.lineWidth = 2;
      // ctx.strokeRect(bounds[0], bounds[1], bounds[2] - bounds[0], bounds[3] - bounds[1]);
      // ctx.fillStyle = 'white';
      ctx.strokeStyle = "#222";
      ctx.lineWidth = 3;
      for (var j = 0; j < 10; j++) {
        var bounds = (inventoryMaps[hotbar[j]] || texmaps[hotbar[j]]).slice(0);
        bounds[0] *= image.width * (128 / image.width);
        bounds[2] *= image.width * (128 / image.width);
        bounds[1] *= image.height * (128 / image.height);
        bounds[3] *= image.height * (128 / image.height);
        ctx.drawImage(image, bounds[0], bounds[1], bounds[2] - bounds[0], bounds[3] - bounds[1], 3 + j * 38, 3, 32, 32);
        // if(j == hotbarSelected){
        ctx.strokeStyle = j == hotbarSelected ? '#f55' : '#555';
        ctx.strokeRect(j * 38, 0, 38, 2);
        ctx.strokeRect(j * 38, 36, 38, 2);
        ctx.strokeRect(j * 38, 0, 2, 38);
        ctx.strokeRect(j * 38 + 37, 0, 2, 38);
        ctx.fillStyle = "white";
        if (limited) ctx.fillText(inventory.numberOf(hotbar[j]), j * 38 + 10, 20);
      }
      var bounds = (inventoryMaps[hotbar[hotbarSelected]] || texmaps[hotbar[hotbarSelected]]).slice(0);
      bounds[0] *= image.width * (128 / image.width);
      bounds[2] *= image.width * (128 / image.width);
      bounds[1] *= image.height * (128 / image.height);
      bounds[3] *= image.height * (128 / image.height);
      // ctx.drawImage(image, bounds[0], bounds[1], bounds[2] - bounds[0], bounds[3] - bounds[1], 3+hotbarSelected*38, 3, 32, 32);
      // if(j == hotbarSelected){
      ctx.strokeStyle = '#f55';
      ctx.strokeRect(hotbarSelected * 38, 0, 38, 2);
      ctx.strokeRect(hotbarSelected * 38, 36, 38, 2);
      ctx.strokeRect(hotbarSelected * 38, 0, 2, 38);
      ctx.strokeRect(hotbarSelected * 38 + 36, 0, 2, 38);
      if (inventoryOpen) {
        ctx.strokeRect(inventorySelectedX * 38, inventorySelectedY * 38 + 38, 38, 38);
      }
      for (var x = 0; x < 10; x++) {
        for (var y = 0; y < 4; y++) {
          var index = y * 10 + x + 1;
          if (index < blockNumber) {
            var bounds = (inventoryMaps[index] || texmaps[index]).slice(0);
            bounds[0] *= image.width * (128 / image.width);
            bounds[2] *= image.width * (128 / image.width);
            bounds[1] *= image.height * (128 / image.height);
            bounds[3] *= image.height * (128 / image.height);
            ctx.drawImage(image, bounds[0], bounds[1], bounds[2] - bounds[0], bounds[3] - bounds[1], x * 38 + 3, y * 38 + 41, 32, 32);
            if (limited) ctx.fillText(inventory.numberOf(index), x * 38 + 10, y * 38 + 61);
          } else {
            if (index == 39) {
              var bounds = texmaps["carrot"].slice(0);
              bounds[0] *= image.width * (128 / image.width);
              bounds[2] *= image.width * (128 / image.width);
              bounds[1] *= image.height * (128 / image.height);
              bounds[3] *= image.height * (128 / image.height);
              ctx.drawImage(image, bounds[0], bounds[1], bounds[2] - bounds[0], bounds[3] - bounds[1], x * 38 + 3, y * 38 + 41, 32, 32);
              ctx.fillText(inventory.numberOf("carrots"), x * 38 + 10, y * 38 + 61);
            } else if (index == 40) {
              var bounds = texmaps["potion"].slice(0);
              bounds[0] *= image.width * (128 / image.width);
              bounds[2] *= image.width * (128 / image.width);
              bounds[1] *= image.height * (128 / image.height);
              bounds[3] *= image.height * (128 / image.height);
              ctx.drawImage(image, bounds[0], bounds[1], bounds[2] - bounds[0], bounds[3] - bounds[1], x * 38 + 3, y * 38 + 41, 32, 32);
              ctx.fillText(inventory.numberOf("potions"), x * 38 + 10, y * 38 + 61);
            }
          }
        }
      }
      if (started_playing && !document.pointerLockElement && !inventoryOpen) {
        back_elt.style.display = 'block';
      } else {
        back_elt.style.display = 'none';
      }
      (function () {
        var theX = tx, theZ = tz;
        for (var i = chunks.length - 1; i >= 0; i--) {
          if (((chunks[i].x == round16(theX)) && (chunks[i].z == round16(theZ)) && (chunks[i].y == 0))) return;
        }
        if ((ty >= 16) && window.AUTO_GENERATE) {
          var t = Math.random();
          chunks.push(new Chunk(gl, round16(theX), 0, round16(theZ), 'special', t));
          chunks.push(new Chunk(gl, round16(theX), 16, round16(theZ), 'special-top', t));
        }
        theX = tx - 1, theZ = tz;
        for (var i = chunks.length - 1; i >= 0; i--) {
          if (((chunks[i].x == round16(theX)) && (chunks[i].z == round16(theZ)) && (chunks[i].y == 0))) return;
        }
        if ((ty >= 16) && window.AUTO_GENERATE) {
          var t = Math.random();
          chunks.push(new Chunk(gl, round16(theX), 0, round16(theZ), 'special', t));
          chunks.push(new Chunk(gl, round16(theX), 16, round16(theZ), 'special-top', t));
        }
        theX = tx + 1, theZ = tz;
        for (var i = chunks.length - 1; i >= 0; i--) {
          if (((chunks[i].x == round16(theX)) && (chunks[i].z == round16(theZ)) && (chunks[i].y == 0))) return;
        }
        if ((ty >= 16) && window.AUTO_GENERATE) {
          var t = Math.random();
          chunks.push(new Chunk(gl, round16(theX), 0, round16(theZ), 'special', t));
          chunks.push(new Chunk(gl, round16(theX), 16, round16(theZ), 'special-top', t));
        }
        theX = tx, theZ = tz - 1;
        for (var i = chunks.length - 1; i >= 0; i--) {
          if (((chunks[i].x == round16(theX)) && (chunks[i].z == round16(theZ)) && (chunks[i].y == 0))) return;
        }
        if ((ty >= 16) && window.AUTO_GENERATE) {
          var t = Math.random();
          chunks.push(new Chunk(gl, round16(theX), 0, round16(theZ), 'special', t));
          chunks.push(new Chunk(gl, round16(theX), 16, round16(theZ), 'special-top', t));
        }
        theX = tx, theZ = tz + 1;
        for (var i = chunks.length - 1; i >= 0; i--) {
          if (((chunks[i].x == round16(theX)) && (chunks[i].z == round16(theZ)) && (chunks[i].y == 0))) return;
        }
        if ((ty >= 16) && window.AUTO_GENERATE) {
          var t = Math.random();
          chunks.push(new Chunk(gl, round16(theX), 0, round16(theZ), 'special', t));
          chunks.push(new Chunk(gl, round16(theX), 16, round16(theZ), 'special-top', t));
        }
      })();
      if (window.animals && window.models) {
        var coords = [], texcoords = [];//, username;
        for (var i = animals.birds.length - 1; i >= 0; i--) {
          animals.birds[i].update();
          if (distance3d(player, animals.birds[i]) > 45) continue;
          coords.push(...animals.birds[i].move((animals.birds[i].isParrot ? models.parrot : models.bird).vertices.slice(0)));
          texcoords.push(...(animals.birds[i].isParrot ? models.parrot : models.bird).texcoords);
        }
        for (var i = animals.squirrels.length - 1; i >= 0; i--) {
          animals.squirrels[i].update();
          if (distance3d(player, animals.squirrels[i]) > 45) continue;
          coords.push(...animals.squirrels[i].move(models.squirrel.vertices.slice(0)));
          texcoords.push(...models.squirrel.texcoords);
        }
        for (var i = animals.horses.length - 1; i >= 0; i--) {
          animals.horses[i].update();
          if (distance3d(player, animals.horses[i]) > 45) continue;
          coords.push(...animals.horses[i].move(models.horse.vertices.slice(0)));
          texcoords.push(...models.horse.texcoords);
        }
        if (animals.rabbits) {
          for (var i = animals.rabbits.length - 1; i >= 0; i--) {
            animals.rabbits[i].update();
            if (distance3d(player, animals.rabbits[i]) > 45) continue;
            coords.push(...animals.rabbits[i].move(models.rabbit.vertices.slice(0)));
            texcoords.push(...models.rabbit.texcoords);
          }
        }
        var tmp;
        for (var i = 0; i < objects.food.length; i++) {
          objects.food[i].update();
          if ((tmp = distance3d(player, objects.food[i])) > 45) continue;
          if (tmp < 1.5) {
            inventory.change(objects.food[i].type() + "s", 1);
            // objects.food[i].effect();
            objects.food.splice(i--, 1);
            continue;
          }
          coords.push(...objects.food[i].move(objects.food[i].getModel().vertices.slice(0)));
          texcoords.push(...objects.food[i].getModel().texcoords);
          // console.log('FOOD');
        }
        if (window.animals.npcs) {
          for (let index = 0; index < animals.npcs.length; index++) {
            const npc = animals.npcs[index];
            if (npc.update()) {
              animals.npcs.splice(index--, 1);
              if (npc.lastHit == "player") {
                for (let index = 0; index < animals.npcs.length; index++) {
                  /** @type {Person} */
                  const other = animals.npcs[index];
                  if (quickDistance(tx, ty, tz, other.x, other.y, other.z) < (1000)) other.mad = true;
                }
              }
            }
          }
        }
        var newList = objects.activatedBoxes.list.slice(0);
        var newDict = Object.assign({}, objects.activatedBoxes.dictionary);
        for (var i = 0, box; i < objects.activatedBoxes.list.length; i++) {
          box = objects.activatedBoxes.list[i][1];
          var result = box.update(newList, newDict);
          if (result) {
            // console.log(box.listEntry, newList.indexOf(box.listEntry));
            newList.splice(newList.indexOf(box.listEntry), 1);
          }
          if (distance3d(player, box) > 45) continue;
          coords.push(...box.move(models.truc.vertices.slice(0)));
          texcoords.push(...models.truc.texcoords);
        }
        for (var i = 0; i < objects.signalEmitters.length; i++) {
          var emitter = objects.signalEmitters[i];
          var result = emitter.update(newList, newDict);
          if (result) {
            objects.signalEmitters.splice(i--, 1);
          }
        }
        objects.activatedBoxes.list = newList;
        objects.activatedBoxes.dictionary = newDict;
        for (var i = objects.arrows.length - 1; i >= 0; i--) {
          var o = {};
          objects.arrows[i].update(getBlockFast, o);
          if (o.deleted) {
            objects.arrows.splice(i--, 1);
            continue;
          }
          if (distance3d(player, objects.arrows[i]) > 45) continue;
          coords.push(...objects.arrows[i].move(models.arrow.vertices.slice(0)));
          texcoords.push(...models.arrow.texcoords);
        }
        coords = new Float32Array(coords);
        texcoords = new Float32Array(texcoords);
        gl.uniform1i(textureLocation, 2);
        gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, coords, gl.DYNAMIC_DRAW);
        gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(positionLocation);
        gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, texcoords, gl.STATIC_DRAW);
        gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(texCoordLocation);
        if (texcoords.length > 0)
          gl.drawArrays(glMode, 0, texcoords.length / 2);
        gl.uniform1i(textureLocation, 3);
        if ((window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED && window.players && window.playerInfos) || (window.animals.npcs)) {
          coords = [], texcoords = [];
          window.players && addPlayersToList(players, coords, texcoords);
          window.animals.npcs && addPlayersToList(window.animals.npcs, coords, texcoords);
          coords = new Float32Array(coords);
          texcoords = new Float32Array(texcoords);
          gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
          gl.bufferData(gl.ARRAY_BUFFER, coords, gl.DYNAMIC_DRAW);
          gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
          gl.enableVertexAttribArray(positionLocation);
          gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
          gl.bufferData(gl.ARRAY_BUFFER, texcoords, gl.STATIC_DRAW);
          gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
          gl.enableVertexAttribArray(texCoordLocation);
          //console.log(coords[0]);
          if (texcoords.length > 0)
            gl.drawArrays(glMode, 0, texcoords.length / 2);
          texcoords = [];
          coords = [];
          if (window.players || (window.animals && window.animals.npcs)) {
            if (window.players) {
              for (let i = 0, username = ''; i < players.length; i++) {
                const thisPlayer = players[i];
                //console.log(thisPlayer, playerInfos);
                username = (playerInfos[thisPlayer.id] || {}).username + '';
                //var matrix = m4.lookAt([player.x, player.y + 2, player.z], [tx, ty, tz], [0, 1, 0]);
                username = username.split('').map(l => l.toLowerCase()).filter(l => ('abcdefghijklmnopqrstuvwxyz_'.indexOf(l) > -1)).join('');
                var dx = (username.length / 2) * -0.25;
                var quadXs = [dx, -dx];
                username = username.split('').reverse().join('');
                for (var l = 0; l < username.length; l++) {
                  texcoords.push(...texQuad(...glyphs[username[l]]));
                  var pos = coordQuad(dx, 2, 0, 0.2, 0.2 * (7 / 5));
                  for (var p = 0; p < 18; p += 3) {
                    var [newX, newY, newZ] = rotate(pos[p], pos[p + 1], pos[p + 2],/* Math.lookAt(tx, tz, thisPlayer.x, thisPlayer.z)+Math.PI*1.5 */-horizontalHeading + Math.PI);
                    pos[p] = newX + thisPlayer.x + thisPlayer.width / 2;
                    pos[p + 1] = newY + thisPlayer.y;
                    pos[p + 2] = newZ + thisPlayer.z + thisPlayer.depth / 2;
                  }
                  coords.push(...pos);
                  dx += 0.25;
                }
                texcoords.push(...texQuad(...glyphs['void']));
                var pos = coordQuad(quadXs[0], 2, 0.01, quadXs[1] * 2, 0.2005 * (7 / 5));
                for (var p = 0; p < 18; p += 3) {
                  var [newX, newY, newZ] = rotate(pos[p], pos[p + 1], pos[p + 2], -horizontalHeading + Math.PI);
                  pos[p] = newX + thisPlayer.x + thisPlayer.width / 2;
                  pos[p + 1] = newY + thisPlayer.y;
                  pos[p + 2] = newZ + thisPlayer.z + thisPlayer.depth / 2;
                }
                coords.push(...pos);
                dx += 0.25;
              }
            }
            if (window.animals && window.animals.npcs) {
              let max = renderDistance ** 2;
              for (let i = 0, username = ''; i < animals.npcs.length; i++) {
                const thisPlayer = animals.npcs[i];
                if (quickDistance(tx, ty, tz, thisPlayer.x, thisPlayer.y, thisPlayer.z) > max) continue;
                //console.log(thisPlayer, playerInfos);
                username = (thisPlayer).name + '';
                //var matrix = m4.lookAt([player.x, player.y + 2, player.z], [tx, ty, tz], [0, 1, 0]);
                // username = username.split('').map(l => l.toLowerCase()).filter(l => ('abcdefghijklmnopqrstuvwxyz_'.indexOf(l) > -1)).join('');
                var dx = (username.length / 2) * -0.25;
                var quadXs = [dx, -dx];
                username = username.split('').reverse().join('');
                for (var l = 0; l < username.length; l++) {
                  texcoords.push(...texQuad(...glyphs[username[l]]));
                  var pos = coordQuad(dx, 2, 0, 0.2, 0.2 * (7 / 5));
                  for (var p = 0; p < 18; p += 3) {
                    var [newX, newY, newZ] = rotate(pos[p], pos[p + 1], pos[p + 2], -horizontalHeading + Math.PI);
                    pos[p] = newX + thisPlayer.x + thisPlayer.width / 2;
                    pos[p + 1] = newY + thisPlayer.y;
                    pos[p + 2] = newZ + thisPlayer.z + thisPlayer.depth / 2;
                  }
                  coords.push(...pos);
                  dx += 0.25;
                }
                texcoords.push(...texQuad(...glyphs['void']));
                var pos = coordQuad(quadXs[0], 2, 0.01, quadXs[1] * 2, 0.2005 * (7 / 5));
                for (var p = 0; p < 18; p += 3) {
                  var [newX, newY, newZ] = rotate(pos[p], pos[p + 1], pos[p + 2], -horizontalHeading + Math.PI);
                  pos[p] = newX + thisPlayer.x + thisPlayer.width / 2;
                  pos[p + 1] = newY + thisPlayer.y;
                  pos[p + 2] = newZ + thisPlayer.z + thisPlayer.depth / 2;
                }
                coords.push(...pos);
                dx += 0.25;
              }
            }
            gl.uniform1i(textureLocation, 1);
            coords = new Float32Array(coords);
            texcoords = new Float32Array(texcoords);
            gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, coords, gl.DYNAMIC_DRAW);
            gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
            gl.enableVertexAttribArray(positionLocation);
            gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, texcoords, gl.STATIC_DRAW);
            gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
            gl.enableVertexAttribArray(texCoordLocation);
            //console.log(coords[0]);
            if (texcoords.length > 0)
              gl.drawArrays(glMode, 0, texcoords.length / 2);
          }
          gl.uniform1i(textureLocation, 0);
        }
      }
      gl.uniform1i(textureLocation, 0);
      for (let index = 0; index < ondrawend.length; index++) {
        const fn = ondrawend[index];
        fn();
      }
      ondrawend = [];
      updateWater();
      ppsCtx.clearRect(0, 0, ppsCtx.canvas.width, ppsCtx.canvas.height);
      ppsCtx.drawImage(canvas, 0, 0);
      if (getBlockFast(Math.floor(cameraPosition.x), Math.floor(cameraPosition.y), Math.floor(cameraPosition.z)) == WATER) {
        // In water
        // #19369da0
        ppsCtx.fillStyle = "rgba(25, 54, 157, 0.62)";
        ppsCtx.fillRect(0, 0, ppsCtx.canvas.width, ppsCtx.canvas.height);
        window.inWater = true;
      } else window.inWater = false;
      wascrouching = crouching;
      var thisFrameTime = (thisFrame = Date.now()) - lastFrame;
      frameTime += (thisFrameTime - frameTime) / filter;
      lastFrame = thisFrame;
      FPS = (1000 / frameTime);
      var text = window.GAME_SAVED ? `Last saved ${((Date.now() - lastSaveTime) / 1000).toFixed(0)} seconds ago` : 'Never saved';
      fps_div.innerText = `${isTyping ? ((answering ? (actualQuestion[0] + ': ') : '') + typing + ((Math.floor(Date.now() / 333) % 2 == 0) ? '_' : '')) : ''}\nFPS: ${Math.round(FPS)}\nPosition: X${Math.floor(tx)}, Y${Math.floor(ty)}, Z${Math.floor(tz)}${flight ? '\nFLIGHT ENABLED' : ''}\n${text}${window.IS_MULTIPLAYER && !window.MULTIPLAYER_CONNECTED ? '\nConnexion en cours...' : ''}${`\n[${'='.repeat(Math.round(window.playerLife * 10))}${' '.repeat(Math.round((1.0 - window.playerLife) * 10))}]`}`;
      requestAnimationFrame(render);
    }
    window.games && games.loadThis() && (render() || (window.CREATE_ANIMALS = false));
    window.render = render;
    CreateTerrain();
    if (window.sessionStorage && window.sessionStorage.getItem('gametype') == 'multiplayer') {
      window.cancelIslands && window.cancelIslands();
      window.chunks.splice(0, chunks.length);
      window.terrainData = {};
      multiplayer();
    }
    //render();
  });
};
window.onerror = function (msg, url, noLigne, noColonne, erreur) {
  var chaine = msg.toLowerCase();
  var souschaine = "script error";
  if (chaine.indexOf(souschaine) > -1) {
    console.log('Script Error : see console');
  } else {
    var message = [
      'Message : ' + msg,
      'URL : ' + url,
      'Line : ' + noLigne,
      'Column : ' + noColonne,
      'Error Object : ' + JSON.stringify(erreur)
    ].join(' - ');

    console.log(message);
  }

  return false;
};
function end() {
  requestAnimationFrame = null;
}
function getBlock(x, y, z) {
  var obj = { x: x, y: y, z: z, width: 1, height: 1, depth: 1 };
  for (var i = 0; i < chunks.length; i++) {
    if (chunks[i].detectCollision(obj) && (y - chunks[i].y < 16) && (z - chunks[i].z < 16) && (x - chunks[i].x < 16) && (y - chunks[i].y >= 0) && (z - chunks[i].z > -1) && (x - chunks[i].x > -1)) {
      //console.log(x-chunks[i].x < 16,y-chunks[i].y,z-chunks[i].z);
      return chunks[i].data[chunk_xyz(x - chunks[i].x, y - chunks[i].y, z - chunks[i].z)];
    }
  }
  return 0;
}
function setBlockFast(x, y, z, v, byFlood) {
  if (v == WATER && !byFlood) {
    toCheck.push([x, y, z]);
  }
  var _x = round16(x), _y = round16(y), _z = round16(z);
  var nc = terrainData[`${_x}/${_y}/${_z}`];
  if (!nc) {
    nc = new Chunk(gl, _x, _y, _z, "empty");
    chunks.push(nc);
  }
  nc.data[chunk_xyz(x - _x, y - _y, z - _z)] = v;
  nc.updateBuffer = true;
}
function getBlockFast(x, y, z) {
  var _x = round16(x), _y = round16(y), _z = round16(z);
  var nc = terrainData[`${_x}/${_y}/${_z}`];
  if (!nc) return 0;
  return nc.data[chunk_xyz(x - _x, y - _y, z - _z)];
}
function setBlock(x, y, z, v, n) {
  if (v == WATER && !window.IS_MULTIPLAYER) {
    toCheck.push([x, y, z]);
  }
  // if(v == WATER) waterList.push([x, y, z]);
  if (!n && window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) window.serverInterface.sendBlock(x, y, z, v);
  var obj = { x: x, y: y, z: z, width: 1, height: 1, depth: 1 };
  for (var i = 0; i < chunks.length; i++) {
    if (cubeCollision2(chunks[i], obj) && (y - chunks[i].y <= 15) && (z - chunks[i].z <= 15) && (x - chunks[i].x <= 15) && (y - chunks[i].y >= 0) && (z - chunks[i].z >= 0) && (x - chunks[i].x >= 0)) {
      // console.log('incorrect', y-chunks[i].y, chunk_xyz(x-chunks[i].x,y-chunks[i].y,z-chunks[i].z));
      chunks[i].data[chunk_xyz(x - chunks[i].x, y - chunks[i].y, z - chunks[i].z)] = v;
      chunks[i].updateBuffer = true;
      return;
    }
  }
  //console.log('Failed !');
  for (var i = chunks.length - 1; i >= 0; i--) {
    if (chunks[i].x == round16(x) && chunks[i].y == round16(y) && chunks[i].z == round16(z)) return;
  }
  console.log('creating chunk at', round16(x), round16(y), round16(z));
  var chunk = new Chunk(gl, round16(x), round16(y), round16(z), "empty");
  chunk.data[chunk_xyz(x - chunk.x, y - chunk.y, z - chunk.z)] = v;
  chunk.updateBuffer = true;
  chunks.push(chunk);
  return;
}
function horizontalVerticalDistanceToXYZ(h, v, d) {
  var x, y, z;
  x = d * -sin(h);
  z = d * -cos(h);
  y = d * sin(v);
  x *= cos(v);
  z *= cos(v);
  return [x, y, z];
}
function importTextures() {
  var fileInput = $('#teximport');
  fileInput.onchange = (e => {
    var file = fileInput.files[0];
    var fr = new FileReader();
    fr.onload = function () {
      var _image = new Image();
      _image.src = fr.result;
      _image.onload = function () {
        image = _image;
        setTexture(image);
      }

    }
    fr.readAsDataURL(file);
  });
  fileInput.click();
}
function createAnimals() {
  Promise.all([loadObjFile('./models/bird-flying.obj', [1, 1, 1], [0, 0, 0]), loadObjFile('./models/squirrel.obj', [0.1, 0.1, 0.1], [-1, 0, 0]), loadObjFile('./models/parrot.obj', [1, 1, 1], [0, 0, 0]), loadObjFile('./models/horse.obj', [0.5, 0.5, 0.5], [0, 0, 0]), loadObjFile('./models/hl.obj', [1, 1, 1], [0, 0, 0]), loadObjFile('./models/arrow.obj', [1, 1, 1], [0, 0, 0]), loadObjFile('./models/truc.obj', [1, 1, 1], [-0.35, -0.35, -0.35]), loadObjFile('./models/carrot.obj', [0.1, 0.1, 0.1], [0, 0, 0]), loadObjFile('./models/potion.obj', [0.3, 0.3, 0.3], [0, 0, 0]), loadObjFile('./models/rabbit.obj', [0.1, 0.1, 0.1], [0, 0, 0])]).then((x) => {
    var obj = x[0], sqrl = x[1], parrot = x[2], horse = x[3], horseLeg = x[4], arrow = x[5], truc = x[6], carrot = x[7], potion = x[8], rabbit = x[9];
    var tx3 = gl.createTexture();
    //console.log(obj.texture);
    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, tx3);
    //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    //gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, obj.texture); } catch (e) { console.log(e) }
    obj.texture.tx3 = tx3;
    console.log('bird::ok');
    window.models = {};
    window.houses = window.houses || [{ x: 10, y: 0, z: 10 }];
    window.models.squirrel = sqrl;
    window.models.bird = obj;
    window.models.parrot = parrot;
    window.models.horse = horse;
    window.models.horseLeg = horseLeg;
    window.models.arrow = arrow;
    window.models.truc = truc;
    window.models.carrot = carrot;
    window.models.potion = potion;
    window.models.rabbit = rabbit;
    window.objects = window.objects || {
      arrows: [],
      activatedBoxes: activatedBoxes,
      signalEmitters: [],
      food: []
    };
    window.animals = window.animals || {
      birds: [],
      squirrels: [],
      horses: [],
      rabbits: [],
      npcs: []
    };
    if (window.CREATE_ANIMALS === false) return;
    for (var i = 0; i < personWaitList.length; i++) {
      window.animals.npcs.push(personWaitList[i]);
    }
    personWaitList = [];
    for (var i = 0; i < 20; i++) {
      animals.birds.push(new Bird(Math.random() * 512 - 256, 50, Math.random() * 512 - 256));
    }
    for (var i = 0; i < 5; i++) {
      animals.squirrels.push(new Squirrel(Math.random() * 512 - 256, 90, Math.random() * 512 - 256));
      console.log('SQUIRREL !!!', animals.squirrels[animals.squirrels.length - 1].x, animals.squirrels[animals.squirrels.length - 1].z);
    }
    for (var i = 0; i < 3; i++) {
      animals.horses.push(new Horse(Math.random() * 512 - 256, 50, Math.random() * 512 - 256));
    }
  });
}
setTimeout(() => {
  createAnimals();
}, 2000);

// setInterval(() => {
//   cleanChunks();
// }, 2000);