class FoodItem {
    constructor(x, y, z){
        this.x = x;
        this.y = y;
        this.z = z;
        this.yForce = 0;
        this.width = 0.1;
        this.height = 0.1;
        this.depth = 0.1;
        this.dir = 0
    }
    update(){
        this.y += this.yForce;
        var colliding = detectCollision(this);
        if (!colliding) this.yForce -= (0.01); else {
            var sign = -Math.sign(this.yForce);
            this.yForce = 0;
            while (detectCollision(this)) {
                this.y += 0.0625 * sign;
            }
        }
        if(this.y < -100) this.y = 100;
    }
    move(obj){
        for(var i=0;i<obj.length;i+=3){
			var __ = obj[i];
			obj[i] = Math.cos(Math.lookAt(obj[i], obj[i+2], 0, 0) + this.dir) * distance2d(obj[i], obj[i+2], 0, 0);
			obj[i+2] = Math.sin(Math.lookAt(__, obj[i+2], 0, 0) + this.dir) * distance2d(__, obj[i+2], 0, 0);
			obj[i] += this.x+0.15;
			obj[i+1] += this.y+0.2;
			obj[i+2] += this.z+0.15;
		}
		return obj;
    }
    getModel(){
        return models.carrot;
    }
    effect(){}
    type(){}
    get name(){
        return "un truc comestible"
    }
}
class Carrot extends FoodItem {
    type(){
        return "carrot";
    }
    getModel(){
        return super.getModel();
    }
    effect(){
        addTemporaryEffect(function (bonus, index) {
            bonus.speed += (index / 10000);
        }, 1000);
    }
    get name(){
        return "une carotte"
    }
}
class Potion extends FoodItem {
    getModel(){
        return models.potion || super.getModel();
    }
    type(){
        return "potion";
    }
    get name(){
        return "un breuvage mystérieux"
    }
}
class HealingPotion extends Potion {
    effect(){
        if(playerLife < 1){
            if(playerLife >= 0.9) playerLife = 1;
            else {
                playerLife += (1.0 - playerLife) * 0.75;
            }
        }
    }
    get name(){
        return super.name + " qui vous guérit de vos souffrances";
    }
}