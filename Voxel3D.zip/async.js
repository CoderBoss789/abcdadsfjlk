function wait(ms){
	return new Promise(resolve => {
		setTimeout(()=>{
			resolve();
		}, ms);
	});
}
async function asyncLoop(start, step, end, fn){
	var i = start;
	while(i<end){
		fn(i);
		i+=step;
		await wait(5);
	}
	return;
}