/**
 * Copyright (c) 2020 Olie Auger | https://repl.it/@ASTROIDE/
 * except window.onerror & throttle
 */
window.RAYCAST_MAX = 6;
Math.lookAt = function(x1, y1, x2, y2){
  return Math._direction = Math.atan2(y2-y1, x2-x1);
}
function realdiff(n1, n2){
  let simple = Math.abs(n1-n2);
  let complex = Math.abs(wrapNumber(n1+PI, 0, PI2)-wrapNumber(n2+PI, 0, PI2));
  return complex<simple?complex:simple;
}
function wrapNumber(n, min, max, ntaos){
  ntaos = ntaos || max;
  if(n<min)n+=ntaos;
  else if(n>max)n-=ntaos;
  return n;
}
var glMode = WebGLRenderingContext.prototype.TRIANGLES;
const LAVA        =  1;
const GRASS       =  2;
const BLUE        =  3;
const GLASS       =  4;
const FOLIAGE     =  5;
const WOOD        =  6;
const BLUE_STONE  =  7;
const WOOD_BIRCH  =  8;
const BLACK_STONE =  9;
const RED         = 10;
const BRICK       = 11;
const SAND        = 12;

var limited = true;
class Inventory {
  constructor(){
    this.items = {};
  }
  numberOf(type){
    if(this.items[type]) return this.items[type];
    return 0;
  }
  change(type, number){
    if(!this.items[type]) this.items[type] = number;
    else this.items[type] += number;
  }
  use(type){
    if(!this.items[type]) return false;
    else {
      this.items[type]--;
      return true;
    }
  }
  toString(){
    return JSON.stringify(this.items);
  }
  load(s){
    this.items = JSON.parse(s);
  }
}
var inventory = new Inventory();
function meow(x, y, z){
  let gb = getBlock, setBlockFast = setBlock;
  if((gb(x, y-1, z) == LAVA || gb(x, y-1, z) == BLUE) && gb(x-1, y, z) == BRICK && gb(x+1, y, z) == BRICK && gb(x, y, z-1) == BRICK && gb(x, y, z+1) == BRICK){
    if(gb(x, y-1, z) == LAVA){
      switch(gb(x, y, z)){
        case SAND:
        setBlockFast(x, y, z, GLASS);
        break;
        case LAVA:
        setBlockFast(x, y, z, RED);
        break;
        case RED:
        setBlockFast(x, y, z, BLACK_STONE);
        break;
        default:
        console.log('?');
        break;
      }
    } else {
      switch(gb(x, y, z)){
        case GLASS:
        setBlockFast(x, y, z, SAND);
        break;
        case RED:
        setBlockFast(x, y, z, LAVA);
        break;
        case BLACK_STONE:
        setBlockFast(x, y, z, RED);
        break;
        default:
        console.log('?');
        break;
      }
    }
  }
}
function distance2d(x1, y1, x2, y2){
  return Math.sqrt((x2 - x1)**2 + (y2 - y1)**2);
}
function lookAt(x1, y1, x2, y2) {
  x2 -= x1;
  y2 -= y1;
  return Math.atan2(y2, x2);
}
function rotate(x, y, z, angle){
  var initialAngle = lookAt(0, 0, x, z), dist = distance2d(0, 0, x, z);
  angle += initialAngle;
  x = Math.cos(angle) * dist;
  z = Math.sin(angle) * dist;
  return [x, y, z];
}
function distance3d(v1, v2){
    var dx = v1.x - v2.x;
    var dy = v1.y - v2.y;
    var dz = v1.z - v2.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}
 var multiplayerConnected;
const $ = document.querySelector.bind(document);
function equal(obj1, obj2){
  for(var e in obj1){
    if(!(e in obj2)) return false;
    if(obj1[e] !== obj2[e]){
      return false;
    }
  }
  return true;
}
function round16(n){
  return Math.floor(n/16)*16;
}
window.THROTTLE_TIMEOUT_OVERRIDE = null;
const throttle = (func, limit) => {
  let inThrottle
  return function() {
    const args = arguments
    const context = this
    if (!inThrottle) {
      func.apply(context, args)
      inThrottle = true
      setTimeout(() => inThrottle = false, window.THROTTLE_TIMEOUT_OVERRIDE||limit)
    }
  }
}
var cm1='', cm2='', cm3='', typing='', isTyping = false;
var horizontalHeading = Math.PI, verticalHeading = 0, selectedType = 1, started_playing = false;
var back_elt = $('#back');
var lastSaveTime = Date.now();
var sin = Math.sin.bind(Math), cos = Math.cos.bind(Math);
var rounding = Math.floor.bind(Math);
var addedListener = false;
document.addEventListener('click', function (e) {
  if(document.pointerLockElement || window.prompting || e.target == back_elt)return;
  /** @type {HTMLCanvasElement} */
  const canvas = $('#webgl');
  canvas.requestPointerLock();
  started_playing = true;
  if(!addedListener)
  canvas.addEventListener('mousemove', e => {
    if(!document.pointerLockElement)return;
    horizontalHeading -= e.movementX * (Math.PI / 360);
    verticalHeading -= e.movementY * Math.PI / 360;
    verticalHeading = Math.max(Math.PI / -2, verticalHeading);
    verticalHeading = Math.min(Math.PI / 2, verticalHeading);
  });
addedListener = true;
});
function lineCollision(coord1, width1, coord2, width2) {
  //Determines if the lines defined by coord1/width1 and coord1/width1 collide.
  if ((coord1 >= coord2 && coord1 <= coord2 + width2) || (coord2 >= coord1 && coord2 <= coord1 + width1)) return true;
  else return false;
}

function squareCollision(x1, y1, w1, h1, x2, y2, w2, h2) {
  //Determines if two rectangles collide.
  if (lineCollision(x1, w1, x2, w2) && lineCollision(y1, h1, y2, h2)) return true;
  else return false;
}

function cubeCollision(x1, y1, z1, w1, h1, d1, x2, y2, z2, w2, h2, d2) {
  return lineCollision(z1, d1, z2, d2) && squareCollision(x1, y1, w1, h1, x2, y2, w2, h2);
}

function cubeCollision2(o1, o2) {
  return lineCollision(o1.z, o1.depth, o2.z, o2.depth) && squareCollision(o1.x, o1.y, o1.width, o1.height, o2.x, o2.y, o2.width, o2.height);
}

var texmaps = {
  "bark": [0, 0.5, 0.25, 0.75],
  "bark-birch": [0.25, 0.5, 0.5, 0.75],
  0: [0.25, 0.5, 0.5, 0.75],
  1: [0, 0, 0.25, 0.25],
  2: [0, 0.25, 0.25, 0.5],
  3: [0.25, 0, 0.5, 0.25],
  4: [0.25, 0.25, 0.5, 0.5],
  5: [0.5, 0, 0.75, 0.25],
  6: [0.5, 0.25, 0.75, 0.5],
  7: [0.75, 0, 1, 0.25],
  8: [0.75, 0.25, 1, 0.5],
  9: [0.5, 0.5, 0.75, 0.75],
  10: [0.75, 0.5, 1, 0.75],
  11: [0.25, 0.75, 0.5, 1],
  12: [0.5, 0.75, 0.75, 1],
  "J": [0, 0.75, 0.25, 1.0],
  218: [0,0,1,1]
};
// H7 W5
var glyphs = {
  "a": [0,     0,    5/32,    7/32],
  "b": [5/32,  0,    10/32,   7/32],
  "c": [10/32, 0,    15/32,   7/32],
  "d": [15/32, 0,    20/32,   7/32],
  "e": [20/32, 0,    25/32,   7/32],
  "f": [25/32, 0,    30/32,   7/32],
  "g": [0,     7/32, 5/32,   14/32],
  "h": [5/32,  7/32, 10/32,  14/32],
  "i": [10/32, 7/32, 15/32,  14/32],
  "j": [15/32, 7/32, 20/32,  14/32],
  "k": [20/32, 7/32, 25/32,  14/32],
  "l": [25/32, 7/32, 30/32,  14/32],
  "m": [0,     14/32, 5/32,  21/32],
  "n": [5/32,  14/32, 10/32, 21/32],
  "o": [10/32, 14/32, 15/32, 21/32],
  "p": [15/32, 14/32, 20/32, 21/32],
  "q": [20/32, 14/32, 25/32, 21/32],
  "r": [25/32, 14/32, 30/32, 21/32],
  "s": [0,     21/32, 5/32,  28/32],
  "t": [5/32,  21/32, 10/32, 28/32],
  "u": [10/32, 21/32, 15/32, 28/32],
  "v": [15/32, 21/32, 20/32, 28/32],
  "w": [5/32,  21/32, 0,     14/32],
  "x": [20/32, 21/32, 25/32, 28/32],
  "y": [15/32, 21/32, 20/32, 31/32],
  "z": [5/32,  21/32, 0,     28/32],
  "_": [25/32, 21/32, 30/32, 28/32]
};
for(var g in glyphs){
  var o = glyphs[g];
  glyphs[g] = [o[2],o[3],o[0],o[1]];
}
var texcoords = new Float32Array([
  0.0, 0.0,
  0.5, 0.5,
  0.5, 0.0,
  0.0, 0.0,
  0.5, 0.5,
  0.0, 0.5,
  0.0, 0.0,
  0.5, 0.5,
  0.5, 0.0,
  0.0, 0.0,
  0.5, 0.5,
  0.0, 0.5
].map(x => x * 2));
var positionArray = [];
//var tx=510,ty=510,tz=132;
var tx = 8, ty = 20, tz = 8;
function texCube(x1, y1, x2, y2) {
  return [
    x1, y1,
    x2, y1,
    x1, y2,

    x1, y2,
    x2, y1,
    x2, y2,

    x1, y1,
    x1, y2,
    x2, y1,

    x1, y2,
    x2, y2,
    x2, y1,

    x1, y1,
    x1, y2,
    x2, y2,

    x1, y1,
    x2, y2,
    x2, y1,

    x1, y2,
    x1, y1,
    x2, y2,

    x2, y2,
    x1, y1,
    x2, y1,
// *()*
    x1, y1,
  x2, y2,
  x2, y1,

  x1, y1,
  x1, y2,
  x2, y2,

  x1, y1,
  x2, y1,
  x2, y2,

  x1, y1,
  x2, y2,
  x1, y2
  ]

}
function texCube2(x1, y1, x2, y2, xx1, yy1, xx2, yy2) {
  return [
    xx1, yy1, //Front
    xx2, yy1,
    xx1, yy2,

    xx1, yy2,
    xx2, yy1,
    xx2, yy2,

    xx1, yy1,//Back
    xx1, yy2,
    xx2, yy1,

    xx1, yy2,
    xx2, yy2,
    xx2, yy1,

    x1, y1,//Down
    x1, y2,
    x2, y2,

    x1, y1,
    x2, y2,
    x2, y1,

    x1, y2,//Up
    x1, y1,
    x2, y2,

    x2, y2,
    x1, y1,
    x2, y1,
// *()*
    xx1, yy1,//Left
  xx2, yy2,
  xx2, yy1,

  xx1, yy1,
  xx1, yy2,
  xx2, yy2,

  xx1, yy1,//Right
  xx2, yy1,
  xx2, yy2,

  xx1, yy1,
  xx2, yy2,
  xx1, yy2
  ]

}
// 00 -> 01 -> 11
// 00 -> 10 -> 11
function coordCube(x, y, z, w, h, d) {
  return [
    x, y, z + d,      //Front
    x + w, y, z + d,
    x, y + h, z + d,

    x, y + h, z + d,
    x + w, y, z + d,
    x + w, y + h, z + d,


    x, y, z,    //Back
    x, y + h, z,
    x + w, y, z,

    x, y + h, z,
    x + w, y + h, z,
    x + w, y, z,


    x, y + h, z,      //Down
    x, y + h, z + d,
    x + w, y + h, z + d,

    x, y + h, z,
    x + w, y + h, z + d,
    x + w, y + h, z,


    x, y, z + d,  //Up
    x, y, z,
    x + w, y, z + d,

    x + w, y, z + d,
    x, y, z,
    x + w, y, z,


    x, y, z,      //Left
    x, y + h, z + d,
    x, y + h, z,

    x, y, z,
    x, y, z + d,
    x, y + h, z + d,


    x + w, y, z,    //Right
    x + w, y + h, z,
    x + w, y + h, z + d,

    x + w, y, z,
    x + w, y + h, z + d,
    x + w, y, z + d
  ];
}
function texQuad(a, b, c, d){
  return [
    a, b,
    a, d,
    c, d,
    a, b,
    c, d,
    c, b
  ];
}
function coordQuad(x, y, z, w, h){
  return [
    x, y, z,
    x, y+h, z,
    x+w, y+h, z,
    x, y, z,
    x+w, y+h, z,
    x+w, y, z
  ];
}
texcoords = texCube(0.5, 0.5, 1, 1);
positionArray = coordCube(-1, -1, -1, 2, 2, 2);
function isTransparent(x){
  return (!x) || x==GLASS || x==FOLIAGE;
}
function isVisible(data, x, y, z){
  if(x==0 || y==0 || z==0 || x==15 || y==15 || z==15) return true;
  return isTransparent(data[((x-1) * 256) + (y * 16) + z]) || isTransparent(data[((x+1) * 256) + (y * 16) + z]) || isTransparent(data[(x * 256) + ((y-1) * 16) + z]) || isTransparent(data[(x * 256) + ((y+1) * 16) + z]) || isTransparent(data[(x * 256) + (y * 16) + (z-1)]) || isTransparent(data[(x * 256) + (y * 16) + (z+1)]);
}
function chunkToPositionBuffer(data, tx, ty, tz) {
  //console.time('ctpb');
  var returnArray = [];
  for (var x = 0; x < 16; x++) {
    for (var y = 0; y < 16; y++) {
      for (var z = 0; z < 16; z++) {
        if (data[(x * 256) + (y * 16) + z] && isVisible(data, x, y, z))
          returnArray.push(...coordCube((x + tx), (y + ty), (z + tz), 1, 1, 1));
      }
    }
  }
  //console.timeEnd('ctpb');
  return new Float32Array(returnArray);
}
function chunkToTexCoordBuffer(data) {
  //console.time('cttcb');
  var returnArray = [];
  for (var x = 0; x < 16; x++) {
    for (var y = 0; y < 16; y++) {
      for (var z = 0; z < 16; z++) {
        if (data[(x * 256) + (y * 16) + z] && isVisible(data, x, y, z))
          returnArray.push(...((data[(x * 256) + (y * 16) + z]==6)?texCube2(...texmaps[6], ...texmaps["bark"]):(data[(x * 256) + (y * 16) + z]==8)?texCube2(...texmaps[8], ...texmaps["bark-birch"]):texCube(...texmaps[data[(x * 256) + (y * 16) + z]])) );
      }
    }
  }
  //console.timeEnd('cttcb');
  return new Float32Array(returnArray);
}
/** @returns {number} */
function chunk_xyz(x, y, z) {
  return (Math.min(Math.max(x, 0), 15) * 256) + (Math.min(y, 15) * 16) + Math.min(Math.max(z, 0), 15);
}
class Chunk {
  /** @param {WebGLRenderingContext} gl */
  constructor(gl, x, y, z, isTop) {
    this.width = 16;
    this.height = 16;
    this.depth = 16;
    this.data = new Uint8Array(16 * 16 * 16);
    //console.time('chunk');
    if(!isTop){
      for (var i = 0; i < this.data.length; i++) {
        this.data[i] = Math.random()>0.05 ? 7 : 1;//Math.floor  (Math.random() * 5);
      }
      for(let x = 0, y= 15;x<16;x++){
        for(let z = 0;z<16;z++){
          this.data[(x * 256) + (y * 16) + z] = 2;
        }
      }
      for(let x = 0, y= 0;x<16;x++){
        for(let z = 0;z<16;z++){
          this.data[(x * 256) + (y * 16) + z] = 4;
        }
      }
      var tunnel = {x: Math.floor(Math.random()*16), y: 15, z: Math.floor(Math.random()*16)};
      this.data[chunk_xyz(tunnel.x, tunnel.y, tunnel.z)] = 3;
      var tunnel_direction = -1;
      while(tunnel_direction > 0 ? (tunnel.y < 15) : (tunnel.y > 1)){
        tunnel.y+=(Math.round(Math.random()-0.25))*tunnel_direction;
        var isX = Math.random()>0.5;
        if(isX){
        tunnel.x += Math.sign(Math.random()-0.5);
        tunnel.x = Math.min(Math.max(0, tunnel.x),15);
        }else{
        tunnel.z += Math.sign(Math.random()-0.5);
        tunnel.z = Math.min(Math.max(0, tunnel.z),15);
        }
        this.data[chunk_xyz(tunnel.x, tunnel.y, tunnel.z)] = 0;
        this.data[chunk_xyz(tunnel.x-1, tunnel.y, tunnel.z)] = 0;
        this.data[chunk_xyz(tunnel.x, tunnel.y, tunnel.z+1)] = 0;
        this.data[chunk_xyz(tunnel.x, tunnel.y-tunnel_direction, tunnel.z)] = 0;
        if(tunnel.y == 1) tunnel_direction = 1;
      }
    }else if(isTop=="empty"){
      for (var i = this.data.length - 1; i >= 0; i--) {
        this.data[i] = 0;
      }
    }else{
      for(var i = 0;i<5;i++){
        let color = Math.random() > 0.5 ? 6 : 8;
        let x = Math.floor(Math.random()*16), z = Math.floor(Math.random()*16), y=0;
        while(Math.random()>0.3 && y < 16){
        this.data[chunk_xyz(x, y, z)] = color;
        this.data[chunk_xyz(x-1, y, z)] = 5;
        this.data[chunk_xyz(x+1, y, z)] = 5;
        this.data[chunk_xyz(x, y, z+1)] = 5;
        this.data[chunk_xyz(x, y, z-1)] = 5;
        y++;
        if(Math.random()>0.5){
          x+= Math.sign(Math.random()-0.5);
        }else z+= Math.sign(Math.random()-0.5);
        }
        this.data[chunk_xyz(x, y, z)] = 5;
      }
    }
    this.positionBuffer = gl.createBuffer();
    this.texCoordBuffer = gl.createBuffer();
    this.updateBuffer = true;
    this.x = x;
    this.y = y;
    this.z = z;
  }
  /** @param {Object} obj
   * @param {number} obj.x
   * @param {number} obj.y
   * @param {number} obj.z
   * @param {number} obj.width
   * @param {number} obj.height
   * @param {number} obj.depth
   */
  detectCollision(obj) {
    if (!cubeCollision(obj.x, obj.y, obj.z, obj.width, obj.height, obj.depth, this.x, this.y, this.z, 16, 16, 16)) return false;
    var x = 0, y = 0, z = 0;
    for (x = 0; x < 16; x++) {
      for (y = 0; y < 16; y++) {
        for (z = 0; z < 16; z++) {
          if (this.data[(x * 256) + (y * 16) + z] && cubeCollision(obj.x, obj.y, obj.z, obj.width, obj.height, obj.depth, this.x + x, this.y + y, this.z + z, 1, 1, 1)) return true;
        }
      }
    }
    return false;
  }
  /** @param {WebGLRenderingContext} gl */
  draw(gl, positionLocation, texCoordLocation) {
    if(distance3d(this, {x:tx,y:ty,z:tz})>(32+16*Math.SQRT2)) return;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.positionBuffer);
    if (this.updateBuffer) {
      this.positiondata = chunkToPositionBuffer(this.data, this.x, this.y, this.z);
      gl.bufferData(gl.ARRAY_BUFFER, this.positiondata, gl.STATIC_DRAW);
    }
    
    gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLocation);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer);
    if (this.updateBuffer) {
      this.texdata = chunkToTexCoordBuffer(this.data);
      gl.bufferData(gl.ARRAY_BUFFER, this.texdata, gl.STATIC_DRAW);
      this.updateBuffer = false;
    }
    
    gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(texCoordLocation);
    //throw new Error('Ratio');
    gl.drawArrays(glMode, 0, this.texdata.length / 2);
  }
}
function setTexture(tx, n, nn){
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, tx);
}
var textImage = new Image();
textImage.src = './text.png';
textImage.onload = ()=>{
  setTimeout(()=>{
    var tx2 = gl.createTexture();
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, tx2);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, textImage);
    textImage.tx2 = tx2;
    console.log('img::ok');
  }, 2000);
};
var image;
var image2 = new Image();
image2.src='./texture2.png';
image2.onload = function(){
var image1 = new Image();
image1.src = './texture.png';
image1.onload = (function () {
  image = image1;
  var leftClickDown, rightClickDown, leftClickTime = 0, rightClickTime = 0;
  const canvas = $('#webgl');
  /** @type {?WebGLRenderingContext} */
  const gl = canvas.getContext('webgl');
  if (!gl) {
    alert('Your browser does not support WebGL.');
    return;
  }
  const canvas2d = $('#selected');
  const ctx = canvas2d.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  const textoverlay = $('#text-overlay');
  try{
  const textctx = textoverlay.getContext('2d');
}catch(e){}
function playerCollision(obj){
  if(!window.players) return;
  var thisPlayer;
  for (var i = window.players.length - 1; i >= 0; i--) {
    thisPlayer = window.players[i];
    var coll = {
      x: thisPlayer.x - 0.3, 
      y: thisPlayer.y - 0.4, 
      z: thisPlayer.z - 0.3, 
      width: 0.6, 
      height: thisPlayer.d ? 0.8 : 1.6, 
      depth: 0.6
    };
    if(cubeCollision2(coll, obj)) return thisPlayer;
  }
  return;
}
  function action(build) {
    if(build){
      // build blocks
      var nearest = 1e9;
      loop:for(var i=0.1;i<window.RAYCAST_MAX;i+=0.05){
        var positions = horizontalVerticalDistanceToXYZ(horizontalHeading, verticalHeading, i);
        positions[0]+=tx;
        positions[1]+=ty;
        positions[2]+=tz;
        var [x_x, y_y, z_z] = positions.map(rounding);
        if(getBlock(x_x,y_y,z_z) && i < nearest){
          nearest = i;
        }
      }
      if(nearest < 1e9){
        loop:for(var i=nearest;i>0.1;i-=0.05){
          var positions = horizontalVerticalDistanceToXYZ(horizontalHeading, verticalHeading, i);
          positions[0]+=tx;
          positions[1]+=ty;
          positions[2]+=tz;
          var [x_x, y_y, z_z] = positions.map(rounding);
          if(getBlock(x_x,y_y,z_z) === 0 && !(cubeCollision2({x:x_x,y:y_y,z:z_z,width:1,height:1,depth:1},player))){
            //console.log(x_x, y_y, z_z);
            if((!limited) || inventory.use(selectedType)){
            setBlock(x_x,y_y,z_z,selectedType);
            meow(x_x,y_y,z_z);
          }
            //console.log('Setting');
            break loop;
          }
        }
      }
    } else {
      // break blocks
      loop:for(var i=0.1;i<window.RAYCAST_MAX;i+=0.05){
        var positions = horizontalVerticalDistanceToXYZ(horizontalHeading, verticalHeading, i);
        positions[0]+=tx;
        positions[1]+=ty;
        positions[2]+=tz;
        var [x_x, y_y, z_z] = positions.map(rounding);
        if(getBlock(x_x,y_y,z_z)){
          if(limited) inventory.change(getBlock(x_x,y_y,z_z), 1);
          setBlock(x_x,y_y,z_z, 0);
          break loop;
        }
      }
    }
  }
  const autoAction = throttle((n)=>{action(n);}, 300);
  document.addEventListener('mousedown', e => {
  if(!window.prompting)e.preventDefault();else return;
  //console.log(e);
    if(!document.pointerLockElement) return;
    var rightclick = (e.which == 3 || e.button == 2 || e.ctrlKey || e.metaKey || e.altKey);
    action(rightclick);
    if(rightclick){
      rightClickDown = true;
      leftClickDown = false;
      rightClickTime = 0;
    }else{
      leftClickDown = true;
      rightClickDown = false;
      leftClickTime = 0;
    }
  });
  document.addEventListener('contextmenu', e => {
  if(!window.prompting)e.preventDefault();else return;
  //console.log(e);
    if(!document.pointerLockElement) return;
    action(1);
  });
  document.addEventListener('mouseup', e => {
    if(!window.prompting)e.preventDefault();else return;
    if(!document.pointerLockElement) return;
    var rightclick = (e.which == 3 || e.button == 2 || e.ctrlKey || e.metaKey || e.altKey);
    if(rightclick){
      rightClickDown = false;
    }else{
      leftClickDown = false;
    }
  });
  window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  });
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  const sky = [0.429, 0.707, 1.0, 1.0];
  gl.clearColor(...sky);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  window.gl = gl;
  /**
   * @param {!WebGLRenderingContext} gl
   * @returns {WebGLShader}
   */
  function createShader(gl, source, type, name) {
    var shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    var status = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
    if (!status) {
      throw new Error(`Shader <${name}> : ERROR (${gl.getShaderInfoLog(shader)})`);
    }
    return shader;
  }
  /** 
   * @param {!WebGLRenderingContext} gl
   * @param {WebGLShader} vertex
   * @param {WebGLShader} fragment
   * @returns {WebGLProgram}
   */
  function createProgram(gl, vertex, fragment) {
    var program = gl.createProgram();
    gl.attachShader(program, vertex);
    gl.attachShader(program, fragment);
    gl.linkProgram(program);
    var status = gl.getProgramParameter(program, gl.LINK_STATUS);
    if (!status) {
      throw new Error('could not compile program. (' + JSON.stringify(gl.getProgramInfoLog(program)) + ')');
    }
    window.program = program;
    return program;
  }
  const vertexShader = createShader(gl, `
attribute vec4 a_position;
attribute vec2 a_texcoord;
varying vec4 v_position;
varying vec2 v_texcoord;
uniform mat4 u_matrix;
void main(){
  v_texcoord = a_texcoord;
  gl_Position = u_matrix * a_position;
  v_position = gl_Position;
}
`, gl.VERTEX_SHADER, 'vertex');
  const fragmentShader = createShader(gl, `
precision highp float;
uniform sampler2D u_texture;
varying vec2 v_texcoord;
varying vec4 v_position;
void main(){
  float fogAmount = (v_position.z / 32.0)*1.1;
  fogAmount = clamp(fogAmount, 0., 1.);
  gl_FragColor = texture2D(u_texture, v_texcoord);
  if(gl_FragColor.a == 0.0) discard;
  gl_FragColor = mix(gl_FragColor, vec4(${sky.join(',')}), fogAmount);
}
`, gl.FRAGMENT_SHADER, 'fragment');
  const program = createProgram(gl, vertexShader, fragmentShader);
  const matrixLocation = gl.getUniformLocation(program, 'u_matrix');
  const positionLocation = gl.getAttribLocation(program, 'a_position');
  const texCoordLocation = gl.getAttribLocation(program, 'a_texcoord');
  const textureLocation = gl.getUniformLocation(program, 'u_texture');
  gl.enable(gl.CULL_FACE);
  gl.enable(gl.DEPTH_TEST);
  window.texture = gl.createTexture();
  setTexture(image);
  var positionBuffer = gl.createBuffer();
  var texCoordBuffer = gl.createBuffer();
  window.flight = false;
  var keys = {}, FPS, fps_div = $('#fps');
  addEventListener("keydown", e => {
    if(window.prompting)return;
    if(isTyping){
      if(e.key.length > 1){
        if(e.key == "Enter" || e.key == "Return"){
          sendMessage(typing);
          typing = '';
          isTyping = false;
        }else if(e.key == "Backspace"){
          typing = typing.slice(0, -1);
          e.preventDefault();
        }
      }else{
        typing += e.key;
      }
      return;
    }
    var keys2 = Object.assign({}, keys);
    //console.log('keydown:',e.key);
    switch (e.key.toLowerCase()) {
      case 'w': keys['w'] = true; break;
      case 'a': keys['a'] = true; break;
      case 's': keys['s'] = true; break;
      case 'd': keys['d'] = true; break;
      case ' ': keys['space'] = true; break;
      case 'q': keys['q'] = true; break;
      case 'shift': keys['shift'] = true; break;
      case 'p': [tx, ty, tz] = [8, 20, 8]; break;
      case 'l': flight = !flight; break;
      case 'escape': document.exitPointerLock(); break;
      case 't':
        if(window.GAME_SAVED){
          games.save(GAME_NAME);
          lastSaveTime = Date.now();
        }else{
          prompt('Nom du monde :', Math.random()*500).then(name => {
            games.save(name);
            window.GAME_SAVED = true;
            window.GAME_NAME = name;
            lastSaveTime = Date.now();
          });
        }
        break;
      case 'e':
        selectedType++;
        selectedType %= 13;
        if(selectedType == 0) selectedType = 1;
        break;
      case 'i':
        switch(image){
          case image1:
          image = image2;
          break;
          case image2:
          image = image1;
          break;
        }
        setTexture(image);
        break;
      case 'z':
      if(isTyping)
        break;
      isTyping = 1;
        break;
    }
    if(!equal(keys, keys2)) sendKeys(keys);
  });
  addEventListener("keyup", e => {
    if(window.prompting || isTyping)return;
    var keys2 = Object.assign({}, keys);
    switch (e.key.toLowerCase()) {
      case 'w': keys['w'] = false; break;
      case 'a': keys['a'] = false; break;
      case 's': keys['s'] = false; break;
      case 'd': keys['d'] = false; break;
      case 'q': keys['q'] = false; break;
      case ' ': keys['space'] = false; break;
      case 'shift': keys['shift'] = false; break;
    }
    if(!equal(keys, keys2)) sendKeys(keys);
  });
  window.chunks = [new Chunk(gl, 0, 0, 0), new Chunk(gl, 16, 0, 0),new Chunk(gl, 0, 0, 16),new Chunk(gl, 16, 0, 16), new Chunk(gl,0,16,0,true),new Chunk(gl,16,16,0,true),new Chunk(gl,0,16,16,true),new Chunk(gl,16,16,16,true)];
  window.yForce = 0;
  var filter = 20, frameTime = 0, lastFrame = Date.now(), thisFrame;
  var wascrouching = false, crouching = false;
  function render() {
    if(textImage.tx2){
    gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.activeTexture(gl.TEXTURE1);
  gl.bindTexture(gl.TEXTURE_2D, textImage.tx2);
}
    if(leftClickDown){
      leftClickTime++;
      if(leftClickTime>=15)
      autoAction(0);
    }
    if(rightClickDown){
      rightClickTime++;
      if(rightClickTime>=15)
      autoAction(1);
    }
    /*ty += yForce;*/
    window.player = {
      x: tx - 0.3,
      y: ty - 0.4,
      z: tz - 0.3,
      width: 0.6,
      height: 1.6,
      depth: 0.6
    };

    /*
    function isColliding() {
      for (var i = 0; i < chunks.length; i++) {
        if (chunks[i].detectCollision(player)) {
          return true;
        }
      }
      return false;
    }
    if (keys.shift) {
      player.height = 0.85;
      crouching = true;
    } else {
      crouching = false;
      if(wascrouching && isColliding()){
        crouching = true;
        player.height = 0.85;
      }
    }
    var colliding = isColliding();
    var ascension=0;
    if (!colliding) yForce -= (0.01); else {
      var sign = -Math.sign(yForce);
      yForce = 0;
      while (isColliding()) {
        ty += 0.0625 * sign;
        player.y += 0.0625 * sign;
        ascension++;
      }
    }
    if (keys.space && (flight ? true : colliding)) {
      yForce += flight ? 0.01 : 0.178;
    }
    var backup = [tx,ty,tz], backup2 = Object.assign({}, player);
    var tmp;
    if (keys.a) {
      tmp = cos(horizontalHeading + Math.PI / 2) * 0.1;
      tz -= tmp;
      player.z -= tmp;
      tmp = sin(horizontalHeading + Math.PI / 2) * 0.1;
      tx -= tmp;
      player.x -= tmp;
    }
    if(isColliding()) {[tx, ty, tz] = backup;player = backup2}
    if (keys.d) {
      tmp = cos(horizontalHeading + Math.PI / 2) * 0.1;
      tz += tmp;
      player.z += tmp;
      tmp = sin(horizontalHeading + Math.PI / 2) * 0.1;
      tx += tmp;
      player.x += tmp;
    }
    if(isColliding()) {[tx, ty, tz] = backup;player = backup2}
    if (keys.s) {
      tmp = cos(horizontalHeading) * 0.1;
      tz += tmp;
      player.z += tmp;
      tmp = sin(horizontalHeading) * 0.1;
      tx += tmp;
      player.x += tmp;
    }
    if(isColliding()) {[tx, ty, tz] = backup;player = backup2}
    if (keys.w) {
      tmp = cos(horizontalHeading) * 0.1;
      tz -= tmp;
      player.z -= tmp;
      tmp = sin(horizontalHeading) * 0.1;
      tx -= tmp;
      player.x -= tmp;
    }
    if(isColliding()) {[tx, ty, tz] = backup;player = backup2}
    if(ty < -100){
      console.log('You fell in the void');
      tx = 8, ty = 20, tz = 8;
      yForce = 0;
    }*/
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
    gl.clearColor(...sky);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(program);
    var projectionMatrix = m4.perspective(Math.PI / 2, canvas.clientWidth / canvas.clientHeight, /* zNear */ 0.01, /* zFar */ 40);
    var cameraMatrix = m4.translation(tx, ty, tz);
    cameraMatrix = m4.inverse(m4.xRotate(m4.yRotate(cameraMatrix, horizontalHeading), verticalHeading));
    var resultMatrix = m4.multiply(projectionMatrix, cameraMatrix);
    gl.uniformMatrix4fv(matrixLocation, false, resultMatrix);
    for (var i = 0; i < chunks.length; i++) {
      chunks[i].draw(gl, positionLocation, texCoordLocation);
    }
    if(window.players){
      var positions = [], textPositions = [], texcoords = [], textTexcoords = [];//, birdCoords = (window.birdModel||{}).vertices||[], birdTexcoords = (window.birdModel||{}).texcoords||[], username;

      for(var i=0;i<players.length;i++){
        var thisPlayer = players[i];
        positions.push(...coordCube(thisPlayer.x - 0.3, thisPlayer.y - 0.4, thisPlayer.z - 0.3, 0.6, thisPlayer.d ? 0.8 : 1.6, 0.6));
        texcoords.push(...texCube(...texmaps["J"]));
        username = thisPlayer.n;
        //var matrix = m4.lookAt([player.x, player.y + 2, player.z], [tx, ty, tz], [0, 1, 0]);
        username = username.split('').map(l => l.toLowerCase()).filter(l => ('abcdefghijklmnopqrstuvwxyz_'.indexOf(l)>-1)).join('');
        var dx = (username.length / 2)*-0.25;
        username = username.split('').reverse().join('');
        for(var l=0;l<username.length;l++){
          textTexcoords.push(...texQuad(...glyphs[username[l]]));
          var pos = coordQuad(dx, 2, 0, 0.2, 0.2 * (7/5));
          for(var p=0;p<18;p+=3){
            var [newX, newY, newZ] = rotate(pos[p],pos[p+1],pos[p+2],lookAt(tx, tz, thisPlayer.x, thisPlayer.z)+Math.PI*1.5);
            pos[p] = newX + thisPlayer.x;
            pos[p+1] = newY + thisPlayer.y;
            pos[p+2] = newZ + thisPlayer.z;
          }
          textPositions.push(...pos);
          dx += 0.25;
        }
      }
      positions = new Float32Array(positions);
      texcoords = new Float32Array(texcoords);
      textPositions = new Float32Array(textPositions);
      textTexcoords = new Float32Array(textTexcoords);
      if(window.birdModel){
      birdCoords = new Float32Array(birdCoords);
      birdTexcoords = new Float32Array(birdTexcoords);
    }
      gl.uniform1i(textureLocation, 1);
      /* text draw */
      gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, textPositions, gl.DYNAMIC_DRAW);
      gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(positionLocation);
      gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, textTexcoords, gl.STATIC_DRAW);
      gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(texCoordLocation);
      if(textTexcoords.length > 0)
      gl.drawArrays(glMode, 0, textTexcoords.length / 2);
    if(window.birdModel){
      gl.uniform1i(textureLocation, 2);
      /* bird draw */
      gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, birdCoords, gl.DYNAMIC_DRAW);
      gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(positionLocation);
      gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, birdTexcoords, gl.STATIC_DRAW);
      gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(texCoordLocation);
      if(birdTexcoords.length > 0)
      gl.drawArrays(glMode, 0, birdTexcoords.length / 2);
  }
      /* end bird draw */
      gl.uniform1i(textureLocation, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, positions, gl.DYNAMIC_DRAW);
      gl.vertexAttribPointer(positionLocation, 3, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(positionLocation);
      gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, texcoords, gl.STATIC_DRAW);
      gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(texCoordLocation);
      gl.drawArrays(glMode, 0, texcoords.length / 2);
    }
    ctx.clearRect(0,0,128,128);
    var bounds = texmaps[selectedType].slice(0);
    bounds[0] *= image.width * (128 / image.width);
    bounds[2] *= image.width * (128 / image.width);
    bounds[1] *= image.height * (128 / image.height);
    bounds[3] *= image.height * (128 / image.height);
    ctx.drawImage(image, 0, 0, image.width, image.height, 0, 0, 128, 128);
    ctx.fillStyle = "black";
    ctx.lineWidth = 2;
    ctx.strokeRect(bounds[0], bounds[1], bounds[2] - bounds[0], bounds[3] - bounds[1]);
    ctx.fillStyle = 'white';
    for(var type = 1;type<13;type++){
      var bounds = texmaps[type].slice(0);
      bounds[0] *= image.width * (128 / image.width);
    bounds[2] *= image.width * (128 / image.width);
    bounds[1] *= image.height * (128 / image.height);
    bounds[3] *= image.height * (128 / image.height);
    //window.DB = bounds;
      if(limited)ctx.fillText(inventory.numberOf(type), bounds[0], bounds[1]+10);
    }
    if(started_playing && !document.pointerLockElement){
      back_elt.style.display = 'block';
    }else{
      back_elt.style.display = 'none';
    }

    wascrouching = crouching;
    var thisFrameTime = (thisFrame=Date.now()) - lastFrame;
    frameTime += (thisFrameTime - frameTime) / filter;
    lastFrame = thisFrame;
    FPS = (1000/frameTime);
    var text = window.GAME_SAVED ? `Dernière sauvegarde : il y a ${((Date.now() - lastSaveTime)/1000).toFixed(0)} secondes` : 'Jamais sauvegardé';
    fps_div.innerText = `${cm1}${cm2}${cm3}${isTyping?(typing+((Math.floor(Date.now()/333)%2==0)?'_':'')):''}\nFPS: ${FPS.toFixed(1)}\nPosition: X${Math.floor(tx)}, Y${Math.floor(ty)}, Z${Math.floor(tz)}${flight ? /*'\nVOL ACTIVÉ'*/'' : ''}\n${text}\n${window.players ? '{'+(window.players.map(x => x.n).join(','))+'}\n' : ''}${(multiplayerConnected === undefined)?'Connexion en cours...':'Connecté'}`;
    requestAnimationFrame(render);
  }
  window.games && games.loadThis();
  render();
});
};
window.onerror = function (msg, url, noLigne, noColonne, erreur) {
  var chaine = msg.toLowerCase();
  var souschaine = "script error";
  if (chaine.indexOf(souschaine) > -1) {
    console.log('Script Error : see console');
  } else {
    var message = [
      'Message : ' + msg,
      'URL : ' + url,
      'Line : ' + noLigne,
      'Column : ' + noColonne,
      'Error Object : ' + JSON.stringify(erreur)
    ].join(' - ');

    console.log(message);
  }

  return false;
};
function end(){
  requestAnimationFrame = null;
}
function getBlock(x, y, z){
  var obj = {x:x,y:y,z:z,width:1,height:1,depth:1};
  for(var i=0;i<chunks.length;i++){
    if(chunks[i].detectCollision(obj) && (y-chunks[i].y < 16) && (z-chunks[i].z < 16) && (x-chunks[i].x < 16) && (y-chunks[i].y >=0) && (z-chunks[i].z > -1) && (x-chunks[i].x > -1)){
      //console.log(x-chunks[i].x < 16,y-chunks[i].y,z-chunks[i].z);
      return chunks[i].data[chunk_xyz(x-chunks[i].x,y-chunks[i].y,z-chunks[i].z)];
    }
  }
  return 0;
}
function setBlock(x, y, z, v, o){
  if(!o) sendBlock(x, y, z, v);
  var obj = {x:x,y:y,z:z,width:1,height:1,depth:1};
  for(var i=0;i<chunks.length;i++){
    if(cubeCollision2(chunks[i], obj) && (y-chunks[i].y <= 15) && (z-chunks[i].z <= 15) && (x-chunks[i].x <= 15) && (y-chunks[i].y >= 0) && (z-chunks[i].z >=0) && (x-chunks[i].x >= 0)){
       console.log('incorrect', y-chunks[i].y, chunk_xyz(x-chunks[i].x,y-chunks[i].y,z-chunks[i].z));
      chunks[i].data[chunk_xyz(x-chunks[i].x,y-chunks[i].y,z-chunks[i].z)] = v;
      chunks[i].updateBuffer = true;
      return;
    }
  }
  console.log('Failed !');
  for (var i = chunks.length - 1; i >= 0; i--) {
    if(chunks[i].x == round16(x) && chunks[i].y == round16(y) && chunks[i].z == round16(z))return;
  }
  console.log('creating chunk at', round16(x), round16(y), round16(z));
  var chunk = new Chunk(gl, round16(x), round16(y), round16(z), "empty");
  chunk.data[chunk_xyz(x-chunk.x,y-chunk.y,z-chunk.z)] = v;
  chunk.updateBuffer = true;
  chunks.push(chunk);
  return;
}
/*
X=distance*cos(angle)

Y=distance*sin(angle)

*/
function horizontalVerticalDistanceToXYZ(h, v, d){
  var x, y, z;
  x = d * -sin(h);
  z = d * -cos(h);
  y = d * sin(v);
  x *= cos(v);
  z *= cos(v);
  return [x,y,z];
}
function importTextures() {
  var fileInput = $('#teximport');
  fileInput.onchange = (e => {
    var file = fileInput.files[0];
    var fr = new FileReader();
    fr.onload = function(){
      var _image = new Image();
      _image.src = fr.result;
      _image.onload = function(){
        image = _image;
        setTexture(image);
      }
      
    }
    fr.readAsDataURL(file);
  });
  fileInput.click();
}
function logAndReturn(v){console.log(v);return v;}
// Serveur:<select id="et"><option value="eph">Éphémère</option><option value="per">Permanent</option></select><br>
prompt('Entrez un nom d\'utilisateur', 'utilisateur', 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz_').then((_meow) => {
  var username = _meow;
//console.log(server);
const socket = io(logAndReturn(`wss://meows.astroide.repl.co`));
socket.on('connect', () => {
  console.log('connected !');
  socket.on('terrain-sync', terrain => {
    console.log(terrain);
    games.decode(terrain);
    multiplayerConnected = true;
  });
  socket.on('chunk', chunkData => {
    games.addChunk(chunkData);
  });
  setTimeout(()=>{socket.emit('sync', username);
  console.log('syncing with the server...');}, 1000);
  window.sendBlock = function(x,y,z, c){
    socket.emit('set-block', x,y,z,c);
  }
  window.sendKeys = function(ks){
    socket.emit('keychange', Object.assign({f:flight}, ks));
  }
  socket.on('set-block', (x, y, z, c) => {
    setBlock(x, y, z, c, 1);
  });
  socket.on('update', function(obj){
    //console.log('(*_*)');
    var player = obj.self;
    tx = player.x;
    ty = player.y;
    tz = player.z;
    window.players = obj.players;
  });
  socket.emit('send-updates');
  setInterval(()=>{
    socket.emit('orientation', horizontalHeading, verticalHeading);
  }, 1000/24);
  socket.on('blablabla', message => {
    cm1 = cm2;
    cm2 = cm3;
    cm3 = message + '\n';
  });
  window.sendMessage = (message => {
    socket.emit('blablabla', message);
  });
  window.emitHit = ((playerName, angle) => {
    socket.emit('player-hit', playerName, angle);
  });
});
});
function xyzToXy(x, y, z, matrix){
  var point = [x,y,z, 1];
  var clipspace = m4.transformVector(matrix, point);
  clipspace[0] /= clipspace[3];
  clipspace[1] /= clipspace[3];
  var pixelX = (clipspace[0] *  0.5 + 0.5) * gl.canvas.width;
  var pixelY = (clipspace[1] * -0.5 + 0.5) * gl.canvas.height;
  return [pixelX, pixelY];
}