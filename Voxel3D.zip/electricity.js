var activatedBoxes = {
    list: [],
    dictionary: {}
}
class ActivatedBox {
    constructor(x, y, z, list, dict){
        //if(activatedBoxes.dictionary[((x) + '/' + (y) + '/' + (z))]) return;
        list = list || activatedBoxes.list;
        dict = dict || activatedBoxes.dictionary;
        this.x = x;
        this.y = y;
        this.z = z;
        this.state = ActivatedBox.LIGHTED;
        list.push(this.listEntry = [(this.x) + '/' + (this.y) + '/' + (this.z), this]);
        dict[(this.x) + '/' + (this.y) + '/' + (this.z)] = this;
        activatedBoxes.dictionary[(this.x) + '/' + (this.y) + '/' + (this.z)] = this;
        this.wait = 10;
    }
    update(list, dict){
        list = list || activatedBoxes.list;
        dict = dict || activatedBoxes.dictionary;
        // Instance multiplication error
        // if(--this.wait > 0) return;
        if(this.state == ActivatedBox.LIGHTED){
            var boxLocation, tmp;
            if((tmp = getBlockFast(this.x-1, this.y, this.z)) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x-1) + '/' + (this.y) + '/' + (this.z))]){
                new ActivatedBox(this.x-1, this.y, this.z, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            } else {
                if(tmp == ARROW_THROWER){
                    throwArrows(this.x-1, this.y, this.z);
                }
            }
            if((tmp = getBlockFast(this.x+1, this.y, this.z)) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x+1) + '/' + (this.y) + '/' + (this.z))]){
                new ActivatedBox(this.x+1, this.y, this.z, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            } else {
                if(tmp == ARROW_THROWER){
                    throwArrows(this.x+1, this.y, this.z);
                }
            }
            if((tmp = getBlockFast(this.x, this.y-1, this.z)) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x) + '/' + (this.y-1) + '/' + (this.z))]){
                // console.log(boxLocation, this);
                // throw new Error('meow');
                new ActivatedBox(this.x-1, this.y-1, this.z, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            } else {
                if(tmp == ARROW_THROWER){
                    throwArrows(this.x, this.y-1, this.z);
                }
            }
            if((tmp = getBlockFast(this.x, this.y+1, this.z)) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x) + '/' + (this.y+1) + '/' + (this.z))]){
                new ActivatedBox(this.x, this.y+1, this.z, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            } else {
                if(tmp == ARROW_THROWER){
                    throwArrows(this.x, this.y+1, this.z);
                }
            }
            if((tmp = getBlockFast(this.x, this.y, this.z-1)) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x) + '/' + (this.y) + '/' + (this.z-1))]){
                new ActivatedBox(this.x, this.y, this.z-1, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            } else {
                if(tmp == ARROW_THROWER){
                    throwArrows(this.x, this.y, this.z-1);
                }
            }
            if((tmp = getBlockFast(this.x, this.y, this.z+1)) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x) + '/' + (this.y) + '/' + (this.z+1))]){
                new ActivatedBox(this.x, this.y, this.z+1, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            } else {
                if(tmp == ARROW_THROWER){
                    throwArrows(this.x, this.y, this.z+1);
                }
            }
            this.state = ActivatedBox.SHUTTING_DOWN;
        } else if(this.state == ActivatedBox.SHUTTING_DOWN){
            dict[(this.x) + '/' + (this.y) + '/' + (this.z)] = null;
            return true;
        }
    }
    move(obj){
		for(var i=0;i<obj.length;i+=3){
			//var __ = obj[i];
			//obj[i] = Math.cos(Math.lookAt(obj[i], obj[i+2], 0, 0) + this.dir + Squirrel.rotation) * distance2d(obj[i], obj[i+2], 0, 0);
			//obj[i+2] = Math.sin(Math.lookAt(__, obj[i+2], 0, 0) + this.dir + Squirrel.rotation) * distance2d(__, obj[i+2], 0, 0);
			obj[i] += this.x + 0.85;
			obj[i+1] += this.y;
			obj[i+2] += this.z + 0.85;
		}
		return obj;
	}
}
ActivatedBox.LIGHTED = 0;
ActivatedBox.SHUTTING_DOWN = 1;
class SignalEmitter {
    constructor(x, y, z){
        this.wait = 12;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    update(list, dict){
        if(--this.wait < 0){
            this.wait = 12;
            var boxLocation, next;
            if(getBlockFast(this.x-1, this.y, this.z) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x-1) + '/' + (this.y) + '/' + (this.z))]){
                new ActivatedBox(this.x-1, this.y, this.z, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            }
            if(getBlockFast(this.x+1, this.y, this.z) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x+1) + '/' + (this.y) + '/' + (this.z))]){
                new ActivatedBox(this.x+1, this.y, this.z, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            }
            if(getBlockFast(this.x, this.y-1, this.z) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x) + '/' + (this.y-1) + '/' + (this.z))]){
                // console.log(boxLocation, this);
                // throw new Error('meow');
                new ActivatedBox(this.x, this.y-1, this.z, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            }
            if(getBlockFast(this.x, this.y+1, this.z) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x) + '/' + (this.y+1) + '/' + (this.z))]){
                new ActivatedBox(this.x, this.y+1, this.z, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            }
            if(getBlockFast(this.x, this.y, this.z-1) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x) + '/' + (this.y) + '/' + (this.z-1))]){
                new ActivatedBox(this.x, this.y, this.z-1, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            }
            if(getBlockFast(this.x, this.y, this.z+1) == CONDUCTOR && !activatedBoxes.dictionary[boxLocation = ((this.x) + '/' + (this.y) + '/' + (this.z+1))]){
                new ActivatedBox(this.x, this.y, this.z+1, list, dict);
                // activatedBoxes.dictionary[boxLocation] = next;
            }
            if(getBlockFast(this.x, this.y, this.z) !== EMITTER) return true;
        }
    }
}

function throwArrows(x, y, z){
    if(window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED){
        serverInterface.arrows([
            [x-1, y, z, -1.455 * Math.PI, 0],
            [x+1, y, z, -1.455 * Math.PI + Math.PI, 0]
        ]);
    } else {
        window.objects.arrows.push(new Arrow(x-1, y, z, {horizontal:-1.455 * Math.PI,vertical:0}, horizontalVerticalDistanceToXYZ, {arrowForce:0.4}));
        window.objects.arrows.push(new Arrow(x+1, y, z, {horizontal:-1.455 * Math.PI + Math.PI,vertical:0}, horizontalVerticalDistanceToXYZ, {arrowForce:0.4}));
        window.objects.arrows.push(new Arrow(x, y, z-1, {horizontal:0,vertical:0}, horizontalVerticalDistanceToXYZ, {arrowForce:0.4}));
        window.objects.arrows.push(new Arrow(x, y, z+1, {horizontal:Math.PI*0.95+Math.PI,vertical:0}, horizontalVerticalDistanceToXYZ, {arrowForce:0.4}));
    }
}