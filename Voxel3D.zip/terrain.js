//const $ = document.querySelector.bind(document), canvas = $('#cnv'), ctx = canvas.getContext('2d');
//var t = 85;
//ctx.fillStyle = 'black';
//ctx.fillRect(0, 0, 512, 512);
//ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
//ctx.filter = 'blur(0.5px)';
Math.lookAt = function(x1, y1, x2, y2){
	return Math._direction = Math.atan2(y2-y1, x2-x1);
}
function horizontalVerticalDistanceToXYZ(h, v, d){
  var x, y, z;
  x = d * -Math.sin(h);
  z = d * -Math.cos(h);
  y = d * Math.sin(v);
  x *= Math.cos(v);
  z *= Math.cos(v);
  return [x,y,z];
}
var LAVA        =  1;
var GRASS       =  2;
var BLUE        =  3;
var GLASS       =  4;
var FOLIAGE     =  5;
var WOOD        =  6;
var BLUE_STONE  =  7;
var WOOD_BIRCH  =  8;
var BLACK_STONE =  9;
var RED         = 10;
var BRICK       = 11;
var SAND        = 12;
var MAGIC       = 13;
var GREY_STONE  = 14;
var SNOW        = 15;
var EARTH       = 19;
function distance2d(x1, y1, x2, y2){
  var dx = x2 - x1, dy = y2 - y1;
  return Math.sqrt(dx*dx + dy*dy);
}
function round16(n){
  return Math.floor(n/16)*16;
}
function CreateTerrain(fns){
if(typeof window === "undefined") var window;
if(typeof global === "undefined") var global = this;
window = window || global;
this.getBlockFast = this.getBlockFast || fns.getBlockFast;
this.setBlockFast = this.setBlockFast || fns.setBlockFast;
  if(window.GAME_SAVED) return;
if(window.sessionStorage && window.sessionStorage.getItem('gamemode') == 'survival') limited = true;
;(function(){
var interval, X = 0, Y = -20, Z = 0, SZ = 10, N = 0;

interval = setInterval(()=>{
    N++;
    Y = -20;
    X = Math.floor(Math.random()*255 - 255/2);
    Z = Math.floor(Math.random()*255 - 255/2);
    SZ = 10;
    for(;SZ > 0;SZ-=2,Y--){
    for(var i = X - (SZ / 2); i < X + SZ / 2;i++){
        for(var j = Z - (SZ / 2); j < Z + SZ / 2;j++){
            setBlockFast(i, Y, j, SZ == 10 ? 2 : 7);
        }
    }
}
    if(N > 50) clearInterval(interval);
}, 50);
window.cancelIslands = function () {
  clearInterval(interval);
}
})();
function randomDirection(){
  return Math.sign(Math.random()-0.5);
}
function constrain(n, min, max){
  if(n<min) return min;
  if(n>max) return max;
  return n;
}
window.dir = randomDirection;
function cave(x, y, z, n){
  // let type = Math.random() > 0.94 ? WATER : 0;
  let type = 0
  var cl = 0, hv = Math.random()*Math.PI*2, vv = 0;
  let caveSize = 1;
  while((getBlockFast(x, y, z) != 0||y<2)&&cl<200){
    caveSize += Math.round(Math.random() * 1.5 - 0.75);
    caveSize = Math.min(Math.max(caveSize, 1), 1);
    if(y <= 3) vv = -vv;
    cl++;
    hv += Math.random()-0.5;
    if(hv<0){
      hv += Math.PI*2;
    }else if(hv > Math.PI*2){
      hv -= Math.PI*2;
    }
    vv += (Math.random()-0.5)/5;
    vv = constrain(vv, -Math.PI/2, Math.PI/2);
    var [dx, dy, dz] = horizontalVerticalDistanceToXYZ(hv, vv, 1);
    x += dx;
    y += dy;
    z += dz;
    var sx = x, sy = y, sz = z;
    x = Math.round(sx);
    y = Math.round(sy);
    z = Math.round(sz);
    // setBlockFast(x, y,   z, 0);
    // setBlockFast(x, y-1, z, 0);
    // setBlockFast(x, y+1, z, 0);
    // setBlockFast(x, y,   z-1, 0);
    // setBlockFast(x, y-1, z-1, 0);
    // setBlockFast(x, y+1, z-1, 0);
    // setBlockFast(x, y,   z+1, 0);
    // setBlockFast(x, y-1, z+1, 0);
    // setBlockFast(x, y+1, z+1, 0);
    // setBlockFast(x-1, y,   z, 0);
    // setBlockFast(x-1, y-1, z, 0);
    // setBlockFast(x-1, y+1, z, 0);
    // setBlockFast(x+1, y,   z, 0);
    // setBlockFast(x+1, y-1, z, 0);
    // setBlockFast(x+1, y+1, z, 0);
    // setBlockFast(x-1, y, z-1, 0);
    // setBlockFast(x+1, y, z+1, 0);
    // setBlockFast(x-1, y, z+1, 0);
    // setBlockFast(x+1, y, z-1, 0);
    // setBlockFast(x-1, y+1, z-1, 0);
    // setBlockFast(x+1, y+1, z+1, 0);
    // setBlockFast(x-1, y+1, z+1, 0);
    // setBlockFast(x+1, y+1, z-1, 0);
    // setBlockFast(x-1, y-1, z-1, 0);
    // setBlockFast(x+1, y-1, z+1, 0);
    // setBlockFast(x-1, y-1, z+1, 0);
    // setBlockFast(x+1, y-1, z-1, 0);
    for(let xx=x-caveSize;xx<x+caveSize+1;xx++){
      for(let yy=y-caveSize;yy<y+caveSize+1;yy++){
        for(let zz=z-caveSize;zz<z+caveSize+1;zz++){
          setBlockFast(xx, yy, zz, type);
        }
      }
    }
    x = sx, y = sy, z = sz;
  }
  //if(n>0){
  //  cave(x, y, z, n-1);
  //}
}
window.cave = cave;
function createTree(x, y, z, inDesert){
  var type = inDesert ? Math.floor(Math.random()*2) + 1 : Math.floor(Math.random()*3), color = (inDesert ? [WOOD,WOOD] : [WOOD,WOOD_BIRCH])[Math.round(Math.random())];
  y++;
  var MAXHEIGHT = y+(inDesert ? 5 : 16);
  //type = 0;
  switch(type){
    case 0:
    // Fir
    for(var i=0;i<3;i++,y++)setBlockFast(x, y, z, color);
    for(var i=4;i>0;i--,y++){
      setBlockFast(x, y, z, color);
      var isTheTop = true;
      for(var n=1;n<i;n++){
        isTheTop = false;
        setBlockFast(x-n, y, z, FOLIAGE);
        setBlockFast(x+n, y, z, FOLIAGE);
        setBlockFast(x, y, z-n, FOLIAGE);
        setBlockFast(x, y, z+n, FOLIAGE);
      }
      if(isTheTop){
        setBlockFast(x, y, z, FOLIAGE);
      }
    }
    break;

    case 1:
    
    // Normal
    while(Math.random()>0 && y < MAXHEIGHT){
    setBlockFast(x, y, z, color);
    setBlockFast(x+1, y, z, FOLIAGE);
    setBlockFast(x-1, y, z, FOLIAGE);
    setBlockFast(x, y, z+1, FOLIAGE);
    setBlockFast(x, y, z-1, FOLIAGE);
    y++;
    if(Math.random()>0.5){
      x+= Math.sign(Math.random()-0.5);
    }else z+= Math.sign(Math.random()-0.5);
    }
    setBlockFast(x, y, z, FOLIAGE);
    break;

    case 2:
    for(var i=0;i<(inDesert ? 0 : 3);i++){
      setBlockFast(x, y++, z, color);
    }
    for(var i=0,rad;i<4;i++){
      rad = [0,1,1,0][i];
      if(rad == 1){
        for(var rotation=0;rotation<Math.PI*2;rotation+=0.1){
          setBlockFast(x+Math.round(Math.cos(rotation)*2), y, z+Math.round(Math.sin(rotation)*2), FOLIAGE);
        }
      } else {
        setBlockFast(x-1, y, z-1, FOLIAGE);
        setBlockFast(x+1, y, z-1, FOLIAGE);
        setBlockFast(x-1, y, z+1, FOLIAGE);
        setBlockFast(x+1, y, z+1, FOLIAGE);
        setBlockFast(x-1, y, z, FOLIAGE);
        setBlockFast(x+1, y, z, FOLIAGE);
        setBlockFast(x, y, z+1, FOLIAGE);
        setBlockFast(x, y, z-1, FOLIAGE);
      }
      setBlockFast(x, y++, z, color);
    }
    setBlockFast(x, y, z, FOLIAGE);
    setBlockFast(x+1, y, z, FOLIAGE);
    setBlockFast(x-1, y, z, FOLIAGE);
    setBlockFast(x, y, z+1, FOLIAGE);
    setBlockFast(x, y, z-1, FOLIAGE);
    break;
  }
}
function pickRandom(array){
  return array[Math.floor(Math.random()*array.length)];
}
const SOME_MATH_CONSTANT = 6 * Math.SQRT2; // 3
window.houses = [];
var useNpcs = sessionStorage.disableNPCs !== "true";
function house(x, z,fc,obj){
  var s = [x, z], source = {
    x: x,
    z: z
  };
  x = Math.round(x + (Math.random()*40)-20);
  z = Math.round(z + (Math.random()*40)-20);
  //var dst = distance2d(x, z, s[0], s[1]);
  s = Math.lookAt(x, z, s[0], s[1]) + Math.PI * 2;
  var theAngle = s;
  var xx = Math.cos(s)/*constrain(Math.cos(s), -SOME_MATH_CONSTANT, SOME_MATH_CONSTANT)*/, zz = /*constrain(*/Math.sin(s)/*, -SOME_MATH_CONSTANT, SOME_MATH_CONSTANT)*/;
  var y = Math.floor(terrain.cnv.pixelAt(x+256, z+256) / 8) + 21;
  if(obj) [x,y,z] = obj;
  //console.log(x,y,z);
  if(!([x,y,z].every(x => !isNaN(x)))){
    return;
  }
  houses.push({x:x,y:y+1,z:z});
  if((fc||Math.random()) > 0.1){
    if(Math.random() > 0.5 && useNpcs) personWaitList.push(new Person(x, y+1, z, source));
    // Floor
    for(var _x = x-3;_x<x+3;_x++){
      for(var _z = z-3;_z<z+3;_z++){
        setBlockFast(_x, y, _z, WOOD_BIRCH);
      }
    }
    y++;
    // Walls
    for(var i=0;i<3;i++){
      for(var _x = x-3;_x<x+3;_x++){
        for(var _z = z-3;_z<z+3;_z++){
          setBlockFast(_x, y, _z, BRICK);
        }
      }
      for(var _x = x-2;_x<x+2;_x++){
        for(var _z = z-2;_z<z+2;_z++){
          setBlockFast(_x, y, _z, 0);
        }
      }
      y++;
    }
    // Roof
    for(var i=3;i>0;i--,y++){
      for(var _x = x-i;_x<x+i;_x++){
        for(var _z = z-i;_z<z+i;_z++){
          setBlockFast(_x, y, _z, BLUE_STONE);
        }
      }
    }
    for(var i=0;i<=SOME_MATH_CONSTANT;i+=0.1){
      setBlockFast(Math.round(xx*i)+x, y - 6, Math.round(zz*i)+z, 0);
      setBlockFast(Math.round(xx*i)+x, y - 5, Math.round(zz*i)+z, 0);
      setBlockFast(Math.round(xx*i)+x, y - 4, Math.round(zz*i)+z, 0);
    }
  } else {
    // Black Tower
    //console.log(`Toure Nouare @ X ${x} Y ${y} Z ${z}`)
    useNpcs && personWaitList.push(new Person(x, y+5, z, source));
    for(let maxy=y+16,radius=5;y<maxy && radius > 0.1;y++,radius *= 0.9){
      for(let angle=0,maxangle=Math.PI*2;angle<maxangle;angle+=Math.PI/45){
        setBlockFast(Math.round(x + Math.cos(angle) * radius), y, Math.round(z + Math.sin(angle) * radius), BLACK_STONE);
        for(let d=radius-1;d>0.01;d-=0.1){
          setBlockFast(Math.round(x + Math.cos(angle) * d), y, Math.round(z + Math.sin(angle) * d), 0);
        }
      }
    }
    var maxy, init_angle=theAngle-Math.PI/8,radius=5;
    for(maxy=y-12,y-=16;y<maxy;y++,radius*=0.9){
      for(var angle = init_angle,ang=angle,maxangle=angle+Math.PI/4;angle<maxangle;angle+=Math.PI/45){
          setBlockFast(Math.round(x + Math.cos(angle) * radius), y, Math.round(z + Math.sin(angle) * radius), 0);
      }
      setBlockFast(Math.round(x + Math.cos(ang) * radius), y, Math.round(z + Math.sin(ang) * radius), RED);
      setBlockFast(Math.round(x + Math.cos(maxangle) * radius), y, Math.round(z + Math.sin(maxangle) * radius), RED);
    }
    for(var angle = init_angle,ang=angle,maxangle=angle+Math.PI/4;angle<maxangle;angle+=Math.PI/45){
          setBlockFast(Math.round(x + Math.cos(angle) * radius), y, Math.round(z + Math.sin(angle) * radius), RED);
    }
    for(y-=5,radius=5;radius > 0.01;radius -= 0.1){
      for(let angle=0,maxangle=Math.PI*2;angle<maxangle;angle+=Math.PI/45){
        setBlockFast(Math.round(x + Math.cos(angle) * radius), y, Math.round(z + Math.sin(angle) * radius), WOOD);
      }
    }
  }
}
window.house = house;
window.villages = [];
function village(_,__){
  var gx = Math.floor(_||(Math.random()*512-256)), gz = Math.floor(__||(Math.random()*512-256));
  villages.push([gx,gz]);
  var nh = Math.random()*15;
  for(var i=0;i<nh;i++){
    house(gx, gz);
  }
}
window.village = village;

var terrain = new Terrain();
var heatMap = new Terrain(0.55);
window.deserts = [];
for(var i=0;i<25;i++){
  deserts.push([Math.random()*512-256,Math.random()*512-256]);
}
var lakes = [];
console.log('TERRAIN');
for(var i=0;i<15;i++){
  lakes.push([Math.floor(Math.random()*512-256),Math.floor(Math.random()*512-256)]);
}
for(var x=0;x<512;x++){
  for(var z=0;z<512;z++){
    // var sh = Infinity;
    // for(var i=0;i<deserts.length;i++){
      // d = distance2d(deserts[i][0], deserts[i][1], x-256, z-256);
      // if(d < sh) sh = d;
    // }
    // sh += Math.random() * 5 - 2.5;
    // var inDesert = sh < 10;
    var inSnow = heatMap.cnv.pixelAt(x, z) > 90 && terrain.cnv.pixelAt(x, z) > 100 && !inDesert;
    var inDesert = heatMap.cnv.pixelAt(x, z) < 30;
    var h = terrain.cnv.pixelAt(x, z) / 8;
    h += 20;
    // water : < 16
    for(var y=0;y<h;y++){
      let height = y/h;
      let groundType = height < 0.3 ? GREY_STONE : (
        height < 0.85 ? BLUE_STONE : EARTH
      );
      // (y/h < 0.3) ? ((Math.random() > 0.05 ? GREY_STONE : pickRandom([LAVA,BLUE,BRICK,SAND]))) : inDesert ? SAND:(Math.random() > 0.05 ? BLUE_STONE : pickRandom([LAVA,BLUE,BRICK,SAND]))
      setBlockFast(x-256, y, z-256, inDesert ? SAND : (
        Math.random() > 0.05 ? groundType : pickRandom([LAVA,BLUE,BRICK,SAND])
      ));
    }
    setBlockFast(x-256, Math.floor(h), z-256, inDesert ? SAND : GRASS);
    if(inSnow) setBlockFast(x-256, Math.floor(h) + 1, z-256, SNOW);
    // for(var y=h+1+inSnow;y<30;y++){
      // let height = y/h;
      // let tmp
      // (y/h < 0.3) ? ((Math.random() > 0.05 ? GREY_STONE : pickRandom([LAVA,BLUE,BRICK,SAND]))) : inDesert ? SAND:(Math.random() > 0.05 ? BLUE_STONE : pickRandom([LAVA,BLUE,BRICK,SAND]))
      // /*if((tmp = heatMap.cnv.pixelAt(x, z)) < 60 && tmp > 51)*/setBlockFast(x-256, Math.floor(y), z-256, WATER);
      // ));
    // }
  }
}

for(var i=0;i<80;i++){
  var x = Math.floor(Math.random()*512);
  var z = Math.floor(Math.random()*512);
  var y = 10;//Math.floor(terrain.cnv.pixelAt(x, z)/10);
  x -= 256;
  z -= 256;
  cave(x, y, z, 10);
  var barNumber = Math.floor(i/80 * 20), fullBars = ' '.repeat(barNumber), emptyBars = ' '.repeat(20-barNumber);
  console.log(`GROTTES : |\u001b[42m${fullBars}\u001b[0m${emptyBars}|${i==79?'':'\u001b[1A'}`);
}
for(var i=0;i<2500;i++){
  var x = Math.floor(Math.random()*512);
  var z = Math.floor(Math.random()*512);
  var y = Math.floor(terrain.cnv.pixelAt(x, z)/8) + 20;
  x -= 256;
  z -= 256;
  // var sh = Infinity;
    // for(var n=0;n<deserts.length;n++){
      // d = distance2d(deserts[n][0], deserts[n][1], x, z);
      // if(d < sh) sh = d;
    // }
  // var inDesert = sh < 10;
  var inDesert = heatMap.cnv.pixelAt(x, z) < 30;
  createTree(x,y,z,inDesert);
  var barNumber = Math.floor(i/2500 * 20), fullBars = ' '.repeat(barNumber), emptyBars = ' '.repeat(20-barNumber);
  console.log(`ARBRES : |\u001b[42m${fullBars}\u001b[0m${emptyBars}|${i==(2500-1)?'':'\u001b[1A'}`);
}

for(var i=0;i<20;i++){
  village();
  var barNumber = i, fullBars = ' '.repeat(barNumber), emptyBars = ' '.repeat(20-barNumber);
  console.log(`VILLAGES : |\u001b[42m${fullBars}\u001b[0m${emptyBars}|${i==19?'':'\u001b[1A'}`);
}
//village(8,8);
for(var x=7;x<=9;x++){
  for(var y=49;y<=51;y++){
    for(var z=7;z<=9;z++){
      setBlockFast(x,y,z,0);
    }
  }
}
Castle(0,-1,0,512,50,BLACK_STONE,0);
function flood(x, y, z) {
  setBlockFast(x, y, z, WATER);
  var list = [];
  list.push([x, y, z]);
  // debugger;
  for (let i = 0; i < list.length; i++) {
    const [x, y, z] = list[i];
    if(!getBlockFast(x-1, y-1, z)){
      list.push([x-1, y-1, z]);
      setBlockFast(x-1, y-1, z, WATER);
    }
    if(!getBlockFast(x+1, y-1, z)){
      list.push([x+1, y-1, z]);
      setBlockFast(x+1, y-1, z, WATER);
    }
    if(!getBlockFast(x, y-1, z-1)){
      list.push([x, y-1, z-1]);
      setBlockFast(x, y-1, z-1, WATER);
    }
    if(!getBlockFast(x, y-1, z+1)){
      list.push([x, y-1, z+1]);
      setBlockFast(x, y-1, z+1, WATER);
    }
    if(!getBlockFast(x, y-1, z)){
      list.push([x, y-1, z]);
      setBlockFast(x, y-1, z, WATER);
    }
    console.log(':>>', i);
  }
}
window.flood = flood;
// flood(0, 100, 0);
typeof render !== "undefined" && render();
}
/*class HeatMap {
  /**
   * @param {number} sizeX Width
   * @param {number} sizeY Height
   * /
  constructor(sizeX, sizeY){
    this.width = sizeX;
    this.height = sizeY;
    this.map = new Float64Array(this.width*this.height);
    for (let i = 0; i < this.map.length; i++) {
      this.map[i] = 5;
    }
    for(var i=0;i<10;i++){
      this.hit(Math.floor(Math.random()*this.width),Math.floor(Math.random()*this.height), Math.random()+0.5);
    }
  }
  getValue(x, y){
    return this.map[y*this.width+x];
  }
  setValue(x, y, v){
    return this.map[y*this.width+x] = v | 0;
  }
  hit(hitX, hitY, strength){
    var spread = Math.round(Math.max(strength, 1/strength) * ((this.width+this.height)/5));
    //console.log('spread', spread);
    for(var x=hitX-spread;x<hitX+spread;x++){
      for(var y=hitY-spread;y<hitY+spread;y++){
        if(x<0 || y<0 || x>this.width || y>this.height) continue;
        this.map[y*this.width+x] *= strength + ((1-strength) * (spread - distance2d(hitX, hitY, x, y)) / spread);
      }
    }
  }
}
var hm = new HeatMap(32, 32), str = '';
for(var i=0;i<hm.width;i++){
  str = ' ';
  for(var j=0;j<hm.height;j++){
    str += Math.floor(hm.map[j*8+i]);
  }
  console.log(str);
}*/
//console.log(hm.map);
class Terrain {
  constructor(threshold) {
    class Canvas {
      constructor(w, h) {
        this.width = w;
        this.height = h;
        this.data = new Uint8Array(w * h);
        this._fillStyle = [1, 0];
      }
      set fillStyle(fs) {
        this._fillStyle = fs.slice(0, 2);
      }
      get fillStyle() {
        return this._fillStyle;
      }
      fillRect(x, y, w, h) {
        if (!this._fillStyle[1]) return;
        var dx = x + w, dy = y + h;
        for (var i = x; i < dx; i++) {
          for (var j = y; j < dy; j++) {
            if (this._fillStyle[1] == 1) this.data[i * this.height + j] = this._fillStyle[0];
            else {
              var newColor = this._fillStyle[1] * this._fillStyle[0] + (1 - this._fillStyle[1]) * this.data[i * this.height + j];
              this.data[i * this.height + j] = Math.round(newColor);
            }
          }
        }
      }
      pixelAt(x, y) {
        return this.data[x * this.height + y];
      }
      clone(){
        const clone = new Canvas(this.width, this.height);
        for(var i=0;i<this.width*this.height;i++){
          clone.data[i] = this.data[i];
        }
        return clone;
      }
    }
    var cnv = new Canvas(512, 512);
    for (var size of (n => { var x = []; for (var i = 0; i < 6; i++)x.push(n *= 2); return x })(4).reverse()) {
      var pixels = Math.floor(512 / size);
      for (var x = 0; x < 512; x += pixels) {
        for (var y = 0; y < 512; y += pixels) {
          cnv.fillStyle = [255, Math.random() / 3];
          cnv.fillRect(x, y, pixels, pixels);
        }
      }
    }
    var lim = 255 * (threshold||0.5);//0.45 for more mountains
    function hamster() {
      for (var i = 0; i < 512; i++) {
        for (var j = 0; j < 512; j++) {
          var n = 0;
          for (var [x, y] of [[i - 1, j], [i + 1, j], [i, j - 1], [i, j + 1], [i - 1, j - 1], [i + 1, j + 1], [i - 1, j + 1], [i + 1, j - 1]]) {
            if (cnv.pixelAt(x, y) < lim) {
              n++;
            }
          }
          if (n >= 2) {
            cnv.fillStyle = [0, 0.3];
            cnv.fillRect(i, j, 1, 1);
          }
        }
      }
    }
    hamster();
    hamster();
    hamster();
    hamster();
    this.cnv = cnv;
    for(var i=0;i<15;i++){
      this.cnv = blur(this.cnv);
    }
  }
}
function Castle(x, y, z, width, height, material, groundMaterial){
  groundMaterial = groundMaterial==undefined ? 2 : groundMaterial;
  [x,y,z] = [x,y,z].map(Math.round);
  width /= 2;
  var root = {x:x,y:y,z:z};
  // First wall
  for(x=root.x-width,z=root.z-width;z<root.z+width+1;z++){
      for(y=root.y;y<root.y+height;y++){
          setBlockFast(x,y,z,material);
      }
  }
  // Second wall
  for(x=root.x+width,z=root.z-width;z<root.z+width+1;z++){
      for(y=root.y;y<root.y+height;y++){
          setBlockFast(x,y,z,material);
      }
  }
  // Third wall
  for(x=root.x-width,z=root.z-width;x<root.x+width+1;x++){
      for(y=root.y;y<root.y+height;y++){
          setBlockFast(x,y,z,material);
      }
  }
  // Fourth wall
  for(x=root.x-width,z=root.z+width;x<root.x+width+1;x++){
      for(y=root.y;y<root.y+height;y++){
          setBlockFast(x,y,z,material);
      }
  }
  for(x=(root.x-width)+1;x<root.x+width;x++){
      for(z=(root.z-width)+1;z<root.z+width;z++){
          setBlockFast(x,root.y,z,groundMaterial)
      }
  }
  function tower(X,Y,Z){
      for(let y=Y;y<Y+height+2;y++){
          for(let x=X-3;x<X+2;x++){
              for(let z=Z-3;z<Z+2;z++){
                  setBlockFast(x,y,z,material);
              }
          }
          if(y==Y) continue;
          for(let x=X-2;x<X+1;x++){
              for(let z=Z-2;z<Z+1;z++){
                  setBlockFast(x,y,z,0);
              }
          }
      }
      for(let y=Y+height+2,f=-4;f<0;y++,f+=0.5){
          for(let x=X+Math.floor(f);x<X-f-1;x++){
              for(let z=Z+Math.floor(f);z<Z-f-1;z++){
                  setBlockFast(x,y,z,material);
              }
          }
      }
  }
  tower(root.x-width,root.y,root.z-width);
  tower(root.x+width+2,root.y,root.z+width+2);
  tower(root.x+width+2,root.y,root.z-width);
  tower(root.x-width,root.y,root.z+width+2);
  for(var n=Math.round(width*2/25),z=root.z-width;n>0;n--,z+=25){
    //console.log(n,z);
    tower(root.x-width,root.y,z);
    tower(root.x+width+2,root.y,z);
  }
}
function fort(x,y,z,sw,sh,material,groundMaterial){
  for(;sw>8;sw-=10,y++,sh+=5){
      //console.log(x,y,z,sw,sh);
      Castle(x,y,z,sw,sh,material,groundMaterial);
  }
}
function blur(terrain){
  var old = terrain, newTerrain = terrain.clone(), val, n;
  for(var x = 0;x<terrain.width;x++){
    for(var y = 0;y<terrain.height;y++){
      n=4;
      val = old.data[x * old.height + y] * 4;
      if(x>0)val += old.data[(x-1) * old.height + (y)] * 2, n+=2;
      if(x<terrain.width-1)val += old.data[(x+1) * old.height + (y)] * 2, n+=2;
      if(y>0)val += old.data[(x) * old.height + (y-1)] * 2, n+=2;
      if(y<terrain.height-1)val += old.data[(x) * old.height + (y+1)] * 2, n+=2;
      if(x>0){
        if(y>0)val += old.data[(x-1) * old.height + (y-1)], n++;
        if(y<terrain.height-1)val += old.data[(x-1) * old.height + (y+1)], n++;
      }
      if(x<terrain.width-1){
        if(y>0)val += old.data[(x+1) * old.height + (y-1)], n++;
        if(y<terrain.height-1)val += old.data[(x+1) * old.height + (y+1)], n++;
      }
      val /= n;
      newTerrain.data[x * old.height + y] = val;
    }
  }
  return newTerrain;
}
(function(){
  if(typeof module !== "undefined" && module.exports){
    module.exports = {
      Terrain: Terrain,
      CreateTerrain: CreateTerrain
    }
  }
})();
