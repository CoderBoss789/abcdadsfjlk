function lineCollision(coord1, width1, coord2, width2) {
  //Determines if the lines defined by coord1/width1 and coord1/width1 collide.
  if ((coord1 >= coord2 && coord1 <= coord2 + width2) || (coord2 >= coord1 && coord2 <= coord1 + width1)) return true;
  else return false;
}

function squareCollision(x1, y1, w1, h1, x2, y2, w2, h2) {
  //Determines if two rectangles collide.
  if (lineCollision(x1, w1, x2, w2) && lineCollision(y1, h1, y2, h2)) return true;
  else return false;
}

function cubeCollision(x1, y1, z1, w1, h1, d1, x2, y2, z2, w2, h2, d2) {
  return lineCollision(z1, d1, z2, d2) && squareCollision(x1, y1, w1, h1, x2, y2, w2, h2);
}

function cubeCollision2(o1, o2) {
  return lineCollision(o1.z, o1.depth, o2.z, o2.depth) && squareCollision(o1.x, o1.y, o1.width, o1.height, o2.x, o2.y, o2.width, o2.height);
}
function greatest(a, b) {
  return Math.max(Math.abs(a), Math.abs(b)) == Math.abs(a) ? a : b;
}
class Arrow {
  constructor(x, y, z, orientation, hvd2xyz, settings, creator) {
    this.damage = settings.arrowDamage;
    this.creator = creator;
    this.x = x;
    this.y = y;
    this.z = z;
    this.dir = orientation.horizontal;
    this.vdir = orientation.vertical;
    [this.xforce, this.yforce, this.zforce] = hvd2xyz(orientation.horizontal, orientation.vertical, 1);
    this.tick = 0;
    this.gf = settings.arrowForce;
    this.hvd2xyz = hvd2xyz;
    //console.log(this, this.xforce, this.yforce, this.zforce);
    this.type = (typeof module !== "undefined" && module.exports) ? 'server' : 'client';
  }
  update(getBlockFast, info, players) {
    if (this.type == "client" && window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) return;
    if(window.animals && window.animals.npcs){
      let self = {
        x: this.x,
        y: this.y,
        z: this.z,
        width: 0.1,
        height: 0.1,
        depth: 0.1
      }, against = {
        x: 0,
        y: 0,
        z: 0,
        width: 0.6,
        height: 1.6,
        depth: 0.6
      };
      for (let i = 0; i < animals.npcs.length; i++) {
        /**
         * @type {Person}
         */
        const npc = animals.npcs[i];
        against.x = npc.x;
        against.y = npc.y;
        against.z = npc.z;
        if (cubeCollision2(against, self)){
          npc.gotHitByAnArrow(this.creator);
          info.deleted = true;
          return;
        }
      }
    }
    if(this.type == 'client'){
      if(this.creator != 'player' && cubeCollision2({x:this.x, y:this.y, z:this.z, width:0.1, height:0.1, depth:0.1},{x:tx-0.3, y:ty-0.8, z:tz-0.3, width:0.6, height:1.6, depth: 0.6})){
        hitPlayer(0.1);
      }
    }
    var fallFactor = 360 * 2;
    this.tick = !this.tick;
    if (Math.abs(/* POS */(Math.PI / 2) - this.vdir) > Math.abs(/* NEG */(-Math.PI / 2) - this.vdir)) {
      this.vdir -= Math.PI / fallFactor * -Math.sign(/* NEG */(-Math.PI / 2) - this.vdir);
    } else {
      this.vdir += Math.PI / fallFactor * -Math.sign(/* POS */(Math.PI / 2) - this.vdir);
    }
    this.gf *= 0.9999;
    this.gf *= 1 - (Math.PI - Math.abs(greatest((/* POS */ (Math.PI / 2) - this.vdir), (/* NEG */ (-Math.PI / 2) - this.vdir)))) / Math.PI / -100;
    if (this.tick) {
      [this.xforce, this.yforce, this.zforce] = this.hvd2xyz(this.dir, this.vdir, 1);
    }
    this.x += this.xforce * this.gf;
    this.y += this.yforce * this.gf;
    this.z += this.zforce * this.gf;
    if (this.type == "server") {
      let self = {
        x: this.x,
        y: this.y,
        z: this.z,
        width: 0.1,
        height: 0.1,
        depth: 0.1
      }, against = {
        x: 0,
        y: 0,
        z: 0,
        width: 0.6,
        height: 1.6,
        depth: 0.6
      };
      for (let i = 0; i < players.length; i++) {
        const player = players[i];
        against.x = player.x;
        against.y = player.y;
        against.z = player.z;
        if (cubeCollision2(against, self) && player != this.creator) {
          player.hit(this.damage, this.creator);
          player.xForce = this.xforce / 10;
          player.zForce = this.zforce / 10;
          info.deleted = true;
          return;
        }
      }
    }
    if (getBlockFast(Math.floor(this.x), Math.floor(this.y), Math.floor(this.z)) || (this.xforce < 1 / 128 && this.yforce < 1 / 128 && this.zforce < 1 / 128)) {
      //setBlockFast(Math.floor(this.x), Math.floor(this.y), Math.floor(this.z));
      info.deleted = true;
    }
  }
  move(obj) {
    for (var i = 0; i < obj.length; i += 3) {
      var __ = obj[i];
      obj[i] = Math.cos(Math.lookAt(obj[i], obj[i + 1], 0, 0) + this.vdir + Math.PI) * distance2d(obj[i], obj[i + 1], 0, 0);
      obj[i + 1] = Math.sin(Math.lookAt(__, obj[i + 1], 0, 0) + this.vdir + Math.PI) * distance2d(__, obj[i + 1], 0, 0);
      var __ = obj[i];
      obj[i] = Math.cos(Math.lookAt(obj[i], obj[i + 2], 0, 0) - this.dir + Math.PI / 2) * distance2d(obj[i], obj[i + 2], 0, 0);
      obj[i + 2] = Math.sin(Math.lookAt(__, obj[i + 2], 0, 0) - this.dir + Math.PI / 2) * distance2d(__, obj[i + 2], 0, 0);
      obj[i] += this.x;
      obj[i + 1] += this.y;
      obj[i + 2] += this.z;
    }
    return obj;
  }
}
if (typeof module !== "undefined" && module.exports) module.exports = Arrow;