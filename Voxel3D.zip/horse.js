Math.lookAt = function(x1, y1, x2, y2){
	return Math._direction = Math.atan2(y2-y1, x2-x1);
}
function distance3d(v1, v2){
    var dx = v1.x - v2.x;
    var dy = v1.y - v2.y;
    var dz = v1.z - v2.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}
function distance2d(x1, y1, x2, y2){
	var dx = x2 - x1, dy = y2 - y1;
	return Math.sqrt(dx*dx + dy*dy);
}
class Something {
    /**
     * @param {number} x X
     * @param {number} y Y
     * @param {number} z Z
     * @param {Horse} owner
     */
    constructor(x, y, z, owner){
        this.x = x;
        this.y = y;
        this.z = z;
        this.width = 0.3;
        this.height = 0.3;
        this.depth = 0.3;
        this.owner = owner;
        this.yForce = 0;
    }
    move(obj){
        for(var i=0;i<obj.length;i+=3){
			obj[i] += this.x;
			obj[i+1] += this.y;
			obj[i+2] += this.z;
		}
		return obj;
    }
    update(){
        var dir = (Math.lookAt(this.x,this.z,this.owner.destination.x,this.owner.destination.z) * 10 + Math.lookAt(this.x,this.z,this.owner.x,this.owner.z) * (distance3d(this,this.owner)/50)) /11;
        //if((distance3d(this.owner.legList[0], this) + distance3d(this.owner.legList[1], this) + distance3d(this.owner.legList[2], this) + distance3d(this.owner.legList[3],this))/4 > 10) dir *= -1;
		this.y += this.yForce;
		var colliding = detectCollision(this);
        var touchingGround = false;
		if (!colliding) this.yForce -= (0.01); else {
	    	var sign = -Math.sign(this.yForce);
            touchingGround = sign == 1;
	    	this.yForce = 0;
    		while (detectCollision(this)) {
        		this.y += 0.0625 * sign;
      		}
      	}
      	var n=0,spd = this.owner.mounted && pressedKeys.q ? 0.4 : 0.3;
      	this.dir = dir;
      	for(var i=0;i<4;i++){
      		n=0;
      		var bx = this.x;
      		this.x += Math.cos(dir) * spd;
      		if(detectCollision(this)){
      			this.x = bx;
      			n++;
      		}
      		var bz = this.z;
      		this.z += Math.sin(dir) * spd;
      		if(detectCollision(this)){
      			this.z = bz;
      			n++;
      		}
      		if(n<2) break;
        }
        if(touchingGround){
            this.yForce += 0.3;
        }
    }
}
var sp = 0.05;
class Horse {
    /**
     * 
     * @param {number} x X
     * @param {number} y Y
     * @param {number} z Z
     */
	constructor(x, y, z){
		this.x = x;
		this.y = y;
		this.z = z;
		this.dir = 0;
		this.yForce = 0;
		this.mounted = false;
		this.destination = houses[Math.floor(Math.random()*houses.length)];
        this.legs = {
            leftFront: new Something(this.x/*-0.5*/,this.y-1,this.z/* +1 */,this),
            rightFront: new Something(this.x/* +0.5 */,this.y-1,this.z/* +1 */,this),
            leftBack: new Something(this.x/* -0.5 */,this.y-1,this.z/* -1 */,this),
            rightBack: new Something(this.x/* +0.5 */,this.y-1,this.z/* -1 */,this)
        }
        this.legList = [this.legs.leftBack,this.legs.leftFront,this.legs.rightBack,this.legs.rightFront];
        this.pos = [[Infinity,Infinity,Infinity]];
        this.domesticated = false;
        this.dir = 0;
	}
	update(){
        if(window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) return;
        this.pos.push([this.x,this.y,this.z]);
        this.legs.leftFront.update();
        this.legs.rightFront.update();
        this.legs.leftBack.update();
        this.legs.rightBack.update();
        this.x = [this.legs.leftFront.x,this.legs.rightFront.x,this.legs.leftBack.x,this.legs.rightBack.x].reduce((a, b) => a + b, 0) / 4;
        this.y = [this.legs.leftFront.y,this.legs.rightFront.y,this.legs.leftBack.y,this.legs.rightBack.y].reduce((a, b) => a + b, 0) / 4 + 1;
        this.z = [this.legs.leftFront.z,this.legs.rightFront.z,this.legs.leftBack.z,this.legs.rightBack.z].reduce((a, b) => a + b, 0) / 4;
		if(distance2d(this.x,this.z,this.destination.x,this.destination.z) < 5){
        	this.destination = houses[Math.floor(Math.random()*houses.length)];
        }
      	this.dir = Math.lookAt(this.x,this.z,this.destination.x,this.destination.z);
      	if(this.y < -100){
      		this.x = 0;this.y = 90; this.z = 0;
      	}
        if(this.mounted){
            if(pressedKeys.r) {
                this.mounted = false;
                pressedKeys.r = false;
            }
            [tx,ty,tz] = [this.x,this.y+2,this.z];
            [this.destination.x,this.destination.y,this.destination.z] = horizontalVerticalDistanceToXYZ(horizontalHeading,verticalHeading,10).map((x,n)=>x+[tx,ty,tz][n]);
            window.yForce=0;
        }
        if(distance3d(window.player,this)<7 && pressedKeys.r){
            this.domesticated = true;
            this.mounted = true;
            pressedKeys.r = false;
        }
        if(this.pos.length>10)this.pos.shift();
        if(distance3d({x:this.pos[0][0],y:this.pos[0][1],z:this.pos[0][2]},this)<1){
            this.legs = {
                leftFront: new Something(this.x/*-0.5*/,this.y-1,this.z/* +1 */,this),
                rightFront: new Something(this.x/* +0.5 */,this.y-1,this.z/* +1 */,this),
                leftBack: new Something(this.x/* -0.5 */,this.y-1,this.z/* -1 */,this),
                rightBack: new Something(this.x/* +0.5 */,this.y-1,this.z/* -1 */,this)
            }
            this.legList = [this.legs.leftBack,this.legs.leftFront,this.legs.rightBack,this.legs.rightFront];
            if(!this.mounted) this.domesticated && Math.random() > 0.6 ? {x:tx,y:ty,z:tz} : this.destination = houses[Math.floor(Math.random()*houses.length)];
        }
	}
	move(obj){
		for(var i=0;i<obj.length;i+=3){
			var __ = obj[i];
			obj[i] = Math.cos(Math.lookAt(obj[i], obj[i+2], 0, 0) + this.dir + Horse.rotation) * distance2d(obj[i], obj[i+2], 0, 0);
			obj[i+2] = Math.sin(Math.lookAt(__, obj[i+2], 0, 0) + this.dir + Horse.rotation) * distance2d(__, obj[i+2], 0, 0);
			obj[i] += this.x+0.15;
			obj[i+1] += this.y+0.2;
			obj[i+2] += this.z+0.15;
		}
		return obj;
	}
}
Horse.rotation = Math.PI / 2;
Horse.xTranslation = 0.5;
if(typeof module !== "undefined" && typeof require !== "undefined" && module.exports){
    module.exports = Horse;
}