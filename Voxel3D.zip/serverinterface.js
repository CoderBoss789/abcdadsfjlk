
const degreesToRadians = (Math.PI / 180);
function xhr(url, data, method){
    return new Promise(resolve => {
        var xhr = new XMLHttpRequest();
        xhr.responseType = "json";
        xhr.onreadystatechange = function(){
            if(xhr.status == 200 && xhr.readyState == 4){
                resolve(xhr.response);
            }
        }
        xhr.open(method || 'POST', url, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
    });
}
function createAccount(username, password){
    return new Promise((resolve, reject) => {
        xhr('https://accounts.astroide.repl.co/newuser', {"username":username,"password":password}).then(result => {
            if(result.status) reject('This username is already taken');
            else {
                resolve();
            }
        });
    });
}
function auth(username, password){
    return new Promise((resolve) => {
        xhr('https://accounts.astroide.repl.co/auth', {"username":username,"password":password}).then(result => {
            if(result.status){
                console.log(result.status);
                resolve((result.status==2)?'Invalid username':'Wrong password.');
            } else {
                resolve();
            }
        });
    });
}
function connect(){
    var socket = io(multiplayerInfo.server);
    socket.on('connect', () => {
        window.serverInterface = {
            sendBlock: () => {},
            sendKeys: () => {},
            sendDirection: () => {}
        };
        window.MULTIPLAYER_CONNECTED = true;
        socket.emit('type', 'gameClient', multiplayerInfo.username);
        socket.on('error', (errorType, additionalInfo) => {
            if(errorType == 'notallowed'){
                if(multiplayerInfo.anonymous){
                    show('Anonymous users aren\'t allowed on this server.');
                } else if(additionalInfo == 'ban'){
                    show('You\'ve been banned from this server.');
                } else {
                    show('You are not authorized to connect to this server.');
                }
                socket.close();
            }
        });
        socket.on('authorized', () => {
            console.log('Connected...');
            window.serverInterface = {
                sendBlock: (x, y, z, v) => {
                    socket.emit('set-block', x, y, z, v);
                },
                sendKeys: k => {
                    socket.emit('keys', k);
                },
                sendDirection: (hh, vh) => {
                    socket.emit('direction', hh, vh);
                },
                createAnimal: (type, x, y, z) => {
                    socket.emit('animal-create', type, x, y, z);
                },
                createPortals: (str1, dest1, str2, dest2) => {
                    console.log('PortalCreate : ', arguments);
                    socket.emit('portal-create', str1, dest1, str2, dest2);
                },
                teleport: (x, y, z) => {
                    socket.emit('goto', x, y, z);
                },
                sendMessage: message => {
                    socket.emit('blablabla', message);
                },
                throwArrow: () => {
                    socket.emit('arrow');
                },
                /**
                 * Ask the server to throw multiple arrows.
                 * @param {number[][]} arr Arrow array [x, y, z, horizontalAngle, verticalAngle][]
                 */
                arrows: (arr) => {
                    socket.emit('arrows', arr);
                }
            };
            window.chunks.splice(0, window.chunks.length);
            window.animals = {
                birds: [],
                squirrels: [],
                horses: []
              };
            socket.on('chunk', c => {
                let x = games.addChunk(c);
                if(x){
                    window.chunks.push(x);
                    // window.cleanChunks && cleanChunks();
                }
                tx = 8;
                tz = 8;
                ty = 50;
            });
            socket.on('echo', message => {
                socket.emit('blablabla', message);
            });
            socket.on('lastChunk', c => {
                let x = games.addChunk(c);
                if(x){
                    window.chunks.push(x);
                    window.cleanChunks && cleanChunks();
                }
                tx = 8;
                tz = 8;
                ty = 50;
            });
            socket.on('set-block', (x, y, z, v) => {
                setBlockFast(x, y, z, v);
            });
            socket.on('blablabla', message => {
                addMessage(message);
            });
            socket.on('portal-create', (str1, dest1, str2, dest2) => {
                if(!window.portalList.includes(str1)) portalList.push(str1);
                if(!window.portalList.includes(str2)) portalList.push(str2);
                console.log(dest1);
                console.log(dest2);
                portals[str1] = dest1;
                portals[str2] = dest2;
            });
            socket.on('clear', ()=>{
                chunks.splice(0, chunks.length);
                window.terrainData = {};
                portalList = [];
                portals = {};
            });
            window.playerInfos = {};
            socket.on('gamedata', data => {
                [tx, ty, tz, window.playerLife] = data[0];
                const p = data[1];
                if(!window.players) window.players = [];
                while(p.length > players.length) players.push({width:0.6,height:1.6,depth:0.6});
                while(p.length < players.length) players.pop();
                for (let i = 0; i < p.length; i++) {
                    const player = p[i];
                    players[i].x = player[0] - 0.3;
                    players[i].y = player[1] - 0.4;
                    players[i].z = player[2] - 0.3;
                    players[i].orientation = {
                        horizontal: -player[3] * degreesToRadians + Math.PI,
                        vertical: player[4] * degreesToRadians
                    };
                    players[i].id = player[5];
                }
                if(!window.animals) window.animals = {};
                const horses = data[2];
                if(!window.animals.horses) window.animals.horses = [];
                while(horses.length > animals.horses.length) animals.horses.push(new Horse(0,0,0));
                while(horses.length < animals.horses.length) animals.horses.pop();
                for (let i = 0; i < horses.length; i++) {
                    const horse = horses[i];
                    animals.horses[i].x = horse[0];
                    animals.horses[i].y = horse[1];
                    animals.horses[i].z = horse[2];
                    animals.horses[i].dir = horse[3] * degreesToRadians;
                }
                const squirrels = data[3];
                if(!window.animals.squirrels) window.animals.squirrels = [];
                while(squirrels.length > animals.squirrels.length){
                    animals.squirrels.push(new Squirrel(0,0,0));
                    console.log('SQRL');
                }
                while(squirrels.length < animals.squirrels.length) animals.squirrels.pop();
                for (let i = 0; i < squirrels.length; i++) {
                    const squirrel = squirrels[i];
                    animals.squirrels[i].x = squirrel[0];
                    animals.squirrels[i].y = squirrel[1];
                    animals.squirrels[i].z = squirrel[2];
                    animals.squirrels[i].dir = squirrel[3] * degreesToRadians;
                }
                const birds = data[4];
                if(!window.animals.birds) window.animals.birds = [];
                while(birds.length > animals.birds.length) animals.birds.push(new Bird(0,0,0));
                while(birds.length < animals.birds.length) animals.birds.pop();
                for (let i = 0; i < birds.length; i++) {
                    const bird = birds[i];
                    animals.birds[i].x = bird[0];
                    animals.birds[i].y = bird[1];
                    animals.birds[i].z = bird[2];
                    animals.birds[i].dir = bird[3] * degreesToRadians;
                }
                const arrows = data[5];
                if(!window.objects.arrows) window.objects.arrows = [];
                while(arrows.length > objects.arrows.length) objects.arrows.push(new Arrow(0,0,0,{},horizontalVerticalDistanceToXYZ,{arrowForce:0}));
                while(arrows.length < objects.arrows.length) objects.arrows.pop();
                for (let i = 0; i < arrows.length; i++) {
                    const arrow = arrows[i];
                    objects.arrows[i].x = arrow[0];
                    objects.arrows[i].y = arrow[1];
                    objects.arrows[i].z = arrow[2];
                    objects.arrows[i].dir = arrow[3] * degreesToRadians;
                    objects.arrows[i].vdir = arrow[4] * degreesToRadians;
                }
            });
            socket.on('player-infos', data => {
                for (let i = 0; i < data.length; i++) {
                    const player = data[i];
                    console.log(player);
                    playerInfos[player.id] = player;
                }
            });
            socket.on('player-info', player => {
                console.log(player);
                playerInfos[player.id] = player;
            });
            
        });
    });
}
var accountDiv = null;
var multiplayerInfo = {};
function multiplayer(){
    window.IS_MULTIPLAYER = true;
    accountDiv = document.getElementById('account');
    multiplayerInfo.server = sessionStorage.getItem('server') || 'wss://meow-server.astroide.repl.co';
    fetch('https://'+multiplayerInfo.server.slice(6)+'/socket.io/socket.io.js').then(() => {
        console.log('waked server');
    });
    if(multiplayerInfo.username = sessionStorage.getItem('username')){
        auth(multiplayerInfo.username, multiplayerInfo.password = sessionStorage.getItem('password')).then(result => {
            if(result){
                // Error
                multiplayerInfo.username = 'qwerty';
                multiplayerInfo.anonymous = true;
                accountDiv.innerText = 'qwerty';
                delete multiplayerInfo.password;
                sessionStorage.removeItem('password');
                // Connect as guest
                connect();
            }else{
                // Success
                accountDiv.innerText = multiplayerInfo.username;
                // Connect to the server...
                connect();
            }
        });
    } else {
        multiplayerInfo.username = 'qwerty';
        multiplayerInfo.anonymous = true;
        accountDiv.innerText = 'qwerty';
        // Connect as guest
        connect();
    }
}