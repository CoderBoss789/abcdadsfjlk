/**
 * Copyright (c) 2020 Olie Auger | https://repl.it/@ASTROIDE/
 */
var RLE_DECODE_MODE = "int";
function RLE_encode(text){
	text += '@';
	var returnv = '', char = text[0], count = 1;
	for (var i = 1; i < text.length; i++) {
		if(text[i] == char){
			count++;
		}else{
			returnv += `${count>1?count:''}${char}`;
			count = 1;
			char = text[i];
		}
	}
	console.log(`Run-length-encoded data size is ${(returnv.length/text.length).toFixed(2)}% of original data`);
	return returnv;
}
function RLE_decode(text){
	var returnv = '';
	var chars = text.split(/(?<=[a-z])(;?)(?=[0-9]?)/g).filter(x => !!x && x!=";"), a, b;
	for (var i = 0; i < chars.length; i++) {
		a = parseInt(chars[i].slice(0, -1)) || 1;
		b = chars[i].slice(-1);
		for (var j = a - 1; j >= 0; j--) {
			returnv += b;
		}
	}
	return returnv;
}