Math.lookAt = function(x1, y1, x2, y2){
	return Math._direction = Math.atan2(y2-y1, x2-x1);
}
function distance3d(v1, v2){
    var dx = v1.x - v2.x;
    var dy = v1.y - v2.y;
    var dz = v1.z - v2.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}
function distance2d(x1, y1, x2, y2){
	var dx = x2 - x1, dy = y2 - y1;
	return Math.sqrt(dx*dx + dy*dy);
}
class Bird {
	constructor(x, y, z){
		this.x = x;
		this.y = y;
		this.z = z;
		this.setDestination();
		this.isParrot = Math.random() > 0.75;
		this.dir = 0;
	}
	setDestination(){
		this.dx = Math.random()*512-256;
		this.dy = 50 + Math.random()*10-5;
		this.dz = Math.random()*512-256;
		this.mx = Math.cos(Math.lookAt(this.x, this.z, this.dx, this.dz)) / 15;
		this.mz = Math.sin(Math._direction) / 15;
		this.dir = Math._direction;
		//this.iterCount = distance2d(this.x, this.z, this.dx, this.dz);
	}
	update(){
		if(window.IS_MULTIPLAYER && window.MULTIPLAYER_CONNECTED) return;
		this.x += this.mx;
		this.z += this.mz;
		this.y += (this.y > this.dy ? -0.05 : 0.05);
		if(Math.abs(this.dx-this.x) + Math.abs(this.dz-this.z) < 15){
			this.setDestination();
		}
		if(getBlockFast(...[this.x,this.y,this.z].map(Math.round)))this.setDestination();
	}
	move(obj){
		for(var i=0;i<obj.length;i+=3){
			var __ = obj[i];
			obj[i] = Math.cos(Math.lookAt(obj[i], obj[i+2], 0, 0) + this.dir - Math.PI/2) * distance2d(obj[i], obj[i+2], 0, 0);
			obj[i+2] = Math.sin(Math.lookAt(__, obj[i+2], 0, 0) + this.dir - Math.PI/2) * distance2d(__, obj[i+2], 0, 0);
			obj[i] += this.x;
			obj[i+1] += this.y;
			obj[i+2] += this.z;
		}
		return obj;
	}
}
if(typeof module !== "undefined" && typeof require !== "undefined" && module.exports){
    module.exports = Bird;
}